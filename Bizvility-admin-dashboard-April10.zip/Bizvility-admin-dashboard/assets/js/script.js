
// fixed help center 
$(document).on('click', '.laucher-icon-img', function(){
    $('.help-box').toggle()
})


// Super Admin Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".super-admin-sidebar");
    const collapseMenu = document.querySelector(".collapse-menu");
    const menuItems = document.querySelectorAll(".menu-item");

    // Function to toggle sidebar visibility based on screen width
    function handleResponsiveSidebar() {
        if (window.innerWidth < 768) {
            sidebar.classList.add("collapsed"); // Hide sidebar initially
        } else {
            sidebar.classList.remove("collapsed"); // Show sidebar for larger screens
        }
    }

    // Initial check on page load
    handleResponsiveSidebar();

    // Also check on window resize
    window.addEventListener("resize", handleResponsiveSidebar);

    // Sidebar collapse toggle (only toggles class)
    collapseMenu.addEventListener("click", function () {
        sidebar.classList.toggle("collapsed");
    });

    // Restore active sublink and submenu from localStorage
    const savedActiveSublink = localStorage.getItem("activeSublink");
    const savedActiveMenu = localStorage.getItem("activeMenu");

    if (savedActiveSublink && savedActiveMenu) {
        const activeMenuItem = document.querySelector(`.menu-item[data-menu="${savedActiveMenu}"]`);
        if (activeMenuItem) {
            const submenu = activeMenuItem.querySelector(".submenu");
            submenu.style.display = "block";
            submenu.classList.add("inside-sidebar");

            submenu.querySelectorAll("a").forEach(link => {
                if (link.textContent === savedActiveSublink) {
                    link.classList.add("active");
                }
            });

            activeMenuItem.classList.add("active");
        }
    }

    // Show sublinks on hover (beside sidebar)
    menuItems.forEach(item => {
        const submenu = item.querySelector(".submenu");
        if (submenu) {
            item.addEventListener("mouseenter", () => {
                if (!submenu.classList.contains("inside-sidebar")) {
                    submenu.style.display = "block";
                }
            });

            item.addEventListener("mouseleave", () => {
                if (!submenu.classList.contains("inside-sidebar")) {
                    submenu.style.display = "none";
                }
            });

            submenu.querySelectorAll("a").forEach(sublink => {
                sublink.addEventListener("click", function (event) {
                    // event.preventDefault();

                    document.querySelectorAll(".submenu a").forEach(link => link.classList.remove("active"));
                    sublink.classList.add("active");

                    localStorage.setItem("activeSublink", sublink.textContent);
                    localStorage.setItem("activeMenu", item.getAttribute("data-menu"));

                    document.querySelectorAll(".submenu").forEach(ul => {
                        ul.classList.remove("inside-sidebar");
                        ul.style.display = "none";
                    });

                    submenu.style.display = "block";
                    submenu.classList.add("inside-sidebar");

                    menuItems.forEach(i => i.classList.remove("active"));
                    item.classList.add("active");

                    updateActiveStyles();
                });
            });

            item.addEventListener("click", function () {
                document.querySelectorAll(".submenu").forEach(ul => {
                    ul.classList.remove("inside-sidebar");
                    ul.style.display = "none";
                });

                menuItems.forEach(i => i.classList.remove("active"));

                if (submenu) {
                    submenu.style.display = "block";
                    submenu.classList.add("inside-sidebar");
                }

                this.classList.add("active");
                updateActiveStyles();
            });
        }
    });

    function updateActiveStyles() {
        menuItems.forEach(item => {
            const listItem = item.querySelector("li");
            if (item.classList.contains("active")) {
                if (listItem) {
                    listItem.style.background = "#2271b1";
                    listItem.style.color = "white";
                    listItem.style.padding = "5px";
                }
            } else {
                const link = item.querySelector("a");
                if (link) {
                    link.style.background = "";
                    link.style.color = "";
                }
            }
        });
    }
});


// sidebar toggle
document.getElementById('sidebar-toggle').addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.getElementById('main-content').classList.toggle('expanded');
});

// close ads
$(document).on('click', '.close1', function(){
    $('.ad1').css({
        display: 'none'
    });
});

$(document).on('click', '.close2', function(){
    $('.ad2').css({
        display: 'none'
    });
});

// dynamic date change
function updateDate() {
    const dateElement = document.getElementById("current-date");
    const now = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    dateElement.innerText = now.toLocaleDateString('en-US', options);
}

document.addEventListener("DOMContentLoaded", function() {
    updateDate();
    setInterval(updateDate, 1000 * 60 * 60); // Check every hour to update the date at midnight
});

//open profile and logout div
$(document).on('click', '.top-nav-hamburger', function () {
    $('.open-profile-box').slideToggle()
})

//open listing more btn
$(document).on('click', '.more-btn-1', function () {
    $('.more-btn-box-1').slideToggle()
})

$(document).on('click', '.more-btn-2', function () {
    $('.more-btn-box-2').slideToggle()
})

$(document).on('click', '.more-btn-3', function () {
    $('.more-btn-box-3').slideToggle()
})

$(document).on('click', '.more-btn-4', function () {
    $('.more-btn-box-4').slideToggle()
})

$(document).on('click', '.more-btn-5', function () {
    $('.more-btn-box-5').slideToggle()
})

$(document).on('click', '.more-btn-6', function () {
    $('.more-btn-box-6').slideToggle()
})

$(document).on('click', '.more-btn-7', function () {
    $('.more-btn-box-7').slideToggle()
})

// Tabs Click Event (Hide More Box on Tab Switch)
$(document).ready(function () {
    $('.btn').on('click', function () {
        $('.more-btn-box-1').css({
            display: 'none'
        });
    });

    $('.btn').on('click', function () {
        $('.more-btn-box-2').css({
            display: 'none'
        });
    });

    $('.btn').on('click', function () {
        $('.more-btn-box-3').css({
            display: 'none'
        });
    });

    $('.btn').on('click', function () {
        $('.more-btn-box-4').css({
            display: 'none'
        });
    });

    $('.btn').on('click', function () {
        $('.more-btn-box-5').css({
            display: 'none'
        });
    });

    $('.btn').on('click', function () {
        $('.more-btn-box-6').css({
            display: 'none'
        });
    });

    $('.btn').on('click', function () {
        $('.more-btn-box-7').css({
            display: 'none'
        });
    });
});



