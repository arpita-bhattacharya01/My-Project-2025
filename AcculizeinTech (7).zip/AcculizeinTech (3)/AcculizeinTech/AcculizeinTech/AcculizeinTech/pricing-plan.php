<?php
session_start();
require_once './connect/config.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['fullname'])) {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['id'];

// Fetch user details
$stmt = $conn->prepare("SELECT fullname, email, phone FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$user_fullname_db = $user['fullname'];
$user_email_db = $user['email'];
$user_phone_db = $user['phone'];

// Fetch data from plans table
$stmt2 = $conn->prepare("SELECT * FROM plans");
$stmt2->execute();
$allPlans = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt2->close();

// Function to generate HTML for a plan card
// function getCard($plan)
// {
//     $customFields = json_decode($plan['custom_fields'], true); // Decode custom_fields JSON
//     $postFields = json_decode($plan['post'], true); // Decode post JSON
//     $postingFields = json_decode($plan['posting'], true); // Decode posting JSON
//     $description = isset($plan['description']) ? $plan['description'] : ''; // Check if 'description' exists

//     $cardHTML = '<div class="plan-card" data-plan-id="' . $plan['id'] . '" data-price="' . $plan['price'] . '" data-duration="' . $plan['duration'] . '">' .
//         '<div class="plan-header">' .
//         '<h3>' . strtoupper($plan['title']) . '</h3>' .
//         '<h1>INR ' . $plan['price'] . '</h1>' .
//         '<small>Per Listing</small>' .
//         '</div>' .
//         '<div class="plan-body">';

//     // Add description if it exists
//     if (!empty($description)) {
//         $cardHTML .= '<p class="plan-description">' . htmlspecialchars($description) . '</p>';
//     }

//     $cardHTML .= '<ul>';

//     // Add custom fields
//     if (!empty($customFields)) {
//         foreach ($customFields as $item) {
//             $cardHTML .= "<li>$item</li>";
//         }
//     }

//     // Add post fields
//     if (!empty($postFields)) {
//         foreach ($postFields as $item) {
//             $cardHTML .= "<li>$item</li>";
//         }
//     }

//     // Add posting fields
//     if (!empty($postingFields)) {
//         foreach ($postingFields as $item) {
//             $cardHTML .= "<li>$item</li>";
//         }
//     }

//     $cardHTML .= '</ul>' .
//         '</div>' .
//         '<div class="plan-footer">' .
//         '<form action="submitlisting.php" method="GET">' .
//         '<input type="hidden" name="plan_id" value="' . htmlspecialchars($plan['id']) . '">' .
//         '<button class="openEnquiryModal">CONTINUE</button>' .
//         '</div>' .
//         '</div>';

//     return $cardHTML;
// }
function getCard($plan)
{
    $customFields = json_decode($plan['custom_fields'], true); // Decode custom_fields JSON
    $postFields = json_decode($plan['post'], true); // Decode post JSON
    $postingFields = json_decode($plan['posting'], true); // Decode posting JSON
    $description = isset($plan['description']) ? $plan['description'] : ''; // Check if 'description' exists

    $cardHTML = '<div class="plan-card" data-plan-id="' . $plan['id'] . '" data-price="' . $plan['price'] . '" data-duration="' . $plan['duration'] . '">' .
        '<div class="plan-header">' .
        '<h3>' . strtoupper($plan['title']) . '</h3>' .
        '<h1>INR ' . $plan['price'] . '</h1>' .
        '<small>Per Listing</small>' .
        '</div>' .
        '<div class="plan-body">';

    // Add description if it exists
    if (!empty($description)) {
        $cardHTML .= '<p class="plan-description">' . htmlspecialchars($description) . '</p>';
    }

    $cardHTML .= '<ul>';

    // Add custom fields
    if (!empty($customFields)) {
        foreach ($customFields as $item) {
            $cardHTML .= "<li>$item</li>";
        }
    }

    // Add post fields
    if (!empty($postFields)) {
        foreach ($postFields as $item) {
            $cardHTML .= "<li>$item</li>";
        }
    }

    // Add posting fields
    if (!empty($postingFields)) {
        foreach ($postingFields as $item) {
            $cardHTML .= "<li>$item</li>";
        }
    }

    $cardHTML .= '</ul>' .
        '</div>' .
        '<div class="plan-footer">' .
        '<form action="submitlisting.php" method="GET">' . // Use GET to pass plan_id in the URL
        '<input type="hidden" name="plan_id" value="' . htmlspecialchars($plan['id']) . '">' . // Pass the plan_id
        '<button type="submit" class="btn btn-primary">CONTINUE</button>' . // Submit the form
        '</form>' .
        '</div>' .
        '</div>';

    return $cardHTML;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bizvility – Dare To Grow</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/bizvility-logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="./assets/css/priceplan.css">
</head>
<style>
    /* Center the modal */
    #enquiryModal {
        display: none;
        /* Hidden by default */
        position: fixed;
        z-index: 1000;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        border-radius: 8px;
        padding: 20px;
        width: 90%;
        max-width: 500px;
    }

    /* Modal content styling */
    .modal-content {
        position: relative;
        padding: 20px;
    }

    /* Close button styling */
    .close-modal {
        position: absolute;
        top: 10px;
        right: 10px;
        font-size: 20px;
        cursor: pointer;
        color: #333;
    }

    /* Add a backdrop effect */
    body.modal-open {
        overflow: hidden;
    }

    body.modal-open::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999;
    }

    .pricing-section {
        padding: 50px 0;
        background-color: #f9f9f9;
    }

    .plan-wrapper {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
    }

    .plan-card {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 300px;
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .plan-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .plan-header {
        background-color: #007bff;
        color: #fff;
        text-align: center;
        padding: 20px;
        border-bottom: 1px solid #ddd;
    }

    .plan-header h3 {
        font-size: 1.5rem;
        margin: 0;
        text-transform: uppercase;
    }

    .plan-header h1 {
        font-size: 2rem;
        margin: 10px 0 0;
    }

    .plan-header small {
        font-size: 0.9rem;
        color: #f0f0f0;
    }

    .plan-body {
        padding: 20px;
    }

    .plan-body ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .plan-body ul li {
        font-size: 1rem;
        color: #555;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
    }

    .plan-body ul li::before {
        content: "✔";
        color: #007bff;
        margin-right: 10px;
        font-size: 1.2rem;
    }

    .plan-footer {
        text-align: center;
        padding: 20px;
        border-top: 1px solid #ddd;
        background-color: #f9f9f9;
    }

    .plan-footer .openEnquiryModal {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 1rem;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .plan-footer .openEnquiryModal:hover {
        background-color: #0056b3;
    }

    .plan-body .plan-description {
        font-size: 1rem;
        color: #666;
        margin-bottom: 15px;
        line-height: 1.5;
    }

    .plan-body ul li {
        font-size: 1rem;
        color: #555;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
    }

    .plan-body ul li::before {
        content: "✔";
        color: #007bff;
        margin-right: 10px;
        font-size: 1.2rem;
    }

    .plan-wrapper {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
        align-items: stretch;
        /* Ensure all cards have the same height */
    }

    .plan-card {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 300px;
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        display: flex;
        flex-direction: column;
        /* Ensure footer stays at the bottom */
    }

    .plan-body {
        flex-grow: 1;
        /* Make the body take up available space */
        padding: 20px;
    }

    .plan-footer {
        text-align: center;
        padding: 20px;
        border-top: 1px solid #ddd;
        background-color: #f9f9f9;
    }

    /* Add styles for filter buttons */
    .filter-buttons {
        text-align: center;
        margin-bottom: 20px;
        margin-top: 20px;
    }

    .filter-buttons button {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 1rem;
        border-radius: 5px;
        cursor: pointer;
        margin: 0 10px;
        transition: background-color 0.3s ease;
    }

    .filter-buttons button:hover {
        background-color: #0056b3;
    }

    .filter-buttons button.active {
        background-color: #0056b3;
    }

    /* Center the modal */
    #enquiryModal {
        display: none;
        /* Hidden by default */
        position: fixed;
        z-index: 1000;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        border-radius: 12px;
        padding: 20px;
        width: 90%;
        max-width: 500px;
        animation: fadeIn 0.3s ease-in-out;
    }

    /* Modal content styling */
    .modal-content {
        position: relative;
        padding: 20px;
        font-family: Arial, sans-serif;
        color: #333;
    }

    /* Close button styling */
    .close-modal {
        position: absolute;
        top: 10px;
        right: 10px;
        font-size: 20px;
        cursor: pointer;
        color: #555;
        transition: color 0.3s ease;
    }

    .close-modal:hover {
        color: #000;
    }

    /* Modal header styling */
    .modal-content h3 {
        font-size: 1.8rem;
        margin-bottom: 20px;
        text-align: center;
        color: #007bff;
        font-weight: bold;
    }

    /* Input field styling */
    .modal-content input,
    .modal-content select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 1rem;
        box-sizing: border-box;
        transition: border-color 0.3s ease;
    }

    .modal-content input:focus,
    .modal-content select:focus {
        border-color: #007bff;
        outline: none;
    }

    /* Submit button styling */
    .modal-content button[type="submit"] {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 1rem;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        width: 100%;
    }

    .modal-content button[type="submit"]:hover {
        background-color: #0056b3;
    }

    /* Add a backdrop effect */
    body.modal-open {
        overflow: hidden;
    }

    body.modal-open::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999;
    }

    /* Fade-in animation */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translate(-50%, -60%);
        }

        to {
            opacity: 1;
            transform: translate(-50%, -50%);
        }
    }
</style>

<body>
    <!-- navbar -->
    <header class="navbar navbar-2">
        <!-- logo -->
        <div class="logo ms-2">
            <a href="index.html">
                <img src="assets/imgs/logo.png" width="220" height="70" alt="">
            </a>
        </div>

        <!-- select-what-where -->
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>
                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn btn-primary search-btn">
                    <i class="fa-magnifying-glass fa-solid"></i>
                </button>
            </div>
        </div>

        <!-- nav-buttons -->
        <ul class="nav-btns me-3">
            <button class="btn btn-outline-light career-nav-link">
                <a href="career.html">
                    Career
                </a>
            </button>
            <!-- <button class="btn btn-outline-light btn-primary">
                <a href="pricing-plan.html">
                    <i class="fa-circle-plus fa-solid"></i>
                    Add Listing
                </a>
            </button> -->
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
        <i class="fa-bars fa-solid menu-open"></i>
        <i class="fa-solid fa-xmark menu-close"></i>
    </header>


    <!-- Filter Buttons -->
    <div class="filter-buttons">
        <button class="filter-btn active" data-filter="all">All</button>
        <button class="filter-btn" data-filter="monthly">Monthly</button>
        <button class="filter-btn" data-filter="yearly">Yearly</button>
        <button class="filter-btn" data-filter="custom">Custom</button>
    </div>

    <!-- Pricing Cards -->
    <div class="pricing-section" id="pricing-cards">
        <div class="container">
            <div class="plan-wrapper">
                <?php foreach ($allPlans as $plan): ?>
                    <?php echo getCard($plan); ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Enquiry Modal -->
    <div id="enquiryModal" style="display: none;">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h3>Enquiry Form</h3>
            <form method="POST" action="connect/enquiry.php">
                <input type="hidden" name="planId" id="hiddenPlanId" value="">

                <label for="fullname">Full Name:</label>
                <input type="text" name="fullname" id="fullname" value="<?php echo htmlspecialchars($user_fullname_db); ?>" readonly>

                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user_email_db); ?>" readonly>

                <label for="phone">Phone:</label>
                <input type="tel" name="phone" id="phone" value="<?php echo htmlspecialchars($user_phone_db); ?>" readonly>

                <label for="category">Category:</label>
                <select name="category" id="category" required>
                    <option value="" selected disabled>--select business category--</option>
                    <option value="arts&entertainment">Arts & Entertainment</option>
                    <option value="automotive">Automotive</option>
                    <option value="beauty&spa">Beauty & Spa</option>
                    <option value="health&medical">Health & Medical</option>
                    <option value="hotels">Hotels</option>
                    <option value="italian">Italian</option>
                    <option value="Other">Other</option>
                </select>

                <label for="other_category">Other Category:</label>
                <input type="text" name="other_category" id="otherInput" placeholder="Please specify">

                <button type="submit">Submit</button>
            </form>
        </div>
    </div>

    <!-- custom pricing cards -->
    <div class="pricing-section tab-content" id="custom-cards">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3>Custom pricing cards</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste amet, sint eos dolorem
                        aspernatur in repellat obcaecati deserunt distinctio. Officiis incidunt dolorum quae.
                        Doloribus accusantium obcaecati saepe quos culpa, quisquam velit?</p>
                </div>
            </div>
        </div>
    </div>
    <!-- footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="copyright">Copyright © 2025 Bizvility</p>
                    <p class="developBy">Developed by Bizvility</p>
                    <div class="social-media">
                        <i class="fa-brands fa-square-facebook"></i>
                        <i class="fa-brands fa-square-x-twitter"></i>
                        <i class="fa-brands fa-square-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                        <i class="fa-solid fa-whiskey-glass"></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const continueButtons = document.querySelectorAll(".openEnquiryModal");
            const enquiryModal = document.getElementById("enquiryModal");
            const hiddenPlanInput = document.getElementById("hiddenPlanId");
            const closeModalButton = document.querySelector(".close-modal");

            continueButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const planCard = button.closest(".plan-card");
                    const planId = planCard.getAttribute("data-plan-id");
                    const planPrice = parseInt(planCard.getAttribute("data-price"));
                    const planDuration = planCard.getAttribute("data-duration");

                    if (planPrice === 999 && planDuration === 'yearly') {
                        // Redirect to submitlisting.html
                        window.location.href = `submitlisting.php?plan_id=${planId}`;
                    } else {
                        // Open the enquiry modal
                        hiddenPlanInput.value = planId;
                        enquiryModal.style.display = "block";
                    }
                });
            });

            closeModalButton.addEventListener("click", function() {
                enquiryModal.style.display = "none";
            });
        });
        //filter
        document.addEventListener("DOMContentLoaded", function() {
            const filterButtons = document.querySelectorAll(".filter-btn");
            const planCards = document.querySelectorAll(".plan-card");

            // Filter functionality
            filterButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const filter = this.getAttribute("data-filter");

                    // Remove active class from all buttons
                    filterButtons.forEach(btn => btn.classList.remove("active"));
                    // Add active class to the clicked button
                    this.classList.add("active");

                    // Show/hide cards based on filter
                    planCards.forEach(card => {
                        const duration = card.getAttribute("data-duration");

                        if (filter === "all" || filter === duration) {
                            card.style.display = "block";
                        } else {
                            card.style.display = "none";
                        }
                    });
                });
            });

            // Modal functionality
            const continueButtons = document.querySelectorAll(".openEnquiryModal");
            const enquiryModal = document.getElementById("enquiryModal");
            const hiddenPlanInput = document.getElementById("hiddenPlanId");
            const closeModalButton = document.querySelector(".close-modal");

            continueButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const planCard = button.closest(".plan-card");
                    const planId = planCard.getAttribute("data-plan-id");
                    const planPrice = parseInt(planCard.getAttribute("data-price"));
                    const planDuration = planCard.getAttribute("data-duration");

                    if (planPrice === 999 && planDuration === 'yearly') {
                        // Redirect to submitlisting.html
                        window.location.href = "submitlisting.php";
                    } else {
                        // Open the enquiry modal
                        hiddenPlanInput.value = planId;
                        enquiryModal.style.display = "block";
                        document.body.classList.add("modal-open");
                    }
                });
            });

            closeModalButton.addEventListener("click", function() {
                enquiryModal.style.display = "none";
                document.body.classList.remove("modal-open");
            });

            // Close modal when clicking outside of it
            window.addEventListener("click", function(event) {
                if (event.target === enquiryModal) {
                    enquiryModal.style.display = "none";
                    document.body.classList.remove("modal-open");
                }
            });
        });
    </script>
</body>

</html>