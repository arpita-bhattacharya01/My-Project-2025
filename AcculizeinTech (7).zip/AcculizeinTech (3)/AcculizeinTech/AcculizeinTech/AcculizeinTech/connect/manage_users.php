<?php
session_start();
require 'config.php'; //database connection

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch all users
$query = $con->query("SELECT * FROM users WHERE user_type != 'admin'");

// Handle User Deletion
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $stmt = $con->prepare("DELETE FROM users WHERE user_id=?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        echo "<script>alert('User deleted successfully!'); window.location='manage_users.php';</script>";
    }
}

// Handle User Update
if (isset($_POST['update_user'])) {
    $user_id = $_POST['user_id'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $user_type = $_POST['user_type'];

    $stmt = $con->prepare("UPDATE users SET fullname=?, email=?, phone=?, city=?, state=?, pincode=?, user_type=? WHERE user_id=?");
    $stmt->bind_param("sssssssi", $fullname, $email, $phone, $city, $state, $pincode, $user_type, $user_id);
    if ($stmt->execute()) {
        echo "<script>alert('User updated successfully!'); window.location='manage_users.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
</head>
<body>
    <h2>Manage Users</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>City</th>
            <th>State</th>
            <th>Pincode</th>
            <th>user_type</th>
            <th>Actions</th>
        </tr>
        <?php while ($user = $query->fetch_assoc()) { ?>
            <tr>
                <form method="POST">
                    <td><?= $user['user_id']; ?></td>
                    <td><input type="text" name="fullname" value="<?= $user['fullname']; ?>"></td>
                    <td><input type="email" name="email" value="<?= $user['email']; ?>" readonly></td>
                    <td><input type="text" name="phone" value="<?= $user['phone']; ?>"></td>
                    <td><input type="text" name="city" value="<?= $user['city']; ?>"></td>
                    <td><input type="text" name="state" value="<?= $user['state']; ?>"></td>
                    <td><input type="text" name="pincode" value="<?= $user['pincode']; ?>"></td>
                    <td>
                        <select name="user_type">
                            <option value="user" <?= $user['user_type'] == 'user' ? 'selected' : ''; ?>>User</option>
                            <option value="sales" <?= $user['user_type'] == 'sales' ? 'selected' : ''; ?>>Sales</option>
                        </select>
                    </td>
                    <td>
                        <input type="hidden" name="user_id" value="<?= $user['user_id']; ?>">
                        <button type="submit" name="update_user">Update</button>
                        <button type="submit" name="delete_user">Delete</button>
                    </td>
                </form>
            </tr>
        <?php } ?>
    </table>
    <br>
    <a href="admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
