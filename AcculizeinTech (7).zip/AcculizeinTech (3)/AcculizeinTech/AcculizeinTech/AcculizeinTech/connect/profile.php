<?php
session_start();
// Retrieve the plan_id from the POST or GET request
if (isset($_GET['plan_id'])) {
    echo "<script>console.log('Plan ID from URL:', " . json_encode($_GET['plan_id']) . ");</script>";
} else {
    echo "<script>console.log('Plan ID is not set in the URL.');</script>";
}


// Retrieve the plan_id from the URL
$plan_id = isset($_GET['plan_id']) ? htmlspecialchars($_GET['plan_id']) : null;
// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = htmlspecialchars($_POST['name'] ?? 'N/A');
    $geoLocation = htmlspecialchars($_POST['geoLocation'] ?? 'N/A');
    $city = htmlspecialchars($_POST['city'] ?? 'N/A');
    $phone = htmlspecialchars($_POST['phone'] ?? 'N/A');
    $website = htmlspecialchars($_POST['website'] ?? 'N/A');
    $facebook = htmlspecialchars($_POST['facebook'] ?? 'N/A');
    $description = htmlspecialchars($_POST['description'] ?? 'N/A');

    // Handle uploaded files
    $logo = '';
    if (!empty($_FILES['logo']['name'])) {
        $logoDir = 'uploads/logo/';
        if (!is_dir($logoDir)) {
            mkdir($logoDir, 0777, true);
        }
        $logoName = time() . '_' . basename($_FILES['logo']['name']);
        $logoPath = $logoDir . $logoName;
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $logoPath)) {
            $logo = $logoPath;
        }
    }

    $images = [];
    if (!empty($_FILES['image']['name'][0])) {
        $imageDir = 'uploads/image/';
        if (!is_dir($imageDir)) {
            mkdir($imageDir, 0777, true);
        }
        foreach ($_FILES['image']['tmp_name'] as $key => $tmpName) {
            if (!empty($tmpName)) {
                $imageName = time() . '_' . basename($_FILES['image']['name'][$key]);
                $imagePath = $imageDir . $imageName;
                if (move_uploaded_file($tmpName, $imagePath)) {
                    $images[] = $imagePath;
                }
            }
        }
    }
} else {
    // Redirect back if accessed directly
    header("Location: submitlisting.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview Listing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<style>
    /* General Styles */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f9f9f9;
        color: #333;
        margin: 0;
        padding: 0;
    }

    h1, h3, h4 {
        color: #007bff;
    }

    a {
        color: #007bff;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    /* Navbar */
    .navbar {
        background-color: #007bff;
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: white;
    }

    .navbar .logo img {
        max-height: 50px;
    }
    .profile-logo img {
            width: 300px;
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
            margin-top: 20px;
        }

    .navbar button {
        background-color: #fff;
        color: #007bff;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .navbar button:hover {
        background-color: #0056b3;
        color: #fff;
    }

    /* Profile Section */
    .profile-logo img {
        width: 300px;
        height: 300px;
        object-fit: cover;
        border-radius: 10px;
        border: 5px solid #007bff;
        margin-bottom: 20px;
        position: relative;
        top: 20px;
    }

    .profile-logo p {
        font-size: 18px;
        color: #666;
    }

    h1.text-center {
        font-size: 2.5rem;
        font-weight: bold;
        margin-top: 20px;
    }

    p.mt-4 {
        font-size: 1.1rem;
        line-height: 1.6;
        color: #555;
    }

    /* Buttons */
    .d-flex button {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .d-flex button:hover {
        background-color: #0056b3;
    }

    .d-flex button:focus {
        outline: none;
    }

    /* Business Hours Table */
    table.table {
        width: 100%;
        margin-top: 20px;
        border-collapse: collapse;
        background-color: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    table.table th, table.table td {
        padding: 15px;
        text-align: center;
        border: 1px solid #ddd;
    }

    table.table th {
        background-color: #007bff;
        color: #fff;
        font-weight: bold;
    }

    table.table td {
        font-size: 1rem;
        color: #555;
    }

    /* Contact Information */
    h4 {
        margin-top: 30px;
        font-size: 1.5rem;
        font-weight: bold;
    }
    h1 {
            font-size: 2rem;
            font-weight: bold;
            color: #007bff;
            text-align: center;
        }

    p {
        font-size: 1rem;
        margin: 5px 0;
        text-align: center;
    }

    /* Gallery */
    .row.mt-5 h3 {
        font-size: 1.8rem;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .row.mt-5 .col-lg-3 img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .row.mt-5 .col-lg-3 img:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    /* Footer */
    footer {
        background-color: #007bff;
        color: white;
        padding: 20px 0;
        text-align: center;
    }

    footer p {
        margin: 5px 0;
    }

    footer .social-media i {
        font-size: 20px;
        margin: 0 10px;
        color: white;
        transition: color 0.3s ease;
    }

    footer .social-media i:hover {
        color: #0056b3;
    }
</style>

<body>
    <!-- Navbar -->
    <header class="navbar navbar-2">
        <div class="logo ms-2">
            <a href="index.html">
                <img src="../assets/imgs/logo.png" width="220" height="70" alt="">
            </a>
        </div>
        <!-- Publish Button -->
<form action="connect/payment.php" method="POST">
    <input type="hidden" name="plan_id" value="<?php echo htmlspecialchars($plan_id); ?>">
    <button type="submit" class="btn btn-primary" style="margin-right: 20px;">Publish</button>
</form>
        
        <!-- <button class="btn btn-primary" style="margin-right: 20px;">Publish</button> -->
    </header>

    <!-- Profile Section -->
    <div class="container mt-5">
        <div class="row">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- Business Logo -->
                <div class="profile-logo text-center mb-4">
                    <?php if ($logo): ?>
                        <img src="<?php echo $logo; ?>" alt="Business Logo" class="img-fluid" style="width: 300px; height: 300px; object-fit: cover; border-radius: 10px;">
                    <?php else: ?>
                        <p>No logo uploaded</p>
                    <?php endif; ?>
                </div>

                <!-- Listing Title -->
                <h1 class="text-center mt-3"><?php echo $name; ?></h1>

                <!-- Description -->
                <p class="mt-4"><?php echo $description; ?></p>

                <!-- Buttons -->
                <div class="d-flex justify-content-center mt-4">
                    <button class="btn btn-outline-primary mx-2">Photos</button>
                    <button class="btn btn-outline-primary mx-2">Videos</button>
                    <button class="btn btn-outline-primary mx-2">Services</button>
                    <button class="btn btn-outline-primary mx-2">Reviews</button>
                </div>
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <!-- Business Hours -->
                <h4>Business Hours</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Day</th>
                            <th>Opening</th>
                            <th>Closing</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Monday</td>
                            <td>09:00 AM</td>
                            <td>05:00 PM</td>
                        </tr>
                        <tr>
                            <td>Tuesday</td>
                            <td>09:00 AM</td>
                            <td>05:00 PM</td>
                        </tr>
                        <tr>
                            <td>Wednesday</td>
                            <td>09:00 AM</td>
                            <td>05:00 PM</td>
                        </tr>
                        <tr>
                            <td>Thursday</td>
                            <td>09:00 AM</td>
                            <td>05:00 PM</td>
                        </tr>
                        <tr>
                            <td>Friday</td>
                            <td>09:00 AM</td>
                            <td>05:00 PM</td>
                        </tr>
                    </tbody>
                </table>

                <!-- Contact Information -->
                <h4>Contact Information</h4>
                <p><strong>Phone:</strong> <?php echo $phone; ?></p>
                <p><strong>Address:</strong> <?php echo $geoLocation; ?>, <?php echo $city; ?></p>
                <p><strong>Website:</strong> <a href="<?php echo $website; ?>" target="_blank"><?php echo $website; ?></a></p>
                <p><strong>Facebook:</strong> <a href="<?php echo $facebook; ?>" target="_blank"><?php echo $facebook; ?></a></p>

                <!-- Other Details -->
                <h4>Other Details</h4>
                <p><strong>Gender:</strong> Male</p>
            </div>
        </div>

        <!-- Gallery -->
        <div class="row mt-5">
            <h3>Gallery</h3>
            <?php if (!empty($images)): ?>
                <?php foreach ($images as $image): ?>
                    <div class="col-lg-3">
                        <img src="<?php echo $image; ?>" alt="Business Image" class="img-fluid" style="width: 100%; height: 200px; object-fit: cover; border-radius: 10px;">
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No images uploaded</p>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
         const urlParams = new URLSearchParams(window.location.search);

// Retrieve the plan_id from the query parameters
const planId = urlParams.get('plan_id');

// Log the plan_id to the console
console.log('Plan ID:', planId);

// Optional: Display the plan_id in an alert (for testing purposes)
if (planId) {
    // alert('Plan ID: ' + planId);
}
    </script>
</body>


</html>