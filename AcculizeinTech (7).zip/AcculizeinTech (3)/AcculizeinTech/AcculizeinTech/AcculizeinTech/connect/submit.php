<?php
include_once 'config.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $business_category = $_POST['business_category'];
    $other_category = isset($_POST['other_category']) ? $_POST['other_category'] : null;
    $approval_status = 'pending'; // Default status

    $sql = "INSERT INTO users (fullname, phone, email, business_category, other_category, approval_status) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $fullname, $phone, $email, $business_category, $other_category, $approval_status);

    if ($stmt->execute()) {
        echo "<script>
                alert('Submission successful! Waiting for admin approval.');
                window.location.href = 'thank-you.php';
              </script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
