<?php
$conn = new mysqli("localhost", "root", "", "business_enquiries");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM contact_messages ORDER BY created_at DESC";
$result = $conn->query($sql);

echo "<h2>Contact Messages</h2>";
while ($row = $result->fetch_assoc()) {
    echo "<p><strong>Name:</strong> " . $row['name'] . "</p>";
    echo "<p><strong>Email:</strong> " . $row['email'] . "</p>";
    echo "<p><strong>Phone:</strong> " . $row['phone'] . "</p>";
    echo "<p><strong>Message:</strong> " . $row['message'] . "</p>";
    echo "<hr>";
}

$conn->close();
?>
