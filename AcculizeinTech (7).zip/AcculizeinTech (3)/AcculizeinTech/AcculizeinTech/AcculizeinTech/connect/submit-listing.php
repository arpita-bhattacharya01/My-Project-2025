<?php
include 'config.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    // Sanitize form inputs
    $listingTitle = mysqli_real_escape_string($conn, $_POST['listingTitle']);
    $tagline = isset($_POST['tagline']) ? mysqli_real_escape_string($conn, $_POST['tagline']) : null;

    // Insert into database
    $sql = "INSERT INTO listings (listingTitle, tagline) VALUES ('$listingTitle', '$tagline')";

    if ($conn->query($sql) === TRUE) {
        echo "New listing submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data and sanitize it
    $geoLocation = isset($_POST['geoLocation']) ? mysqli_real_escape_string($conn, $_POST['geoLocation']) : null;
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $latitude = isset($_POST['latitude']) ? mysqli_real_escape_string($conn, $_POST['latitude']) : null;
    $longitude = isset($_POST['longitude']) ? mysqli_real_escape_string($conn, $_POST['longitude']) : null;
    $pinLocation = isset($_POST['pinLocation']) ? mysqli_real_escape_string($conn, $_POST['pinLocation']) : null;

    // Prepare the SQL query to insert data into the table
    $sql = "INSERT INTO listings (geoLocation, city, phone, latitude, longitude, pinLocation)
            VALUES ('$geoLocation', '$city', '$phone', '$latitude', '$longitude', '$pinLocation')";

    // Execute the query and check if it was successful
    if ($conn->query($sql) === TRUE) {
        echo "New listing submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
    // Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize input data from the form
    $category = isset($_POST['category']) ? mysqli_real_escape_string($conn, $_POST['category']) : null;
    $delivery = isset($_POST['delivery']) ? 1 : 0;
    $takeout = isset($_POST['takeout']) ? 1 : 0;
    $air_conditioning = isset($_POST['air_conditioning']) ? 1 : 0;
    $dog_allowed = isset($_POST['dog_allowed']) ? 1 : 0;
    $twenty_four_hours_open = isset($_POST['24hours_open']) ? 1 : 0;
    $wheelchair_accessible = isset($_POST['wheelchair_accessible']) ? 1 : 0;
     
    // Prepare the SQL query to insert data into the listings table
    $sql = "INSERT INTO listings (category, delivery, takeout, air_conditioning, dog_allowed, twenty_four_hours_open, wheelchair_accessible)
            VALUES ('$category', '$delivery', '$takeout', '$air_conditioning', '$dog_allowed', '$twenty_four_hours_open', '$wheelchair_accessible')";

    // Execute the query and check if it was successful
    if ($conn->query($sql) === TRUE) {
        echo "New listing submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

    // Capture and sanitize input
$geoLocation = mysqli_real_escape_string($conn, $_POST['geoLocation']);
$latitude = mysqli_real_escape_string($conn, $_POST['latitude']);
$longitude = mysqli_real_escape_string($conn, $_POST['longitude']);
$pinLocation = mysqli_real_escape_string($conn, $_POST['pinLocation']);

// Insert into database
$sql = "INSERT INTO listings (geoLocation, latitude, longitude, pinLocation) 
        VALUES ('$geoLocation', '$latitude', '$longitude', '$pinLocation')";


// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Sanitize input data from the form
    $gender = isset($_POST['gender']) ? mysqli_real_escape_string($conn, $_POST['gender']) : null;
    $payment_methods = isset($_POST['payment_method']) ? implode(", ", $_POST['payment_method']) : null;
    $price_range = isset($_POST['price_range']) ? mysqli_real_escape_string($conn, $_POST['price_range']) : null;
    $price_from = isset($_POST['price_from']) ? mysqli_real_escape_string($conn, $_POST['price_from']) : null;
    $price_to = isset($_POST['price_to']) ? mysqli_real_escape_string($conn, $_POST['price_to']) : null;

    // Prepare the SQL query to insert data into the listings table
    $sql = "INSERT INTO listings (gender, payment_methods, price_range, price_from, price_to)
            VALUES ('$gender', '$payment_methods', '$price_range', '$price_from', '$price_to')";

    // Execute the query and check if it was successful
    if ($conn->query($sql) === TRUE) {
        echo "New listing submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Sanitize input data from the form
    $gender = isset($_POST['gender']) ? mysqli_real_escape_string($conn, $_POST['gender']) : null;
    $payment_methods = isset($_POST['payment_method']) ? implode(", ", $_POST['payment_method']) : null;
    $price_range = isset($_POST['price_range']) ? mysqli_real_escape_string($conn, $_POST['price_range']) : null;
    $price_from = isset($_POST['price_from']) ? mysqli_real_escape_string($conn, $_POST['price_from']) : null;
    $price_to = isset($_POST['price_to']) ? mysqli_real_escape_string($conn, $_POST['price_to']) : null;

    // Business Hours (Monday - Friday)
    $business_hours = [
        'monday' => ['start' => $_POST['monday_start'], 'end' => $_POST['monday_end']],
        'tuesday' => ['start' => $_POST['tuesday_start'], 'end' => $_POST['tuesday_end']],
        'wednesday' => ['start' => $_POST['wednesday_start'], 'end' => $_POST['wednesday_end']],
        'thursday' => ['start' => $_POST['thursday_start'], 'end' => $_POST['thursday_end']],
        'friday' => ['start' => $_POST['friday_start'], 'end' => $_POST['friday_end']],
        'saturday' => ['start' => $_POST['saturday_start'], 'end' => $_POST['saturday_end']],
        'sunday' => ['start' => $_POST['sunday_start'], 'end' => $_POST['sunday_end']],
    ];

    // Prepare the SQL query to insert data into the listings table
    $sql = "INSERT INTO listings (gender, payment_methods, price_range, price_from, price_to, business_hours)
            VALUES ('$gender', '$payment_methods', '$price_range', '$price_from', '$price_to', '" . json_encode($business_hours) . "')";

    // Execute the query and check if it was successful
    if ($conn->query($sql) === TRUE) {
        echo "New listing submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the values from the form
    $weekday = $_POST['weekdays'];
    $start_time = $_POST['day-start'];
    $end_time = $_POST['day-end'];
    $is_24hours = isset($_POST['24-hours-work']) ? 1 : 0;

    // Validate the inputs
    if (!empty($weekday) && !empty($start_time) && !empty($end_time)) {
        // Prepare SQL query to insert the data into the database
        $sql = "INSERT INTO business_hours (weekday, start_time, end_time, is_24hours) 
                VALUES (?, ?, ?, ?)";

        if ($stmt = $conn->prepare($sql)) {
            // Bind the parameters to the SQL query
            $stmt->bind_param("sssi", $weekday, $start_time, $end_time, $is_24hours);

            // Execute the statement
            if ($stmt->execute()) {
                echo "Business hours added successfully.";
            } else {
                echo "Error: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "All fields are required.";
    }
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Social Media Data
    if (isset($_POST['category']) && isset($_POST['choose-social-media'])) {
        $category = $_POST['category'];
        $link = $_POST['choose-social-media'];

        // Validate the inputs
        if (!empty($category) && !empty($link)) {
            // Prepare SQL query to insert social media data into the database
            $sql = "INSERT INTO social_media (category, link) VALUES (?, ?)";

            if ($stmt = $conn->prepare($sql)) {
                // Bind the parameters to the SQL query
                $stmt->bind_param("ss", $category, $link);

                // Execute the statement
                if ($stmt->execute()) {
                    echo "Social media link added successfully.";
                } else {
                    echo "Error: " . $stmt->error;
                }

                // Close the statement
                $stmt->close();
            } else {
                echo "Error: " . $conn->error;
            }
        } else {
            echo "All fields for social media are required.";
        }
    }

    // 2. Frequently Asked Questions (FAQs)
    if (isset($_POST['faq']) && isset($_POST['faq-answer'])) {
        $faq_question = $_POST['faq'];
        $faq_answer = $_POST['faq-answer'];

        // Validate the inputs
        if (!empty($faq_question) && !empty($faq_answer)) {
            // Prepare SQL query to insert FAQ data into the database
            $sql_faq = "INSERT INTO faqs (question, answer) VALUES (?, ?)";

            if ($stmt_faq = $conn->prepare($sql_faq)) {
                // Bind the parameters to the SQL query
                $stmt_faq->bind_param("ss", $faq_question, $faq_answer);

                // Execute the statement
                if ($stmt_faq->execute()) {
                    echo "FAQ added successfully.";
                } else {
                    echo "Error: " . $stmt_faq->error;
                }

                // Close the statement
                $stmt_faq->close();
            } else {
                echo "Error: " . $conn->error;
            }
        } else {
            echo "FAQ question and answer are required.";
        }
    }
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Handle the description
    if (isset($_POST['description'])) {
        $description = $_POST['description'];
    } else {
        $description = ''; // Empty if not set
    }

    // 2. Handle tags (keywords)
    if (isset($_POST['tags-keywords'])) {
        $tags = $_POST['tags-keywords'];
    } else {
        $tags = ''; // Empty if not set
    }

    // 3. Handle video link (optional)
    if (isset($_POST['video-link'])) {
        $video_link = $_POST['video-link'];
    } else {
        $video_link = ''; // Empty if not set
    }

    // 4. Handle file uploads (images)
    $image_links = [];

    if (isset($_FILES['image-files']) && !empty($_FILES['image-files']['name'][0])) {
        $upload_dir = 'uploads/'; // Directory to save images
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_count = count($_FILES['image-files']['name']);

        // Loop through all uploaded files
        for ($i = 0; $i < $file_count; $i++) {
            $file_name = $_FILES['image-files']['name'][$i];
            $file_tmp = $_FILES['image-files']['tmp_name'][$i];
            $file_size = $_FILES['image-files']['size'][$i];
            $file_error = $_FILES['image-files']['error'][$i];

            // Validate the file (you can add more validations here)
            if ($file_error === UPLOAD_ERR_OK) {
                $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
                $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];

                if (in_array(strtolower($file_ext), $allowed_exts)) {
                    $new_file_name = uniqid() . '.' . $file_ext;
                    $file_path = $upload_dir . $new_file_name;

                    // Move the uploaded file to the desired location
                    if (move_uploaded_file($file_tmp, $file_path)) {
                        // Add the image path to the array
                        $image_links[] = $file_path;
                    }
                }
            }
        }
    }

    // Convert the image links array to a JSON string to store in the database
    $image_links_json = json_encode($image_links);

    // Insert the data into the database
    $sql = "INSERT INTO business_info (description, tags, video_link, image_links) VALUES (?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssss", $description, $tags, $video_link, $image_links_json);

        if ($stmt->execute()) {
            echo "Business info saved successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get form data
    $description = $_POST['description'];
    $tags = $_POST['tags-keywords'];
    $video_link = $_POST['video-link'];
    $email = $_POST['email-for-signUp'];
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Handle file uploads
    if (isset($_FILES['image'])) {
        $image_files = $_FILES['image'];
        // Process uploaded images
        foreach ($image_files['tmp_name'] as $key => $tmp_name) {
            $file_name = $image_files['name'][$key];
            $file_tmp = $image_files['tmp_name'][$key];
            // Move the uploaded file to your desired directory
            move_uploaded_file($file_tmp, "uploads/" . $file_name);
        }
    }

    // Handle the business logo file
    if (isset($_FILES['business-logo'])) {
        $logo = $_FILES['business-logo'];
        // Process uploaded logo
        $logo_name = $logo['name'];
        $logo_tmp = $logo['tmp_name'];
        move_uploaded_file($logo_tmp, "uploads/" . $logo_name);
    }

    // Optionally, save the data to a database, send email, etc.

    // Output for testing
    echo "Form submitted successfully!<br>";
    echo "Description: " . $description . "<br>";
    echo "Tags: " . $tags . "<br>";
    echo "Video Link: " . $video_link . "<br>";
    echo "Email: " . $email . "<br>";
    echo "Username: " . $username . "<br>";
    echo "Password: " . $password . "<br>";
}



    // Close connection
    $conn->close();
}

?>
