<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enquiry Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
            text-align: center;
        }
        form {
            display: inline-block;
            text-align: left;
            background: #f8f8f8;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px gray;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h2>Enquiry Form</h2>
    <form action="submit.php" method="post">
        <label>Full Name:</label>
        <input type="text" name="fullname" required>

        <label>Mobile No.:</label>
        <input type="text" name="phone" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Business Category:</label>
        <select name="business_category" required>
            <option value="">--Select Business Category--</option>
            <option value="IT Services">IT Services</option>
            <option value="Retail">Retail</option>
            <option value="Healthcare">Healthcare</option>
            <option value="Education">Education</option>
        </select>

        <button type="submit">Submit</button>
    </form>

</body>
</html> -->

<?php include 'config.php';

$result=mysqli_query($conn, "select * from doctors order by id desc");
echo "<h2>Exclusive & Popular</h2>";
while($row=mysqli_fetch_assoc($result)){
    echo "<div class='doctor'>";
    echo "<img src='uploads/".$row['image']";
    
}