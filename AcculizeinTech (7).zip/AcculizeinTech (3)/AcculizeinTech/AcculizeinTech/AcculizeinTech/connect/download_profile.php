<?php
require('fpdf.php'); // Include FPDF Library
//require 'path/to/fpdf.php';
session_start();
require 'config.php'; //database connection


if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(40, 10, "User Profile");
// Save the PDF to a file
$pdf->Output('F', 'filename.pdf');

// Output the PDF to the browser
$pdf->Output('I');

$pdf->Ln();
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 10, "Name: " . $user['first_name'] . " " . $user['last_name']);
$pdf->Ln();
$pdf->Cell(40, 10, "Email: " . $user['email']);
$pdf->Ln();
$pdf->Cell(40, 10, "Phone: " . $user['phone']);
$pdf->Ln();
$pdf->Cell(40, 10, "Address: " . $user['address1']);

$pdf->Output();
?>
