<?php
session_start();
include '../session_check.php';
include '../connect/config.php';

// Check if user is logged in via session or cookie
if (!isset($_SESSION['user_id'])) {
    if (isset($_COOKIE['remember_me'])) {
        $token = $_COOKIE['remember_me'];
        $query = "SELECT user_id, fullname, email, user_type FROM users WHERE remember_token = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['fullname'] = $row['fullname'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['user_type'] = $row['user_type'];
            session_regenerate_id(true);

            // Refresh the cookie expiration time
            setcookie("remember_me", $token, time() + (86400 * 30), "/", "", true, true);
        }
    }
}

// Ensure the user is logged in and is a sales user
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'sales') {
    header("Location: login.php");
    exit();
}

// Get sales user details
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $con->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header("Location: logout.php"); // Logout if user not found
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sales Dashboard</title>
    <link rel="stylesheet" href="libs/bower/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css">
    <link rel="stylesheet" href="libs/bower/animate.css/animate.min.css">
    <link rel="stylesheet" href="libs/bower/fullcalendar/dist/fullcalendar.min.css">
    <link rel="stylesheet" href="libs/bower/perfect-scrollbar/css/perfect-scrollbar.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/core.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
    <script src="libs/bower/breakpoints.js/dist/breakpoints.min.js"></script>
    <script> Breakpoints(); </script>
</head>

<body class="menubar-left menubar-unfold menubar-light theme-primary">

<main id="app-main" class="app-main">
    <div class="wrap">
        <section class="app-content">
            <h1>Welcome to the Sales Dashboard, <?php echo htmlspecialchars($_SESSION['fullname']); ?>!</h1>
            
            <div class="row">
                <!-- Profile Section -->
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Your Profile</h3>
                        </div>
                        <div class="panel-body">
                            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['fullname']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                            <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone']); ?></p>
                            <p><strong>City:</strong> <?php echo htmlspecialchars($user['city']); ?></p>
                            <p><strong>State:</strong> <?php echo htmlspecialchars($user['state']); ?></p>
                            <p><strong>Pincode:</strong> <?php echo htmlspecialchars($user['pincode']); ?></p>
                            <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                            <a href="sales_profile.php" class="btn btn-primary">Edit Profile</a>
                        </div>
                    </div>
                </div>

                <!-- New Users Widget -->
                <div class="col-md-6 col-sm-6">
                    <div class="widget stats-widget">
                        <div class="widget-body clearfix">
                            <?php 
                                $sql = "SELECT COUNT(*) FROM users WHERE approval_status IS NULL AND user_id = ?";
                                $stmt = $con->prepare($sql);
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $stmt->bind_result($totnewapt);
                                $stmt->fetch();
                                $stmt->close();
                            ?>
                            <div class="pull-left">
                                <h3 class="widget-title text-warning"><span class="counter"><?php echo $totnewapt; ?></span></h3>
                                <small class="text-color">New Users</small>
                            </div>
                            <span class="pull-right big-icon watermark"><i class="fa fa-paperclip"></i></span>
                        </div>
                        <footer class="widget-footer bg-warning">
                            <a href="user_profile.php"><small> View Profile</small></a>
                        </footer>
                    </div>
                </div>

                <!-- Total Sales Widget -->
                <div class="col-md-6 col-sm-6">
                    <div class="widget stats-widget">
                        <div class="widget-body clearfix">
                            <?php 
                                $sql = "SELECT COUNT(*) FROM sales_team WHERE user_id = ?";
                                $stmt = $con->prepare($sql);
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $stmt->bind_result($totsale);
                                $stmt->fetch();
                                $stmt->close();
                            ?>
                            <div class="pull-left">
                                <h3 class="widget-title text-primary"><span class="counter"><?php echo $totsale; ?></span></h3>
                                <small class="text-color">Total Sales</small>
                            </div>
                            <span class="pull-right big-icon watermark"><i class="fa fa-file-text-o"></i></span>
                        </div>
                        <footer class="widget-footer bg-primary">
                            <a href="all-appointment.php"><small> View Detail</small></a>
                        </footer>
                    </div>
                </div>
            </div><!-- .row -->
        </section>
    </div>
</main>

<?php include('./profile.php');?>

<script src="libs/bower/jquery/dist/jquery.js"></script>
<script src="libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
<script src="libs/bower/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="assets/js/library.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/app.js"></script>
<script src="libs/bower/fullcalendar/dist/fullcalendar.min.js"></script>
<script src="assets/js/fullcalendar.js"></script>

</body>
</html>
