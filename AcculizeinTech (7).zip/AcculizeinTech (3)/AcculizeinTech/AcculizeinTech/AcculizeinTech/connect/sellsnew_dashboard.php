<?php
session_start();
include 'config.php'; // Database connection file

// Check if user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['user_type'])) {
    header("Location: signin.php");
    exit();
}

$user_id = $_SESSION['id'];
$user_type = $_SESSION['user_type']; // Fetch user_type from session

$query = $conn->prepare("SELECT * FROM users WHERE id = ? AND user_type = ?");
$query->bind_param("is", $user_id, $user_type);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();
$query->close();

// Redirect if user_type does not match expected type
if (!$user) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sales Dashboard</title>
    <link rel="stylesheet" href="libs/bower/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css">
    <link rel="stylesheet" href="libs/bower/animate.css/animate.min.css">
    <link rel="stylesheet" href="libs/bower/fullcalendar/dist/fullcalendar.min.css">
    <link rel="stylesheet" href="libs/bower/perfect-scrollbar/css/perfect-scrollbar.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/core.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
    <script src="libs/bower/breakpoints.js/dist/breakpoints.min.js"></script>
    <script> Breakpoints(); </script>
</head>

<body class="menubar-left menubar-unfold menubar-light theme-primary">

<main id="app-main" class="app-main">
    <div class="wrap">
        <section class="app-content">
            <h1>Welcome to the Sales Dashboard, <?php echo htmlspecialchars($_SESSION['fullname']); ?>!</h1>
            
            <div class="row">
                <!-- Profile Section -->
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Your Profile</h3>
                        </div>
                        <div class="panel-body">
                            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['fullname']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                            <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone']); ?></p>
                            <p><strong>City:</strong> <?php echo htmlspecialchars($user['city']); ?></p>
                            <p><strong>State:</strong> <?php echo htmlspecialchars($user['state']); ?></p>
                            <p><strong>Pincode:</strong> <?php echo htmlspecialchars($user['pincode']); ?></p>
                            <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                            <a href="sales_profile.php" class="btn btn-primary">Edit Profile</a>
                            <li><a href="logout.php">Logout</a></li>
                        </div>
                    </div>
                </div>

                <!-- New Users Widget -->
                <div class="col-md-6 col-sm-6">
                    <div class="widget stats-widget">
                        <div class="widget-body clearfix">
                            <?php 
                                $sql = "SELECT COUNT(*) FROM enquiry WHERE approval_status IS NULL AND id = ?";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $stmt->bind_result($totnewapt);
                                $stmt->fetch();
                                $stmt->close();
                            ?>
                            <div class="pull-left">
                                <h3 class="widget-title text-warning"><span class="counter"><?php echo $totnewapt; ?></span></h3>
                                <small class="text-color">New Users</small>
                            </div>
                            <span class="pull-right big-icon watermark"><i class="fa fa-paperclip"></i></span>
                        </div>
                        <footer class="widget-footer bg-warning">
                            <a href="user_profile.php"><small> View Profile</small></a>
                        </footer>
                    </div>
                </div>

                <!-- Total Sales Widget -->
                <div class="col-md-6 col-sm-6">
                    <div class="widget stats-widget">
                        <div class="widget-body clearfix">
                            <?php 
                                $sql = "SELECT COUNT(*) FROM sales_team WHERE user_id = ?";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $stmt->bind_result($totsale);
                                $stmt->fetch();
                                $stmt->close();
                            ?>
                            <div class="pull-left">
                                <h3 class="widget-title text-primary"><span class="counter"><?php echo $totsale; ?></span></h3>
                                <small class="text-color">Total Sales</small>
                            </div>
                            <span class="pull-right big-icon watermark"><i class="fa fa-file-text-o"></i></span>
                        </div>
                        <footer class="widget-footer bg-primary">
                            <a href="all-appointment.php"><small> View Detail</small></a>
                        </footer>
                    </div>
                </div>
            </div><!-- .row -->
        </section>
    </div>
</main>

<?php include('./profile.php');?>

<script src="libs/bower/jquery/dist/jquery.js"></script>
<script src="libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
<script src="libs/bower/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="assets/js/library.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/app.js"></script>
<script src="libs/bower/fullcalendar/dist/fullcalendar.min.js"></script>
<script src="assets/js/fullcalendar.js"></script>

</body>
</html>
