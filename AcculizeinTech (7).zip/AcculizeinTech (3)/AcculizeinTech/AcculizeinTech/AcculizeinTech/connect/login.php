<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'config.php'; //database connection


if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Function to redirect users based on user type
// function redirectToDashboard($user_type) {
//     $dashboardPages = [
//         "sales" => "connect/sales_dashboard.php",
//         "user" => "connect/user_dashboard.php",
//         "admin" => "connect/admin_dashboard.php"
//     ];
    
//     if (isset($dashboardPages[$user_type])) {
//         header("Location: " . $dashboardPages[$user_type]);
//         exit();
//     }
//     header("Location: login.php");
//     exit();
// }

// // If user is already logged in, redirect to dashboard
// if (isset($_SESSION['user_id']) && isset($_SESSION['user_type'])) {
//     redirectToDashboard($_SESSION['user_type']);
// }

$error_message = "";

// Handle login via form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $emailOrUsername = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $remember = isset($_POST['chk']);

    if (empty($emailOrUsername) || empty($password)) {
        $error_message = "<p style='color:red; text-align:center;'>Both fields are required.</p>";
    } else {
        $query = "SELECT `user_id`, `fullname`, `email`, `username`, `password`, `user_type` FROM `users` WHERE `email` = ? OR `username` = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        

        $stmt->bind_param("ss", $emailOrUsername, $emailOrUsername);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['fullname'] = $row['fullname'];
                $_SESSION['email'] = $row['email'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['user_type'] = $row['user_type']; // Updated to user_type
                $_SESSION['LAST_ACTIVE_TIME'] = time();
                session_regenerate_id(true);

                // Update last login time
                $updateQuery = "UPDATE users SET last_login = NOW() WHERE user_id = ?";
                $updateStmt = $conn->prepare($updateQuery);
                $updateStmt->bind_param("i", $row['user_id']);
                $updateStmt->execute();

                // Remember Me (Set Cookies)
                if ($remember) {
                    setcookie("username", $emailOrUsername, time() + (86400 * 30), "/");
                    setcookie("user_id", $row['user_id'], time() + (86400 * 30), "/");
                } else {
                    setcookie("username", "", time() - 3600, "/");
                    setcookie("user_id", "", time() - 3600, "/");
                }

                // redirectToDashboard($row['user_type']);
            } else {
                $error_message = "<p style='color:red; text-align:center;'>Incorrect password!</p>";
            }
        } else {
            $error_message = "<p style='color:red; text-align:center;'>User not found. <a href='signup.php'>Sign up here</a></p>";
        }
        $stmt->close();
    }
}

// Logout logic
if (isset($_GET['logout'])) {
    session_destroy();
    setcookie("user_id", "", time() - 3600, "/");
    header("Location: login.php");
    exit();
}

// JSON API Login Support
$json = file_get_contents("php://input");
$data = json_decode($json, true);
$response = ["success" => false, "message" => "Invalid request"];

if ($data && isset($data["action"]) && $data["action"] === "login") {
    $email = trim($data["email"] ?? "");
    $password = trim($data["password"] ?? "");

    if (!empty($email) && !empty($password)) {
        $query = "SELECT user_id, fullname, email, username, password, user_type FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                if (password_verify($password, $row["password"])) {
                    $_SESSION["loggedin"] = true;
                    $_SESSION["user_id"] = $row["user_id"];
                    $_SESSION["fullname"] = $row["fullname"];
                    $_SESSION["email"] = $row["email"];
                    $_SESSION["username"] = $row["username"];
                    $_SESSION["user_type"] = $row["user_type"];

                    $response = [
                        "success" => true,
                        "message" => "Login successful",
                        "user" => $row
                    ];
                } else {
                    $response["message"] = "Invalid email or password.";
                }
            } else {
                $response["message"] = "Invalid email or password.";
            }
            $stmt->close();
        }
    } else {
        $response["message"] = "Email and password are required.";
    }
    header("Content-Type: application/json");
    echo json_encode($response);
    exit();
}
?>
