<?php
session_start();
require_once 'config.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['user_type'])) {
    header("Location: signin.php");
    exit;
} 

$user_id = $_SESSION['id'];
$user_type = $_SESSION['user_type'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Store user details in session
$_SESSION['fullname'] = $user['fullname'];
$_SESSION['phone'] = $user['phone'];
$_SESSION['city'] = $user['city']; // Ensure city is stored
$_SESSION['state'] = $user['state'];
$_SESSION['pincode'] = $user['pincode'];
$_SESSION['country'] = $user['country'];
$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name'] = $user['last_name'];
$_SESSION['about'] = $user['about'];
$_SESSION['facebook'] = $user['facebook'];
$_SESSION['instagram'] = $user['instagram'];
$_SESSION['twitter'] = $user['twitter'];
$_SESSION['linkedin'] = $user['linkedin'];
$_SESSION['pinterest'] = $user['pinterest'];
$_SESSION['address_line_1'] = $user['address_line_1'];
$_SESSION['address_line_2'] = $user['address_line_2'];
$_SESSION['image'] = $user['image'];

// Modified SQL query to join tables
$stmt2 = $conn->prepare("SELECT 
        e.*, 
        u.fullname, 
        u.email, 
        u.phone, 
        u.image,
        p.title AS plan_title,
        p.price AS plan_price,
        p.duration AS plan_duration
    FROM enquiry e
    LEFT JOIN users u ON e.user_id = u.id
    LEFT JOIN plans p ON e.plan_id = p.id");
$stmt2->execute();
$enquiries = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt2->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Update</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            background-color: #f8f9fa;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #1c1f26;
            color: white;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            position: fixed;
            left: 0;
            top: 0;
            transition: width 0.3s ease-in-out;
            overflow: hidden;
        }

        .sidebar.collapsed {
            width: 70px;
        }

        /* Sidebar Header */
        .sidebar-header {
            background: blue;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .sidebar-header .logo {
            display: flex;
            align-items: center;
        }

        .sidebar-header .logo img {
            width: 160px;
            height: auto;
            transition: opacity 0.3s ease-in-out;
        }

        .sidebar.collapsed .sidebar-header .logo {
            display: none;
        }

        .hamburger {
            font-size: 24px;
            cursor: pointer;
            color: white;
            transition: transform 0.3s;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            width: 100%;
            margin-top: 20px;
        }

        .sidebar ul li {
            padding: 15px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            transition: background 0.3s;
        }

        .sidebar ul li:hover {
            background: #32363d;
        }

        .sidebar ul li i {
            font-size: 18px;
        }

        .sidebar.collapsed ul li span {
            display: none;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            width: calc(100% - 250px);
            padding: 20px;
            transition: margin-left 0.3s;
        }

        .main-content.expanded {
            margin-left: 70px;
            width: calc(100% - 70px);
        }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            background: white;
            padding: 15px 20px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Nav Links */
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
            font-size: 14px;
        }

        .nav-links a {
            text-decoration: none;
            color: black;
        }

        /* Profile Section */
        .leftdata {
            display: flex;
            align-items: center;
        }

        .leftdata img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ddd;
        }

        /* Hamburger Icon */
        .hamburger {
            font-size: 24px;
            cursor: pointer;
            color: black;
        }

        /* Profile Update Section */
        .container {
            width: 100%;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .container-title {
            width: 100%;
            background-color: #ecf0ff;
            display: flex;
            justify-content: start;
            align-items: center;
            padding: 10px;
            margin-bottom: 20px;
        }

        .container-title h2 {
            font-size: 18px;
            color: #555;
        }

        .container-title-2 {
            background-color: transparent;
            margin-top: 40px;
            margin-bottom: 0;
        }

        .profile-pic {
            /* width: 100%; */
            display: flex;
            justify-content: start;
            align-items: start;
            gap: 50px;
            padding: 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid #ccc;
        }

        .profile-pic img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #ddd;
        } 

        .profile-pic .update-profile-text {
            display: flex;
            justify-content: start;
            align-items: start;
            flex-direction: column;
            gap: 10px;
        }

        .profile-pic .update-profile-text p {
            color: #666;
        }

        .upload-btn {
            display: block;
            /* margin: 10px auto; */
            padding: 10px 15px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .upload-btn:hover {
            background: #0056b3;
        }

        form {
            /* display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px; */
            width: 100%;
            display: flex;
            justify-content: start;
            align-items: start;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            color: #32363d;
        }

        form .input-field {
            width: 100%;
            display: flex;
            justify-content: start;
            align-items: start;
            flex-direction: row;
            gap: 20px;
            padding: 10px 0;
        }

        form .input-field .input-box {
            width: 40%;
        }

        form .input-field input {
            width: 100%;
            padding: 12px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 5px;
        }

        form .input-field-2 .input-box {
            width: 50%;
        }

        form .input-field-textarea {
            width: 100%;
        }

        form .input-field-textarea .input-box {
            width: 100%;
        }

        form .input-field textarea {
            width: 100%;
            height: 200px;
            padding: 12px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 5px;
        }

        .full-width {
            grid-column: span 2;
        }

        form p {
            color: #32363d;
        }

        form .input-field .input-box .new-password-input {
            background-color: #d2daf7;
        }

        .submit-btn {
            grid-column: span 2;
            /* text-align: center; */
            margin-top: 20px;
        }

        .submit-btn button {
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .submit-btn button:hover {
            background: #0056b3;
        }

        .download-pdf {
            margin: 40px 0;
        }

        .download-pdf button {
            padding: 10px 20px;
            background: #28a745;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .download-pdf button a {
            text-decoration: none;
            color: white;
        }

        .download-pdf button:hover {
            background: #218838;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
            }

            .sidebar.show {
                left: 0;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }

        #dropdown-menu {
            position: absolute;
            top: 50px;
            /* Adjust based on your layout */
            left: 10px;
            /* Adjust to align below the icon */
            background: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            width: 150px;
            display: none;
            /* Initially hidden */
            z-index: 1000;
        }

        #dropdown-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        #dropdown-menu li {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        #dropdown-menu li:last-child {
            border-bottom: none;
        }

        #dropdown-menu a {
            text-decoration: none;
            color: black;
            display: block;
        }

        .hidden {
            display: none;
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="../assets/imgs/logo.png" alt="biZvility Logo">
            </div>
            <i class="fas fa-bars hamburger" id="sidebar-toggle"></i>
        </div>

        <ul>
        <a href="userdashboard.php">
                <li><i class="fa-solid fa-gauge"></i> <span>Dashboard</span></li>
            </a>
            <!-- <li><i class="fas fa-user"></i> <span>My Profile</span></li> -->
            <li><i class="fas fa-heart"></i> <span>Saved</span></li>
            <li><i class="fas fa-envelope"></i> <span>Inbox</span></li>
            <li><i class="fas fa-star"></i> <span>Reviews</span></li>
            <li><i class="fas fa-cog"></i> <span>Setting</span></li> <!-- Updated Icon -->
            <li>
                <a href="logout.php" style="text-decoration: none; color: inherit;">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </li> <!-- Updated Icon -->
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="main-content">

        <!-- Top Navigation -->
        <div class="top-nav">
            <div class="nav-links">
                <button class="btn btn-primary">
                    <a href="../pricing-plan.php">
                        <i class="fa-solid fa-circle-plus"></i>
                        Add Listing
                    </a>
                </button>
                <!-- Button trigger modal -->
                <a href="#">📞 Contact Support</a>
                <p><?php echo htmlspecialchars($_SESSION['fullname']); ?></p>
                <div class="leftdata">
                <img  src="<?php
                                                        $imageSrc = '';
                                                        if (!empty($_SESSION['image']) && $_SESSION['image'] !== 'default.jpg' && !strpos($_SESSION['image'], 'flaticon.com')) {
                                                            $imageSrc = '../uploads/profile_images/' . $_SESSION['image'];
                                                        } else {
                                                            $imageSrc = '../assets/imgs/avatar.jpg'; // Correct path to your default image
                                                        }
                                                        // Handle NULL or empty explicitly
                                                        if (empty($_SESSION['image']) || $_SESSION['image'] === null) {
                                                            $imageSrc = '../assets/imgs/avatar.jpg'; // Correct path to your default image
                                                        }
                                                        echo htmlspecialchars($imageSrc);
                                                        ?>" alt="User Profile Picture" style="width: 45px; height: 45px; border-radius: 100%;">
                </div>
                <i class="fas fa-bars hamburger" id="sidebar-toggle"></i> <!-- Hamburger Icon Added Here -->
                <!-- Dropdown Menu -->
                <div id="dropdown-menu" class="hidden">
                    <ul>
                        <li><a href="profile.php">My Profile</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- <div class="open-profile-box">
            <ul>
                <a href="#">
                    <li>
                        <i class="fa-solid fa-circle-user"></i>
                        My Profile
                    </li>
                </a>
                <a href="../connect/logout.php">
                    <li>
                        <i class="fa-solid fa-lock"></i>
                        Logout
                    </li>
                </a>
            </ul>
        </div> -->
         <div class="fetchuserenquiry">

         </div>

        
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="../assets/js/scripts.js"></script>
    <script>
        // document.getElementById('sidebar-toggle').addEventListener('click', function() {
        //     document.getElementById('sidebar').classList.toggle('collapsed');
        //     document.getElementById('main-content').classList.toggle('expanded');
        // });

        // document.addEventListener("DOMContentLoaded", function() {
        //     const sidebarToggle = document.getElementById("sidebar-toggle");
        //     const dropdownMenu = document.getElementById("dropdown-menu");

        //     sidebarToggle.addEventListener("click", function(event) {
        //         event.stopPropagation(); // Prevents the click from bubbling up
        //         dropdownMenu.classList.toggle("hidden");
        //     });

        //     // Hide the dropdown if clicked outside
        //     document.addEventListener("click", function(event) {
        //         if (!sidebarToggle.contains(event.target) && !dropdownMenu.contains(event.target)) {
        //             dropdownMenu.classList.add("hidden");
        //         }
        //     });
        // });


        
        const fileInput = document.getElementById('fileInput');
        const profilePreview = document.getElementById('profilePreview');

        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    profilePreview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            } else {
                // If no file is selected, revert to the original or default image
                profilePreview.src = "<?php echo htmlspecialchars($_SESSION['image'] ?? 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'); ?>";
            }
        });
    

    </script>

</body>

</html>

