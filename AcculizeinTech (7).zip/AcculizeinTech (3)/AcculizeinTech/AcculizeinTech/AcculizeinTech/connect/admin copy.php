<?php
include_once 'config.php'; // Database connection

// Update status if admin approves/rejects
if (isset($_POST['action']) && isset($_POST['id'])) {
    $id = $_POST['id'];
    $action = $_POST['action'];

    if ($action === 'approve') {
        $status = 'approved';
    } elseif ($action === 'reject') {
        $status = 'rejected';
    }

    $sql = "UPDATE enquiry SET approval_status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        echo "<script>alert('Request $status successfully!');</script>";
    } else {
        echo "<script>alert('Error updating status');</script>";
    }
}

// Fetch all enquiries
$sql = "SELECT * FROM enquiry ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel - Approve Enquiries</title>
</head>
<body>
    <h2>Admin Panel - Approve or Reject Enquiries</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Category</th>
            <th>Other Category</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['fullname'] ?></td>
                <td><?= $row['phone'] ?></td>
                <td><?= $row['email'] ?></td>
                <td><?= $row['business_category'] ?></td>
                <td><?= $row['other_category'] ?></td>
                <td><?= ucfirst($row['approval_status']) ?></td>
                <td>
                    <?php if ($row['approval_status'] == 'pending') { ?>
                        <form method="POST">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <button type="submit" name="action" value="approve">Approve</button>
                            <button type="submit" name="action" value="reject">Reject</button>
                        </form>
                    <?php } else { ?>
                        <?= ucfirst($row['approval_status']) ?>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
