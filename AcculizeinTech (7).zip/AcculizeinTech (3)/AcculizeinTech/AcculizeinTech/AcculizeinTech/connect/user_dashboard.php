<?php
session_start();
require 'config.php'; //database connection

include '../session_check.php';

// Check if user is logged in via session or "Remember Me" cookie
if (!isset($_SESSION['user_id'])) {
    if (isset($_COOKIE['remember_me'])) {
        $token = $_COOKIE['remember_me'];
        $query = "SELECT user_id, fullname, email, user_type FROM users WHERE remember_token = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['fullname'] = $row['fullname'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['user_type'] = $row['user_type'];
            session_regenerate_id(true);

            // Refresh the cookie expiration time
            setcookie("remember_me", $token, time() + (86400 * 30), "/", "", true, true);
        }
    }
}

// Ensure user is logged in and has the correct user_type
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'user') {
    header("Location: login.php");
    exit();
}

// Database connection (Ensure it's correctly set in config.php)
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $con->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// If user data is not found, log them out
if (!$user) {
    header("Location: logout.php");
    exit();
}

// Fetch user's enquiries
$enquiryQuery = "SELECT * FROM enquiry WHERE user_id = ?";
$stmt = $con->prepare($enquiryQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$enquiryResult = $stmt->get_result();
$enquiries = $enquiryResult->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($user['fullname']); ?></h1>

        <h2>Your Details</h2>
        <table class="table">
            <tr>
                <th>Full Name</th>
                <td><?php echo htmlspecialchars($user['fullname']); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?php echo htmlspecialchars($user['approval_status']); ?></td>
            </tr>
        </table>

        <h2>Your Enquiries</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Enquiry ID</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($enquiries)) {
                    foreach ($enquiries as $enquiry) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($enquiry['id']); ?></td>
                            <td><?php echo htmlspecialchars($enquiry['status']); ?></td>
                            <td><?php echo htmlspecialchars($enquiry['enquiry_date']); ?></td>
                        </tr>
                <?php } 
                } else { ?>
                    <tr>
                        <td colspan="3">No enquiries found.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <?php include('profile.php'); ?>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
