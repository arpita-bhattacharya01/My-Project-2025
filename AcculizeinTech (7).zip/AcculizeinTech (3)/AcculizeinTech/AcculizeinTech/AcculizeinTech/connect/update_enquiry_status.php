<?php
// update_enquiry_status.php

require_once 'config.php';
require_once __DIR__ . '/../PhpMailer/PHPMailer.php';
require_once __DIR__ . '/../PhpMailer/SMTP.php';
require_once __DIR__ . '/../PhpMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;   

function updateEnquiryStatusAndSendEmail($enquiry_id, $new_status) {
    global $conn, $smtp_host, $smtp_user, $smtp_pass; // Access global database and SMTP variables

    $allowed_statuses = ['approved', 'rejected', 'pending', 'expired'];

    if (!$enquiry_id || !in_array($new_status, $allowed_statuses)) {
        error_log("updateEnquiryStatusAndSendEmail - Invalid input: enquiry_id=" . $enquiry_id . ", status=" . $new_status);
        return false; // Indicate failure
    }

    $stmt = $conn->prepare("UPDATE enquiry SET approval_status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $enquiry_id);

    if (!$stmt->execute()) {
        error_log("updateEnquiryStatusAndSendEmail - Database update failed: " . $stmt->error);
        $stmt->close();
        return false; // Indicate failure
    }
    $stmt->close();

    $email_stmt = $conn->prepare("
        SELECT u.email, u.fullname, p.title AS category, e.approval_status
        FROM enquiry e
        JOIN users u ON e.user_id = u.id
        JOIN plans p ON e.plan_id = p.id
        WHERE e.id = ?
    ");
    $email_stmt->bind_param("i", $enquiry_id);
    $email_stmt->execute();
    $email_stmt->bind_result($user_email, $user_fullname, $user_category, $user_approval_status);
    $fetchResult = $email_stmt->fetch();
    $email_stmt->close();

    if ($fetchResult && filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
        $mail = new PHPMailer(true);

        try {
            $mail->SMTPDebug = SMTP::DEBUG_OFF;
            $mail->isSMTP();
            $mail->Host = $smtp_host;
            $mail->SMTPAuth = true;
            $mail->Username = $smtp_user;
            $mail->Password = $smtp_pass;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom($smtp_user, 'Bizvility');
            $mail->addAddress($user_email, $user_fullname);
            $mail->isHTML(true);
            $mail->Subject = 'Enquiry Status Update';

            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'];
            $price_link = "https://{$host}/backend30/AcculizeinTech/submitlisting.html";

            switch ($user_approval_status) {
                case 'approved':
                    $mail->Body = "Hello {$user_fullname},<br><br>
                                    Thanks for choosing our services for: <b>{$user_category}</b>.<br><br>
                                    Please review our pricing and make a payment:<br>
                                    👉 <a href='{$price_link}' target='_blank'>View Pricing</a><br><br>
                                    Or copy this URL:<br><b>{$price_link}</b><br><br>
                                    Best regards,<br>Bizvility";
                    break;
                case 'rejected':
                    $mail->Body = "Hello {$user_fullname},<br><br>
                                    Unfortunately, your enquiry for <b>{$user_category}</b> has been <b>rejected</b>.<br>
                                    You may submit a new enquiry.<br><br>
                                    Best regards,<br>Your Company Name";
                    break;
                default:
                    $mail->Body = "Hello {$user_fullname},<br><br>
                                    Your enquiry status is updated to: <b>{$user_approval_status}</b>.<br><br>
                                    Best regards,<br>Your Company Name";
                    break;
            }

            if ($mail->send()) {
                return true; // Indicate email sent successfully
            } else {
                error_log("updateEnquiryStatusAndSendEmail - Email send failed: " . $mail->ErrorInfo);
                return false; // Indicate email sending failure
            }

        } catch (Exception $e) {
            error_log("updateEnquiryStatusAndSendEmail - PHPMailer Error: " . $mail->ErrorInfo);
            return false; // Indicate email sending failure
        }
    } else {
        error_log("updateEnquiryStatusAndSendEmail - User not found or invalid email for enquiry ID: " . $enquiry_id);
        return true; // Status updated, but no email sent (or couldn't be) - maybe consider false depending on requirement
    }
}

// Prevent direct execution if this file is called directly
if (basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
    header('Content-Type: application/json; charset=utf-8');
    $response = ['status' => 'error', 'message' => 'This script should not be accessed directly.'];
    echo json_encode($response);
    exit();
}
?>