CREATE TABLE listings (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    hotelName VARCHAR(255) NOT NULL,
    tagline VARCHAR(255) NULL,
    address VARCHAR(255) NOT NULL,
    contactEmail VARCHAR(255) NOT NULL,
    contactPhone VARCHAR(50) NOT NULL,
    description TEXT NOT NULL
    geoLocation VARCHAR(255) NULL,
    city VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    latitude DOUBLE NULL,
    longitude DOUBLE NULL,
    pinLocation VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS listings (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(255) NOT NULL,
    delivery TINYINT(1) NOT NULL DEFAULT 0,
    takeout TINYINT(1) NOT NULL DEFAULT 0,
    air_conditioning TINYINT(1) NOT NULL DEFAULT 0,
    dog_allowed TINYINT(1) NOT NULL DEFAULT 0,
    twenty_four_hours_open TINYINT(1) NOT NULL DEFAULT 0,
    wheelchair_accessible TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS listings (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    gender ENUM('Male', 'Female') NOT NULL,
    payment_methods TEXT NOT NULL,
    price_range VARCHAR(255),
    price_from DECIMAL(10,2),
    price_to DECIMAL(10,2),
    business_hours JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE business_hours (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    weekday VARCHAR(20),
    start_time TIME,
    end_time TIME,
    is_24hours BOOLEAN
);

CREATE TABLE business_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    description TEXT,
    tags VARCHAR(255),
    video_link VARCHAR(255),
    image_links TEXT
);
