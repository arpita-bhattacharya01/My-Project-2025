<?php
include_once 'config.php'; // Database connection

if (isset($_GET['phone'])) {
    $phone = $_GET['phone'];

    $sql = "SELECT fullname, approval_status FROM enquiry WHERE phone = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo "<h2>Hello " . $row['fullname'] . ", your request status is: <b>" . ucfirst($row['approval_status']) . "</b></h2>";
    } else {
        echo "<h2>No request found for this phone number.</h2>";
    }
} else {
    echo "<h2>Please enter a phone number.</h2>";
}
?>
