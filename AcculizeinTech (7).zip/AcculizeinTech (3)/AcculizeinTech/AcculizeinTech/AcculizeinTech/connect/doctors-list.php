<?php
// Include database connection
include_once 'config.php';

// Query to get all doctors
$query = "SELECT doctor_id, fullname, specialty FROM doctors";
$result = mysqli_query($conn, $query);

$create_doctors_table="CREATE TABLE `doctors` (
   `doctor_id` INT AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(255) NOT NULL,
    `specialty` VARCHAR(255) NOT NULL,
    `location` VARCHAR(255) NOT NULL,
    `working_hours` VARCHAR(100) NOT NULL,
    `contact_number` VARCHAR(15) NOT NULL,
    `image_url` VARCHAR(255) NOT NULL,
    `profile_url` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);";

$create_listings_table="CREATE TABLE `listings` (
    CREATE TABLE listings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hotel_name VARCHAR(255) NOT NULL,
    tagline VARCHAR(255),
    geo_location VARCHAR(255),
    city VARCHAR(255),
    phone VARCHAR(20),
    website VARCHAR(255),
    custom_address Varchar(255),
    latitude FLOAT(10, 6),
    longitude FLOAT(10, 6),
    business_title text,
    business_description varchar(255),
    category VARCHAR(50),
    delivery BOOLEAN,
    takeout BOOLEAN,
    air_conditioning BOOLEAN,
    dog_allowed BOOLEAN,
    hours_24 BOOLEAN,
    wheelchair_accesible BOOLEAN,
    gender text,
    payment_modes
    price_range VARCHAR(50),
    price_from DECIMAL(10, 2),
    price_to DECIMAL(10, 2),
    business_hours JSON,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size INT(11) NOT NULL,
    file_path VARCHAR(255) NOT NULL,    
    description varchar(255),
    tags text,
    upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);";

CREATE TABLE `uploads` (
    `id` INT(11) AUTO_INCREMENT PRIMARY KEY,
    `file_name` VARCHAR(255) NOT NULL,
    `file_type` VARCHAR(50) NOT NULL,
    `file_size` INT(11) NOT NULL,
    `file_path` VARCHAR(255) NOT NULL,
    `upload_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

// Check if there are any doctors
if (mysqli_num_rows($result) > 0) {
    echo "<h1>List of Doctors</h1>";
    echo "<ul>";
    
    // Loop through the doctors and display them
    while ($row = mysqli_fetch_assoc($result)) {
        $doctor_id = $row['doctor_id'];
        $fullname = htmlspecialchars($row['fullname']);
        $specialty = htmlspecialchars($row['specialty']);
        
        echo "<li><a href='doctor_profile.php?id=$doctor_id'>$fullname - $specialty</a></li>";
    }

    echo "</ul>";
} else {
    echo "<p>No doctors found.</p>";
}

// Fetch doctors from the database
$query = "SELECT * FROM doctors";
$result = mysqli_query($conn, $query);

// Check if there are doctors
if (mysqli_num_rows($result) > 0) {
    while ($doctor = mysqli_fetch_assoc($result)) {
        $doctor_id = $doctor['doctor_id'];
        $fullname = htmlspecialchars($doctor['fullname']);
        $specialty = htmlspecialchars($doctor['specialty']);
        $location = htmlspecialchars($doctor['location']);
        $working_hours = htmlspecialchars($doctor['working_hours']);
        $phone = htmlspecialchars($doctor['phone']);
        $image_url = htmlspecialchars($doctor['image_url']);
        $profile_url = htmlspecialchars($doctor['profile_url']);
        ?>

        <div class="card doctor-card">
            <div class="card-header">
                <img src="<?php echo $image_url; ?>" alt="<?php echo $fullname; ?>">
            </div>
            <div class="card-body">
                <div class="doctor-name">
                    <h5>
                        <a href="<?php echo $profile_url; ?>">
                            <?php echo $fullname; ?>
                            <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                <i class="fa-solid fa-circle-check"></i>
                            </a>
                        </a>
                    </h5>
                    <p>
                        <a href="#">
                            <i class="fa-solid fa-notes-medical"></i>
                            <?php echo $specialty; ?>
                        </a>
                    </p>
                    <div class="location-time">
                        <p>
                            <a href="#">
                                <i class="fa-solid fa-location-dot"></i>
                                <?php echo $location; ?>
                            </a>
                        </p>
                        <p class="open"><?php echo $working_hours; ?></p>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <p class="call-first">
                    <a href="#">
                        <i class="fa-solid fa-square-phone"></i>
                        Call
                    </a>
                </p>
                <p class="call-second">
                    <a href="tel:<?php echo $contact_number; ?>">
                        <i class="fa-solid fa-square-phone"></i>
                        <?php echo $contact_number; ?>
                    </a>
                </p>
                <p class="direction">
                    <a href="#">
                        <i class="fa-solid fa-diamond-turn-right"></i>
                        Get Direction
                    </a>
                </p>
            </div>
        </div>

        <?php
    }
} else {
    echo "No doctors found!";
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input values
    $hotel_name = mysqli_real_escape_string($conn, $_POST['hotelName']);
    $tagline = isset($_POST['tagline']) ? mysqli_real_escape_string($conn, $_POST['tagline']) : null;
    $geo_location = mysqli_real_escape_string($conn, $_POST['geoLocation']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $website = mysqli_real_escape_string($conn, $_POST['website']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    
    // Checkbox values (if checked, will be 1, otherwise 0)
    $delivery = isset($_POST['toggle-delivery']) ? 1 : 0;
    $takeout = isset($_POST['toggle-takeout']) ? 1 : 0;
    $air_conditioning = isset($_POST['air-conditioning-checkbox']) ? 1 : 0;
    $dog_allowed = isset($_POST['dog-allowed-checkbox']) ? 1 : 0;
    $hours_24 = isset($_POST['24-hours-work']) ? 1 : 0;
    
    // Price details
    $price_range = mysqli_real_escape_string($conn, $_POST['price_range']);
    $price_from = mysqli_real_escape_string($conn, $_POST['price_from']);
    $price_to = mysqli_real_escape_string($conn, $_POST['price_to']);
    
    // Business hours - assume that they are being passed as a JSON
    $business_hours = json_encode([
        "monday" => [
            "start" => $_POST['monday_start'],
            "end" => $_POST['monday_end']
        ],
        "tuesday" => [
            "start" => $_POST['tuesday_start'],
            "end" => $_POST['tuesday_end']
        ],
        "wednesday" => [
            "start" => $_POST['wednesday_start'],
            "end" => $_POST['wednesday_end']
        ],
        "thursday" => [
            "start" => $_POST['thursday_start'],
            "end" => $_POST['thursday_end']
        ],
        "friday" => [
            "start" => $_POST['friday_start'],
            "end" => $_POST['friday_end']
        ],
        "saturday" => [
            "start" => $_POST['saturdday_start'],
            "end" => $_POST['saturday_end']
        ],
        "sunday" => [
            "start" => $_POST['sunday_start'],
            "end" => $_POST['sunday_end']
        ],
        // Add for other days
    ]);

    // Insert data into the database
    $query = "INSERT INTO listings (hotel_name, tagline, geo_location, city, phone, website, category, delivery, takeout, air_conditioning, dog_allowed, hours_24, price_range, price_from, price_to, business_hours) 
              VALUES ('$hotel_name', '$tagline', '$geo_location', '$city', '$phone', '$website', '$category', '$delivery', '$takeout', '$air_conditioning', '$dog_allowed', '$hours_24', '$price_range', '$price_from', '$price_to', '$business_hours')";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        echo "Listing submitted successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if files were uploaded
    if (isset($_FILES['files']) && !empty($_FILES['files']['name'][0])) {
        // Loop through each file uploaded
        $totalFiles = count($_FILES['files']['name']);
        for ($i = 0; $i < $totalFiles; $i++) {
            $fileName = $_FILES['files']['name'][$i];
            $fileTmpName = $_FILES['files']['tmp_name'][$i];
            $fileSize = $_FILES['files']['size'][$i];
            $fileError = $_FILES['files']['error'][$i];
            $fileType = $_FILES['files']['type'][$i];

            // Set allowed file types (e.g., images and videos)
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/webm', 'video/avi'];

            // Check if file type is allowed
            if (in_array($fileType, $allowedTypes)) {
                // Check if there were no errors with the file upload
                if ($fileError === 0) {
                    // Set the upload directory
                    $uploadDir = 'uploads/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0777, true); // Create directory if it doesn't exist
                    }

                    // Generate a unique file name to avoid overwriting
                    $uniqueFileName = uniqid('', true) . '-' . basename($fileName);

                    // Define the file path
                    $fileDestination = $uploadDir . $uniqueFileName;

                    // Move the file to the server
                    if (move_uploaded_file($fileTmpName, $fileDestination)) {
                        echo "File uploaded successfully: " . $uniqueFileName . "<br>";
                    } else {
                        echo "Error uploading file: " . $fileName . "<br>";
                    }
                } else {
                    echo "Error with file: " . $fileName . "<br>";
                }
            } else {
                echo "File type not allowed: " . $fileName . "<br>";
            }
        }
    } else {
        echo "No files were uploaded.";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if files were uploaded
    if (isset($_FILES['files']) && !empty($_FILES['files']['name'][0])) {
        // Loop through each file uploaded
        $totalFiles = count($_FILES['files']['name']);
        for ($i = 0; $i < $totalFiles; $i++) {
            $fileName = $_FILES['files']['name'][$i];
            $fileTmpName = $_FILES['files']['tmp_name'][$i];
            $fileSize = $_FILES['files']['size'][$i];
            $fileError = $_FILES['files']['error'][$i];
            $fileType = $_FILES['files']['type'][$i];

            // Set allowed file types
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/webm', 'video/avi'];

            // Check if file type is allowed
            if (in_array($fileType, $allowedTypes)) {
                // Check if there were no errors with the file upload
                if ($fileError === 0) {
                    // Set the upload directory
                    $uploadDir = 'uploads/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0777, true); // Create directory if it doesn't exist
                    }

                    // Generate a unique file name to avoid overwriting
                    $uniqueFileName = uniqid('', true) . '-' . basename($fileName);

                    // Define the file path
                    $fileDestination = $uploadDir . $uniqueFileName;

                    // Move the file to the server
                    if (move_uploaded_file($fileTmpName, $fileDestination)) {
                        // Prepare the SQL statement to insert file details into the database
                        $stmt = $conn->prepare("INSERT INTO uploads (file_name, file_type, file_size, file_path) VALUES (?, ?, ?, ?)");
                        $stmt->bind_param("ssis", $uniqueFileName, $fileType, $fileSize, $fileDestination);

                        // Execute the query
                        if ($stmt->execute()) {
                            echo "File uploaded and data saved: " . $uniqueFileName . "<br>";
                        } else {
                            echo "Error saving data: " . $stmt->error . "<br>";
                        }

                        // Close the statement
                        $stmt->close();
                    } else {
                        echo "Error uploading file: " . $fileName . "<br>";
                    }
                } else {
                    echo "Error with file: " . $fileName . "<br>";
                }
            } else {
                echo "File type not allowed: " . $fileName . "<br>";
            }
        }
    } else {
        echo "No files were uploaded.";
    }
}


mysqli_close($conn); // Close database connection
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bizvility &#8211; Dare To Grow</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/bizvility-logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <!-- navbar -->
    <header class="navbar navbar-2">
        <!-- logo -->
        <div class="logo ms-2">
            <a href="index.html">
                <img src="assets/imgs/logo.png" width="220" height="70" alt="">
            </a>
        </div>

        <!-- select-what-where -->
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn search-btn btn-primary">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </div>
        </div>

        <!-- nav-buttons -->
        <ul class="nav-btns me-3">
            <button class="btn btn-outline-light">Career</button>
            <button class="btn btn-primary btn-outline-light">
                <a href="pricing-plan.html">
                    <i class="fa-solid fa-circle-plus"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
        <i class="fa-solid fa-bars menu-open"></i>
        <i class="fa-solid fa-xmark menu-close"></i>
    </header>

    <div class="side-menu side-menu-2">
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn search-btn btn-primary">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </div>
        </div>
        <ul class="side-links">
            <button class="btn btn-outline-light">Career</button>
            <button class="btn btn-primary btn-outline-light">
                <a href="pricing-plan.html">
                    <i class="fa-solid fa-circle-plus"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
    </div>

    <!-- signIn & signUp Modal -->
    <div class="popup_main">
        <div class="popup_body">
            <div class="popup_back"></div>
            <div class="popup_contain">
                <div class="popup_close">&times;</div>
                <div class="left">
                    <img src="assets/imgs/signIn-img.jpg" alt="Placeholder Image">
                    <button class="toggle-btn" id="toggle-auth">Click to Sign In</button>
                </div>
                <div class="right">
                    <div class="form-container active" id="signup-form">
                        <h3>Create new account</h3>
                        <hr>
                        <form action="signup.php" method="post">
                            <input type="text" name="fullname" id="fullName" placeholder="Your Full Name" required>
                            <input type="email" name="email" id="email" placeholder="Your Email" required>
                            <input type="tel" name="phone" id="phone" placeholder="Your Phone Number" required>
                            <input type="text" name="city" id="state" placeholder="City" required>
                            <input type="text" name="state" id="state" placeholder="State" required>
                            <input type="number" name="pincode" id="pincode" placeholder="Pincode" required>
                            <input type="text" name="username" id="username" placeholder="Username" required>
                            <div class="form-group">
                                <input type="password" name="password" id="password" placeholder="Password" required>
                                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                            </div>
                            <div class="form-group">
                                <input type="password" name="confirm-password" id="confirm-password" placeholder="Confirm Password" required>
                                <span class="toggle-password" onclick="togglePassword('confirm-password')">👁</span>
                            </div>
                            <div class="form-btns">
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <button type="submit" name="signup" class="btn btn-primary">Sign Up</button>
                            </div>
                        </form>
                        <div class="form-toggle">
                            <button class="toggle-btn" id="toggle-auth-2">Click to Sign In</button>
                        </div>
                    </div>
                </div>
                <div class="form-container" id="signin-form">
                    <h3>Sign In</h3>
                    <form action="signin.php" method="post">
                        <input type="text" class="mb-2" name="username" placeholder="Username" required>
                        <div class="form-group">
                            <input type="password" name="signin-password" id="signin-password" placeholder="Password" required>
                            <span class="toggle-password" onclick="togglePassword('signin-password')">👁</span>
                        </div>
                        <div class="form-btns">
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <button type="submit" name="signin" class="btn btn-primary">Sign In</button>
                        </div>
                    </form>
                    <div class="form-toggle">
                        <button class="toggle-btn" id="toggle-auth-3">Click to Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- automative listing -->
    <div class="listing-section">
        <div class="listing-content">
            <div class="title">
                <h5>Results For <span>Automotive Listing</span></h5>
                <div class="listing-set">
                    <i class="fa-solid fa-table-cells-large grid-box"></i>
                    <i class="fa-solid fa-list list-box"></i>
                </div>
            </div>

            <div class="sorting-btn-group">
                <div class="six-btn-group">
                    <button class="btn near-me">
                        <i class="fa-solid fa-location-dot"></i>
                        Near me
                        <div class="hover-list">
                            <li>Click To Get</li>
                        </div>
                    </button>
                    <button class="btn price">
                        <i class="fa-solid fa-money-bill-1"></i>
                        Price
                        <div class="hover-list">
                            <li title="Expensive">&#8377;</li>
                            <li title="Moderate">&#8377;&#8377;</li>
                            <li title="Pricey">&#8377;&#8377;&#8377;</li>
                            <li title="Ultra High End">&#8377;&#8377;&#8377;&#8377;</li>
                        </div>
                    </button>
                    <button class="btn open-now">
                        <i class="fa-solid fa-clock"></i>
                        Open Now
                        <div class="hover-list">
                            <li>Click To See What Open Now</li>
                        </div>
                    </button>
                    <button class="btn shuffle">
                        <i class="fa-solid fa-shuffle"></i>
                        Best Match
                        <div class="hover-list">
                            <li>Click To See Your Best Match</li>
                        </div>
                    </button>
                    <button class="btn sort-by">
                        <i class="fa-solid fa-sort"></i>
                        Sort By
                        <div class="hover-list">
                            <li>Most Reviewed</li>
                            <li>Most Viewed</li>
                            <li>Highestt Rated</li>
                        </div>
                    </button>
                    <button class="btn filter">
                        <i class="fa-solid fa-filter"></i>
                        <div class="filter-hover">
                            <p>More Filters</p>
                        </div>
                    </button>
                </div>

                <div class="sorting-listing-dropdown">
                    <p class="open-list">
                        <i class="fa-solid fa-list list-box pe-2"></i>
                        Sorting Dropdown
                        <i class="fa-solid fa-angle-down sort-down"></i>
                    </p>
                    <div class="sort-list">
                        <li><a href="#">All Categories</a></li>
                        <li><a href="#">Arts & Entertainment</a></li>
                        <li><a href="#">Beauty & Spa</a></li>
                        <li><a href="#">Health & Medical</a></li>
                        <li><a href="#">Hotels</a></li>
                        <li><a href="#">Italian</a></li>
                        <li><a href="#">Real Estate</a></li>
                        <li><a href="#">Restaurant</a></li>
                        <li><a href="#">Services</a></li>
                        <li><a href="#">Shopping</a></li>
                    </div>
                </div>

                <div class="show-map">
                    <i class="fa-solid fa-map-location-dot map-icon" onclick="openMap()"></i>

                    <div class="map-modal" id="mapModal">
                        <div class="map-container">
                            <span class="close-btn" onclick="closeMap()">&times;</span>
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227159.73554759895!2d77.81520197899306!3d27.176078189144043!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39740d857c2f41d9%3A0x784aef38a9523b42!2sAgra%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1740025655844!5m2!1sen!2sin"
                                width="570" height="450" style="border:0;" allowfullscreen="true" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>

            <div class="doctors-list">
                <!-- card 1 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-arun-gupta.png" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <?php include 'drarun.php'; ?>
                                <a href="dr-arun.html">
                                    Dr. Arun Gupta
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <p class="open">24 Hours Open</p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                Call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <p class="direction">
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p>
                    </div>
                </div>

                <!-- card 2 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-shriyansh-chahar.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <?php include 'drshriyansh.php'; ?>
                                <a href="dr-shriyansh.html">
                                    Dr. Shriyansh Chahar
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <p class="closing">Closed now</p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                Call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:07078272881">
                                <i class="fa-solid fa-square-phone"></i>
                                07078272881
                            </a>
                        </p>
                        <p class="direction">
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p>
                    </div>
                </div>

                <!-- card 3 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img name="phot_url" src="assets/imgs/dr-chitra-janu.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-chitra.html">
                                    Dr. Chitra janu
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <p class="closing">Closed now</p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                Call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09910997436">
                                <i class="fa-solid fa-square-phone"></i>
                                09910997436
                            </a>
                        </p>
                        <p class="direction">
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p>
                    </div>
                </div>

                <?php include 'drkhooshbu.php'; ?>
                <!-- card 4 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-khooshbu-goyal.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-khushboo.html">
                                    Dr. Khushboo Goyal
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09068368441">
                                <i class="fa-solid fa-square-phone"></i>
                                09068368441
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>

                <?php include 'drmeghal.php'; ?>
                <!-- card 5 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-meghal-2.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-meghal.html">
                                    Dr. Meghal Goyal
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:07300968441">
                                <i class="fa-solid fa-square-phone"></i>
                                07300968441
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>

                <?php include 'drricha.php'; ?>
                <!-- card 6 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-richa-2.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-richa.html">
                                    Dr. Reecha Agarwal
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09634454726">
                                <i class="fa-solid fa-square-phone"></i>
                                09634454726
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>
              <?php include 'drsaumyata.php'; ?>
                <!-- card 7 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-saumyata-2.png" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-saumyata.html">
                                    Dr. Saumyata Neeraj
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:08788467848">
                                <i class="fa-solid fa-square-phone"></i>
                                08788467848
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>
            </div>
        </div>


        <div class="side-map" name="map_link">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227159.73554759895!2d77.81520197899306!3d27.176078189144043!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39740d857c2f41d9%3A0x784aef38a9523b42!2sAgra%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1740025655844!5m2!1sen!2sin"
                width="" height="" style="border:0;" allowfullscreen="true" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>


        <!-- responsive listing -->
        <div class="responsive-listing">
            <div class="title">
                <h5>Results For <span>Automotive</span></h5>
            </div>

            <!-- filters and map -->
            <div class="filter-map-btns">
                <button class="btn btn-primary see-filters-btn">See Filters</button>

                <div class="show-map">
                    <i class="fa-solid fa-map-location-dot map-icon" onclick="openMap2()"></i>

                    <div class="map-modal" id="mapModal2">
                        <div class="map-container">
                            <span class="close-btn" onclick="closeMap2()">&times;</span>
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227159.73554759895!2d77.81520197899306!3d27.176078189144043!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39740d857c2f41d9%3A0x784aef38a9523b42!2sAgra%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1740025655844!5m2!1sen!2sin"
                                width="570" height="450" style="border:0;" allowfullscreen="true" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>

            <!-- filter dropdown -->
            <div class="see-filters">
                <div class="sorting-btn-group">
                    <div class="six-btn-group">
                        <button class="btn near-me">
                            <i class="fa-solid fa-location-dot"></i>
                            Near me
                            <div class="hover-list">
                                <li>Click To Get</li>
                            </div>
                        </button>
                        <button class="btn price">
                            <i class="fa-solid fa-money-bill-1"></i>
                            Price
                            <div class="hover-list">
                                <li title="Expensive">&#8377;</li>
                                <li title="Moderate">&#8377;&#8377;</li>
                                <li title="Pricey">&#8377;&#8377;&#8377;</li>
                                <li title="Ultra High End">&#8377;&#8377;&#8377;&#8377;</li>
                            </div>
                        </button>
                        <button class="btn open-now">
                            <i class="fa-solid fa-clock"></i>
                            Open Now
                            <div class="hover-list">
                                <li>Click To See What Open Now</li>
                            </div>
                        </button>
                        <button class="btn shuffle">
                            <i class="fa-solid fa-shuffle"></i>
                            Best Match
                            <div class="hover-list">
                                <li>Click To See Your Best Match</li>
                            </div>
                        </button>
                        <button class="btn sort-by">
                            <i class="fa-solid fa-sort"></i>
                            Sort By
                            <div class="hover-list">
                                <li>Most Reviewed</li>
                                <li>Most Viewed</li>
                                <li>Highestt Rated</li>
                            </div>
                        </button>
                        <button class="btn filter">
                            <i class="fa-solid fa-filter"></i>
                            <div class="filter-hover">
                                <p>More Filters</p>
                            </div>
                        </button>
                    </div>

                    <div class="sorting-listing-dropdown">
                        <p class="open-list">
                            <i class="fa-solid fa-list list-box pe-2"></i>
                            Sorting Dropdown
                            <i class="fa-solid fa-angle-down sort-down"></i>
                        </p>
                        <div class="sort-list">
                            <li><a href="#">All Categories</a></li>
                            <li><a href="#">Arts & Entertainment</a></li>
                            <li><a href="#">Beauty & Spa</a></li>
                            <li><a href="#">Health & Medical</a></li>
                            <li><a href="#">Hotels</a></li>
                            <li><a href="#">Italian</a></li>
                            <li><a href="#">Real Estate</a></li>
                            <li><a href="#">Restaurant</a></li>
                            <li><a href="#">Services</a></li>
                            <li><a href="#">Shopping</a></li>
                        </div>
                    </div>
                </div>
            </div>


            <!-- doctors list -->
            <div class="doctors-list">
                <!-- card 1 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-arun-gupta.png" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <?php include 'drarun.php'; ?>
                                <a href="#">
                                    Dr. Arun Gupta
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <p class="open">24 Hours Open</p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                Call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <p class="direction">
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p>
                    </div>
                </div>
                <?php include 'drshriyansh.php'; ?>
                                
                <!-- card 2 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-shriyansh-chahar.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-shriyansh.html">
                                    Dr. Shriyansh Chahar
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <p class="closing">Closed now</p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                Call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <p class="direction" name="map_link">
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p>
                    </div>
                </div>
                <?php include 'drChitra.php'; ?>
                                
                <!-- card 3 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-chitra-janu.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-chitra.html">
                                    Dr. Chitra janu
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <p class="closing">Closed now</p>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                Call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <p class="direction" name="map_link">
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p>
                    </div>
                </div>
                <?php include 'drkhushboo.php'; ?>
                                
                <!-- card 4 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-khooshbu-goyal.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-khushboo.html">
                                    Dr. Khushboo Goyal
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>
                <?php include 'drmeghal.php'; ?>
                                
                <!-- card 5 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-meghal-2.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-meghal.html">
                                    Dr. Meghal Goyal
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>
                
                <?php include 'drricha.php'; ?>
                                
                <!-- card 6 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-richa-2.jpg" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-richa.html">
                                    Dr. Reecha Agarwal
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>

                
                                
                <!-- card 7 -->
                <div class="card doctor-card">
                    <div class="card-header">
                        <img src="assets/imgs/dr-saumyata-2.png" alt="">
                    </div>
                    <div class="card-body">
                        <div class="doctor-name">
                            <h5>
                                <a href="dr-saumyata.html">
                                    Dr. Saumyata Neeraj
                                    <a href="#" data-bs-toggle="tooltip" data-bs-title="Claimed">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </a>
                                </a>
                            </h5>
                            <p>
                                <a href="#">
                                    <i class="fa-solid fa-notes-medical"></i>
                                    Health & Medical
                                </a>
                            </p>
                            <div class="location-time">
                                <p>
                                    <a href="#">
                                        <i class="fa-solid fa-location-dot"></i>
                                        Agra
                                    </a>
                                </p>
                                <!-- <p class="open-closing">24 Hours Open</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <p class="call-first">
                            <a href="#">
                                <i class="fa-solid fa-square-phone"></i>
                                call
                            </a>
                        </p>
                        <p class="call-second">
                            <a href="tel:09568139362">
                                <i class="fa-solid fa-square-phone"></i>
                                09568139362
                            </a>
                        </p>
                        <!-- <p>
                            <a href="#">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                Get Direction
                            </a>
                        </p> -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>