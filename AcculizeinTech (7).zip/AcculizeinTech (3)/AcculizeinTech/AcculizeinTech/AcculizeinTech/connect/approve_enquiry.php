<?php
// include_once '../config.php'; // Adjust path if needed
include_once __DIR__ . '/../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $enquiry_id = $_POST['enquiry_id'];
    $status = $_POST['status']; // 'approved' or 'rejected'

    // Fetch user email from enquiry table
    $query = "SELECT email FROM enquiry WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $enquiry_id);
    $stmt->execute();
    $stmt->bind_result($email);
    $stmt->fetch();
    $stmt->close();

    if ($email) {
        // Update enquiry status
        $update_query = "UPDATE enquiry SET approval_status = ? WHERE id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("si", $status, $enquiry_id);
        if ($stmt->execute()) {
            // Send email notification to user
            $subject = "Enquiry Status Update";
            $message = "Hello,\n\nYour enquiry has been $status.\n\nRegards,\nBizvility Team";
            $headers = "From: bizvility@gmail.com";

            mail($email, $subject, $message, $headers);

            echo "<script>
                    alert('Enquiry status updated successfully! Email sent to user.');
                    window.location.href = '../admin_dashboard.html';
                  </script>";
        } else {
            echo "<script>alert('Error updating status.');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('User not found.');</script>";
    }
    
    $conn->close();
}
?>
