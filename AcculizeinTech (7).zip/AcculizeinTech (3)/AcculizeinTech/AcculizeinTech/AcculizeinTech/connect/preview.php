<?php
// Capture form data from POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // $fullname = $_POST['fullname'];
    // $email = $_POST['email'];
    // $phone = $_POST['phone'];
    // $business_category = $_POST['business_category'];
    // $tagline = $_POST['tagline'];  // Optional
    $id =$_POST['id'];
    $hotelName=$_POST['hotelName'];
    $tagline=$_POST['tagline'];
    $geoLocation=$_POST['geoLocation'];
    $city=$_POST['city'];
    $phone=$_POST['phone'];
    $latitude=$_POST['latitude'];
    $longitude=$_POST['longitude'];
    $pinLocation=$_POST['pinLocation'];
    $category=$_POST['category'];
    $delivery=$_POST['delivery'];
    $takeout=$_POST['takeout'];
    $air_conditioning=$_POST['air_conditioning'];
    $dog_allowed=$_POST['dog_allowed'];
    $twenty_four_hours_open=$_POST['twenty_four_hours_open'];
    $wheelchair_accessible=$_POST['wheelchair_accessible'];
    $gender=$_POST['gender'];
    $payment_methods=$_POST['payment_methods'];
    $price_range=$_POST['price_range'];
    $price_from=$_POST['price_from'];
    $price_to=$_POST['price_to'];
    $business_hours=$_POST['business_hours'];
    $image_links=$_POST['image_links'];
    $description=$_POST['description'];
    $tags=$_POST['tags'];
    $video_link=$_POST['video_link'];

// Check if the tagline checkbox is checked
$tagline_checkbox = isset($_POST['tagline-checkbox']) ? 1 : 0;

    // Display the captured data for review
    echo "<h2>Preview Your Information</h2>";
    echo "<p><strong>Listing Title:</strong> " . htmlspecialchars($hotelName) . "</p>";
    echo "<input type='Checkbox' name='tagline_checkbox' value='" .htmlspecialchars($tagline_checkbox)."'>";
    echo "<p><strong>Full Address (Geolocation):</strong> " . htmlspecialchars($full_address) . "</p>";
    echo "<p><strong>City:</strong> " . htmlspecialchars($city) . "</p>";
    echo "<p><strong>Phone:</strong> " . htmlspecialchars($website) . "</p>";
    echo "<p><strong>Website:</strong>".htmlspecialchars($website)."</p>";

 // Display checkbox data
 if ($tagline_checkbox == 1) {
    echo "<p><strong>Does your business have a tagline? </strong> Yes</p>";
} else {
    echo "<p><strong>Does your business have a tagline? </strong> No</p>";
}
}
// Get the ID from the URL
$business_id = isset($_GET['id']) ? $_GET['id'] : 0;

if ($business_id > 0) {
    // Retrieve data from the database based on the ID
    $sql = "SELECT * FROM business_info WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $business_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Display the data
        echo "<h1>Preview Your Business Information</h1>";

        echo "<p><strong>Action Type:</strong> " . $row['action_type'] . "</p>";

        if ($row['action_type'] == 'google') {
            echo "<p><strong>Full Address:</strong> " . $row['full_address'] . "</p>";
            echo "<p><strong>City:</strong> " . $row['city'] . "</p>";
            echo "<p><strong>Phone:</strong> " . $row['phone'] . "</p>";
            echo "<p><strong>Website:</strong> " . $row['website'] . "</p>";
        } elseif ($row['action_type'] == 'manual') {
            echo "<p><strong>Latitude:</strong> " . $row['latitude'] . "</p>";
            echo "<p><strong>Longitude:</strong> " . $row['longitude'] . "</p>";
            echo "<p><strong>City:</strong> " . $row['city'] . "</p>";
            echo "<p><strong>Phone:</strong> " . $row['phone'] . "</p>";
            echo "<p><strong>Website:</strong> " . $row['website'] . "</p>";
        } elseif ($row['action_type'] == 'drop_pin') {
            echo "<p><strong>Business Category:</strong> " . $row['business_category'] . "</p>";
        }

        // Tagline information
        $tagline_display = $row['has_tagline'] ? $row['tagline'] : 'No tagline provided.';
        echo "<p><strong>Tagline:</strong> " . $tagline_display . "</p>";

    } else {
        echo "<p>No data found for the provided ID.</p>";
    }

    $stmt->close();
} else {
    echo "<p>Invalid ID.</p>";
}

// Retrieve the latest entry from the database (or all entries)
// $sql = "SELECT * FROM business_features ORDER BY id DESC LIMIT 1"; // Fetch the most recent entry
// $result = $conn->query($sql);

$result=$conn->query("SELECT * FROM business_features ORDER BY id DESC LIMIT 1"); //fetch the most recent entry

// Check if the result contains data
if ($result->num_rows > 0) {
    // Fetch the data and display it
    $row = $result->fetch_assoc();
    echo "<h3>Your Submitted Business Features:</h3>";
    echo "Delivery: " . ($row['delivery'] ? 'Yes' : 'No') . "<br>";
    echo "Takeout: " . ($row['takeout'] ? 'Yes' : 'No') . "<br>";
    echo "Air Conditioning: " . ($row['air_conditioning'] ? 'Yes' : 'No') . "<br>";
    echo "Dog Allowed: " . ($row['dog_allowed'] ? 'Yes' : 'No') . "<br>";
    echo "24 Hours Open: " . ($row['hours_open'] ? 'Yes' : 'No') . "<br>";
    echo "Wheelchair Accessible: " . ($row['wheelchair_accessible'] ? 'Yes' : 'No') . "<br>";
} else {
    echo "No data found.";
}

// Retrieve the most recent entry from the database (or all entries)
$sql = "SELECT * FROM user_payment_info ORDER BY id DESC LIMIT 1"; // Fetch the most recent entry
$result = $conn->query($sql);

// Check if the result contains data
if ($result->num_rows > 0) {
    // Fetch the data and display it
    $row = $result->fetch_assoc();
    echo "<h3>Your Submitted Information:</h3>";
    echo "Gender: " . $row['gender'] . "<br>";
    echo "Payment Modes: " . $row['payment_modes'] . "<br>";
    echo "Business Hours:" .$row['business_hours']. "<br>";
} else {
    echo "No data found.";
}

// Retrieve the most recent entry from the user_payment_info table
$sql_user_payment_info = "SELECT * FROM user_payment_info ORDER BY id DESC LIMIT 1"; 
$result_user_payment_info = $conn->query($sql_user_payment_info);

// Retrieve the most recent entry from the business_hours table
$sql_business_hours = "SELECT * FROM business_hours ORDER BY id DESC LIMIT 1"; 
$result_business_hours = $conn->query($sql_business_hours);

// Check if data is found for user_payment_info
if ($result_user_payment_info->num_rows > 0) {
    $row_user_payment_info = $result_user_payment_info->fetch_assoc();
    echo "<h3>Your Submitted Information:</h3>";
    echo "Gender: " . $row_user_payment_info['gender'] . "<br>";
    echo "Payment Modes: " . $row_user_payment_info['payment_modes'] . "<br>";
} else {
    echo "No user payment information found.<br>";
}

// Check if data is found for business_hours
if ($result_business_hours->num_rows > 0) {
    $row_business_hours = $result_business_hours->fetch_assoc();
    echo "<h3>Business Hours:</h3>";
    echo "Weekday: " . $row_business_hours['weekday'] . "<br>";
    echo "Start Time: " . $row_business_hours['start_time'] . "<br>";
    echo "End Time: " . $row_business_hours['end_time'] . "<br>";
    echo "Is 24 Hours: " . ($row_business_hours['is_24hours'] ? 'Yes' : 'No') . "<br>";
} else {
    echo "No business hours found.<br>";
}

   // After previewing the form data, give the user an option to confirm
   echo "<form method='POST' action='submit.php'>";
   echo "<input type='hidden' name='fullname' value='" . htmlspecialchars($fullname) . "'>";
   echo "<input type='hidden' name='email' value='" . htmlspecialchars($email) . "'>";
   echo "<input type='hidden' name='phone' value='" . htmlspecialchars($phone) . "'>";
   echo "<input type='hidden' name='business_category' value='" . htmlspecialchars($business_category) . "'>";
   echo "<input type='hidden' name='tagline' value='" . htmlspecialchars($tagline) . "'>";
   echo "<input type='hidden' name='tagline-checkbox' value='<?php echo $tagline_checkbox; ?>'>";
   echo "<input type='hidden' name='image_links' value='<?php echo $image_links;?>'>";
   echo "<input type='hidden' name='video-link' value='<?php echo $video_link;?>'>";
   echo "<button type='submit'>Submit</button>";
   echo "</form>";


$conn->close();
?>