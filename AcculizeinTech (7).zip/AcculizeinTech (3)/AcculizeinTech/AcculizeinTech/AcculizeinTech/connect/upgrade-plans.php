<?php

include_once 'config.php'; // Include database connection


$email = $_POST['email'];
$plan = $_POST['plan'];

$sql = "UPDATE listings SET category = CONCAT(category, ' (Premium)') WHERE email='$email'";

if ($conn->query($sql) === TRUE) {
    echo "<script>
        alert('Upgrade Successful! Proceed to Payment.');
        window.location.href='payment.html';
    </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
