<?php
$host = "localhost";
//$user = "gauravmu_bizvilitydb";
//$pass= "bizvilitydb@123456789";
//$dbname = "gauravmu_bizvilitydb";
$user = "root";
$pass = "";
$dbname = "bizvilitydb";  


// Create connection`
$conn = new mysqli($host, $user, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// SMTP Configuration
$smtp_host = "mail.gauravmudgal.com";
$smtp_user = "info@gauravmudgal.com";
$smtp_pass = "c5NdkovF=F8=";
?>