<?php

include_once 'config.php'; // Include database connection



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $address = $_POST["address"];
    $phone = $_POST["phone"];
    $latitude = $_POST["latitude"];
    $longitude = $_POST["longitude"];
    $details = $_POST["details"];

    // File Upload
    $photo = $_FILES["photo"]["name"];
    $target = "uploads/" . basename($photo);
    move_uploaded_file($_FILES["photo"]["tmp_name"], $target);

    $stmt = $conn->prepare("INSERT INTO doctors (name, address, phone, photo, latitude, longitude, details) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssdds", $name, $address, $phone, $photo, $latitude, $longitude, $details);
    
    if ($stmt->execute()) {
        echo "Doctor added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>

<form action="upload.php" method="post" enctype="multipart/form-data">
    Name: <input type="text" name="name" required><br>
    Address: <textarea name="address" required></textarea><br>
    Phone: <input type="text" name="phone" required><br>
    Latitude: <input type="text" name="latitude" required><br>
    Longitude: <input type="text" name="longitude" required><br>
    Details: <textarea name="details" required></textarea><br>
    Photo: <input type="file" name="photo" required><br>
    <input type="submit" value="Upload">
</form>
