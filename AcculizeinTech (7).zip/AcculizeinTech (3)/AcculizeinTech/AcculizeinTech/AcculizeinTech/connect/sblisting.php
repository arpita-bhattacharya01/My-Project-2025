<?php
include 'config.php';
$query='select * from Users';
$result=mysqli_query($conn,$query);
if(!$result){
    die("query failed".mysqli_error());
}
else{
    $row=mysqli_fetch_row($result);
    print_r($row);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bizvility &#8211; Dare To Grow</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/bizvility-logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <!-- navbar -->
    <header class="navbar navbar-2">
        <!-- logo -->
        <div class="logo ms-2">
            <a href="index.html">
                <img src="assets/imgs/logo.png" width="220" height="70" alt="">
            </a>
        </div>

        <!-- select-what-where -->
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn search-btn btn-primary">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </div>
        </div>

        <!-- nav-buttons -->
        <ul class="nav-btns me-3">
            <button class="btn btn-outline-light">Career</button>
            <button class="btn btn-primary btn-outline-light">
                <a href="pricing-plan.html">
                    <i class="fa-solid fa-circle-plus"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
        <i class="fa-solid fa-bars menu-open"></i>
        <i class="fa-solid fa-xmark menu-close"></i>
    </header>

    <div class="side-menu side-menu-2">
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn search-btn btn-primary">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </div>
        </div>
        <ul class="side-links">
            <button class="btn btn-outline-light">Career</button>
            <button class="btn btn-primary btn-outline-light">
                <a href="pricing-plan.html">
                    <i class="fa-solid fa-circle-plus"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
    </div>

    <!-- signIn & signUp Modal -->
    <div class="popup_main">
        <div class="popup_body">
            <div class="popup_back"></div>
            <div class="popup_contain">
                <div class="popup_close">&times;</div>
                <div class="left">
                    <img src="assets/imgs/signIn-img.jpg" alt="Placeholder Image">
                    <button class="toggle-btn" id="toggle-auth">Click to Sign In</button>
                </div>
                <div class="right">
                    <div class="form-container active" id="signup-form">
                        <h3>Create new account</h3>
                        <hr>
                        <form action="connect/signup.php" method="post">
                            <input type="text" name="fullname" id="fullName" placeholder="Your Full Name" required>
                            <input type="email" name="email" id="email" placeholder="Your Email" required>
                            <input type="tel" name="phone" id="phone" placeholder="Your Phone Number" required>
                            <input type="text" name="city" id="state" placeholder="City" required>
                            <input type="text" name="state" id="state" placeholder="State" required>
                            <input type="number" name="pincode" id="pincode" placeholder="Pincode" required>
                            <input type="text" name="username" id="username" placeholder="Username" required>
                            <div class="form-group">
                                <input type="password" name="password" id="password" placeholder="Password" required>
                                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                            </div>
                            <div class="form-group">
                                <input type="password" name="confirm-password" id="confirm-password" placeholder="Confirm Password" required>
                                <span class="toggle-password" onclick="togglePassword('confirm-password')">👁</span>
                            </div>
                            <div class="form-btns">
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <button type="submit" class="btn btn-primary">Sign Up</button>
                            </div>
                        </form>
                        <div class="form-toggle">
                            <button class="toggle-btn" id="toggle-auth-2">Click to Sign In</button>
                        </div>
                    </div>
                </div>
                <div class="form-container" id="signin-form">
                    <h3>Sign In</h3>
                    <form action="connect/signin.php" method="post">
                        <input type="text" class="mb-2" name="username" placeholder="Username" required>
                        <div class="form-group">
                            <input type="password" name="signin-password" id="signin-password" placeholder="Password" required>
                            <span class="toggle-password" onclick="togglePassword('signin-password')">👁</span>
                        </div>
                        <div class="form-btns">
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <button type="submit" class="btn btn-primary">Sign In</button>
                        </div>
                    </form>
                    <div class="form-toggle">
                        <button class="toggle-btn" id="toggle-auth-3">Click to Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!-- submit listing form -->
    <div class="submit-listing">
        <div class="container">
            <div class="row">
            
            <?php
            while($row =mysqli_fetch_assoc($result))
            {
                

                ?>
                <div class="col-lg-12 col-md-12">
                    <div class="reminder-header">
                        <p>Returning User? Please <span data-bs-toggle="modal" data-bs-target="#exampleModal">
                            <a href="connect/signin.php">Sign In</a>    
                            </span> and if you are a New User, continue below and register along with this submission.
                        </p>
                    </div>
                    <hr>
                </div>

                <div class="col-lg-8 col-md-12">
                    <div class="form-section">
                        <form action="connect/submit-listing.php" class="form" id="form"  method="post" enctype="multipart/form-data">
                            <div class="form-separate-box">
                                <h6>Primary listing details</h6>
                                <hr>
                                <div class="input-field">
                                    <label for="hotelName">
                                        Listing Title
                                        <span>*</span>
                                        <a href="#" data-bs-toggle="tooltip"
                                            data-bs-title="Put your listing title here and tell the name of your business to the world.">
                                            <i class='bx bx-question-mark'></i>
                                        </a>
                                    </label>
                                    <input type="text" name="hotelName" id="hotelName"
                                        placeholder="Staple & Fancy Hotel" value="<?php echo $row['hotelName']?>">
                                </div>

                                <div class="checkbox-field">
                                    <label>
                                        <input type="checkbox" name="tagline-checkbox" id="toggle-extra" value="<?php echo $row['tagline-checkbox']?>"> Does Your
                                        Business
                                        Have A
                                        Tagline?
                                    </label>

                                    <div id="extra-input" class="hidden-input">
                                        <label>Tagline</label>
                                        <input type="text" name="tagline" id="tagline"
                                            placeholder="Tagline Example: Best Express Mexican Grill" value="<?php echo $row['tagline']?>">
                                    </div>
                                </div>

                                <div class="form-btns-group">
                                    <button type="button" class="toggle-form active" data-form="toggle1">Search By
                                        Google</button>
                                    <button type="button" class="toggle-form" data-form="toggle2">Manual
                                        Coordinates</button>
                                    <button type="button" class="toggle-form" data-form="toggle3">
                                        <i class="fa-solid fa-map-pin"></i>
                                        Drop Pin
                                    </button>
                                </div>

                                <div id="toggle1" class="form-container">
                                    <!-- first input field -->
                                    <div class="input-field">
                                        <label for="geoLocation">
                                            Full Address (Geolocation)
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="Start typing and select your google location from google suggestions. This is for the map and also for locating your business.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <input type="text" name="geoLocation" id="geoLocation"
                                            placeholder="Start typing and find your place in google map" autocomplete="off" value="<?php echo $row['geoLocation']; initAutocomplete(); ?>">
                                    </div>

                                    <!-- second input field -->
                                    <div class="input-field">
                                        <label for="city">
                                            City
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="The city name will help users find you in search filters.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <input type="text" name="city" id="city"
                                            placeholder="Select your listing region" value="<?php echo $row['city']?>">
                                    </div>

                                    <!-- third input field -->
                                    <div class="input-field">
                                        <label for="phone">Phone</label>
                                        <input type="tel" name="phone" id="phone" maxlength="10"
                                            placeholder="111-111-1234" value="<?php echo $row['phone']?>">
                                    </div>

                                    <!-- fourth input field -->
                                    <div class="input-field">
                                        <label for="website">Website</label>
                                        <input type="text" name="website" id="website" placeholder="http://" value="<?php echo $row['website']?>">
                                    </div>
                                </div>

                                <div id="toggle2" class="form-container">
                                    <!-- first input field -->
                                    <div class="input-field">
                                        <label for="custome-address">Add Custom Address</label>
                                        <input type="text" name="custom-address" id="custome-address"
                                            placeholder="Add address here" value="<?php echo $row['custom-address']?>">
                                    </div>

                                    <!-- second input field -->
                                    <div class="input-field-2">
                                        <div class="first-field">
                                            <label for="latitude">Latitude</label>
                                            <input type="text" name="latitude" id="latitude" placeholder="40.7143528" value="<?php echo $row['latitude']?>">
                                        </div>
                                        <div class="second-field">
                                            <label for="longitude">Longitude</label>
                                            <input type="text" name="longitude" id="longitude" placeholder="-74.0059731" value="<?php echo $row['longitude']?>">
                                        </div>
                                    </div>

                                    <!-- third input field -->
                                    <div class="input-field">
                                        <label for="city">
                                            City
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="The city name will help users find you in search filters.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <input type="text" name="city" id="city"
                                            placeholder="Select your listing region" value="<?php echo $row['longitude']?>">
                                    </div>

                                    <!-- fourth input field -->
                                    <div class="input-field">
                                        <label for="phone">Phone</label>
                                        <input type="tel" name="phone" id="phone" maxlength="10"
                                            placeholder="111-111-1234" value="<?php echo $row['phone']?>">
                                    </div>

                                    <!-- fifth input field -->
                                    <div class="input-field">
                                        <label for="website">Website</label>
                                        <input type="text" name="website" id="website" placeholder="http://"  value="<?php echo $row['website']?>">
                                    </div>
                                </div>

                                <!-- <div id="toggle3" class="form-container">
                                <label>Phone:</label>
                                <input type="tel">
                            </div> -->

                            </div>

                            <div class="form-separate-box">
                                <div class="box-2">
                                    <h6>Category & services</h6>
                                    <hr>
                                    <div class="input-field">
                                        <label for="category">Category<span>*</span></label>
                                        <select name="category" id="category" value="<?php echo $row['category']?>">
                                            <option value="chooseWhat" disabled selected>Choose Your Business Category
                                            </option>
                                            <option value="arts&entertainment">Arts & Entertainment</option>
                                            <option value="automotive">Automotive</option>
                                            <option value="beauty&spa">Beauty & Spa</option>
                                            <option value="health&medical">Health & Medical</option>
                                            <option value="hotels">Hotels</option>
                                            <option value="italian">Italian</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-3">
                                    <div class="toggle-container">
                                        <div class="toggle-box">
                                            <label for="toggle-delivery">
                                                <input type="checkbox" id="toggle-delivery" class="toggle-checkbox" value="<?php echo $row['delivery']?>">
                                                <span class="toggle-label"></span>
                                                Delivery
                                            </label>
                                        </div>

                                        <div class="toggle-box">
                                            <label for="toggle-takeout">
                                                <input type="checkbox" id="toggle-takeout" class="toggle-checkbox" value="<?php echo $row['takeout']?>">
                                                <span class="toggle-label"></span>
                                                Take Out
                                            </label>
                                        </div>
                                    </div>

                                    <div class="checkbox-container">
                                        <div class="checkboxes">
                                            <label for="air-conditioning">
                                                <input type="checkbox" name="air-conditioning"
                                                    id="air-conditioning-checkbox" value="<?php echo $row['air_conditioning']?>">
                                                Air Conditioning
                                            </label>
                                            <label for="dog-allowed">
                                                <input type="checkbox" name="dog-allowed"
                                                    id="dog-allowed-checkbox" value="<?php echo $row['dog_allowed']?>">
                                                Dog Allowed
                                            </label>
                                            <label for="24hours-open">
                                                <input type="checkbox" name="twenty_four_hours_open"
                                                    id="24hours-open-checkbox" value="<?php echo $row['twenty_four_hours_open']?>">
                                                24 Hours Open
                                            </label>
                                            <label for="wheelchair-accesible">
                                                <input type="checkbox" name="wheelchair-accesible"
                                                    id="wheelchair-accesible-checkbox" value="<?php echo $row['wheelchair_accessible']?>">
                                                Wheelchair Accessible
                                            </label>
                                        </div>
                                    </div>

                                    <div class="radio-container">
                                        <span>Gender</span>
                                        <div class="radioes">
                                            <label for="male">
                                                <input type="radio" name="gender" id="male" value="<?php echo $row['gender']?>">
                                                Male
                                            </label>
                                            <label for="female">
                                                <input type="radio" name="gender" id="female" value="<?php echo $row['gender']?>">
                                                Female
                                            </label>
                                        </div>
                                    </div>

                                    <div class="checkbox-container">
                                        <span>Accept Payments</span>
                                        <div class="checkboxes checkboxes-2">
                                            <label for="credit-card">
                                                <input type="checkbox" name="payment_modes"
                                                    id="credit-card-checkbox" value="<?php echo $row['payment_modes']?>">
                                                Credit Card
                                            </label>
                                            <label for="bank-transfer">
                                                <input type="checkbox" name="payment_modes"
                                                    id="bank-transfer-checkbox" value="<?php echo $row['payment_modes']?>">
                                                Bank Transfer
                                            </label>
                                            <label for="mobile-payment">
                                                <input type="checkbox" name="payment_modes"
                                                    id="mobile-payment-checkbox" value="<?php echo $row['payment_modes']?>">
                                                Mobile Payments
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-4">
                                    <h6>Price details</h6>
                                    <hr>
                                    <div class="input-field input-field-3">
                                        <div class="first-field">
                                            <label for="price-range">Price Range</label>
                                            <select name="price_range" id="" value="<?php echo $row['price_range']?>">
                                                <option value="not-to-say">Not to say</option>
                                                <option value="not-to-say">&#8377;-Inexpensive</option>
                                                <option value="not-to-say">&#8377;&#8377;-Moderate</option>
                                                <option value="not-to-say">&#8377;&#8377;&#8377;-Pricey</option>
                                                <option value="not-to-say">&#8377;&#8377;&#8377;&#8377;-Ultra High
                                                </option>
                                            </select>
                                        </div>
                                        <div class="second-field">
                                            <label for="price-from">Price From</label>
                                            <input type="text" name="price_from" id="price-from"
                                                placeholder="Price From" value="<?php echo $row['price_from']?>">
                                        </div>
                                        <div class="third-field">
                                            <label for="price-to">Price To</label>
                                            <input type="text" name="price_to" id="price-to" placeholder="Price To" value="<?php echo $row['price_to']?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-5">
                                    <h6 name="business_hours" value="<?php echo $row['business_hours']?>">Business hours</h6>
                                    <hr>
                                    <div class="business-time">
                                    <span name="weekday" value="<?php echo $row['weekday']?>">.$row['weekday'].</span>
                                      <!--  <span name="weekday" value="<?php echo $row['weekday']?>">Monday</span> -->
                                        <div class="time">
                                            <p class="starting" name="start_time" value="<?php echo $row['start_time']?>">09:00AM -</p>
                                            <p class="ending" name="end_time" value="<?php echo $row['end_time']?>">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-solid fa-circle-xmark"></i>
                                        </div>
                                    </div>
                                    <!-- <div class="business-time">
                                        <span name="weekday" value="<?php echo $row['weekday']?>">Tuesday</span>
                                        <div class="time">
                                            <p class="starting" name="start_time" value="<?php echo $row['start_time']?>">09:00AM -</p>
                                            <p class="ending" name="end_time" value="<?php echo $row['end_time']?>">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-solid fa-circle-xmark"></i>
                                        </div>
                                    </div>
                                    <div class="business-time">
                                        <span name="weekday" value="<?php echo $row['weekday']?>">Wednesday</span>
                                        <div class="time">
                                            <p class="starting" name="start_time" value="<?php echo $row['start_time']?>">09:00AM -</p>
                                            <p class="ending" name="end_time" value="<?php echo $row['end_time']?>">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-solid fa-circle-xmark"></i>
                                        </div>
                                    </div>
                                    <div class="business-time">
                                        <span name="weekday" value="<?php echo $row['weekday']?>">Thursday</span>
                                        <div class="time">
                                            <p class="starting" name="start_time" value="<?php echo $row['start_time']?>">09:00AM -</p>
                                            <p class="ending" name="end_time" value="<?php echo $row['end_time']?>">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-solid fa-circle-xmark"></i>
                                        </div>
                                    </div>
                                    <div class="business-time">
                                        <span name="weekday" value="<?php echo $row['weekday']?>">Friday</span>
                                        <div class="time">
                                            <p class="starting" name="start_time" value="<?php echo $row['start_time']?>">09:00AM -</p>
                                            <p class="ending" name="end_time" value="<?php echo $row['end_time']?>">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-solid fa-circle-xmark"></i>
                                        </div>
                                    </div> -->

                                    <div class="add-another-days-container">
                                        <div class="add-another-days">
                                            <select name="weekday" id="weekdays" value="<?php echo $row['weekday']?>">
                                                <option value="monday">Monday</option>
                                                <option value="tuesday">Tuesday</option>
                                                <option value="wednesday">Wednesday</option>
                                                <option value="thursday">Thursday</option>
                                                <option value="friday">Friday</option>
                                                <option value="saturday">Saturday</option>
                                                <option value="sunday">Sunday</option>
                                            </select>

                                            <select name="start_time" id="day-start" value="<?php echo $row['start_time']?>">
                                                <option value="12:00AM">12:00AM</option>
                                                <option value="12:30AM">12:30AM</option>
                                                <option value="01:00AM">01:00AM</option>
                                                <option value="01:30AM">01:30AM</option>
                                                <option value="02:00AM">02:00AM</option>
                                                <option value="02:30AM">02:30AM</option>
                                                <option value="03:00AM">03:00AM</option>
                                                <option value="04:00AM">04:00AM</option>
                                                <option value="04:30AM">04:30AM</option>
                                                <option value="05:00AM">05:00AM</option>
                                                <option value="05:30AM">05:30AM</option>
                                                <option value="06:00AM">06:00AM</option>
                                                <option value="06:30AM">06:30AM</option>
                                                <option value="07:00AM">07:00AM</option>
                                                <option value="07:30AM">07:30AM</option>
                                                <option value="08:00AM">08:00AM</option>
                                                <option value="08:30AM">08:30AM</option>
                                                <option value="09:00AM" selected>09:00AM</option>
                                                <option value="09:30AM">09:30AM</option>
                                                <option value="10:00AM">10:00AM</option>
                                                <option value="10:30AM">10:30AM</option>
                                                <option value="11:00AM">11:00AM</option>
                                                <option value="11:30AM">11:30AM</option>
                                                <option value="12:00PM">12:00M</option>
                                                <option value="12:30PM">12:30M</option>
                                                <option value="01:00PM">01:00PM</option>
                                                <option value="01:30PM">01:30PM</option>
                                                <option value="02:00PM">02:00PM</option>
                                                <option value="02:30PM">02:30PM</option>
                                                <option value="03:00PM">03:00PM</option>
                                                <option value="03:30PM">03:30PM</option>
                                                <option value="04:00PM">04:00PM</option>
                                                <option value="04:30PM">04:30PM</option>
                                                <option value="05:00PM">05:00PM</option>
                                                <option value="05:30PM">05:30PM</option>
                                                <option value="06:00PM">06:00PM</option>
                                                <option value="06:30PM">06:30PM</option>
                                                <option value="07:00PM">07:00PM</option>
                                                <option value="07:30PM">07:30PM</option>
                                                <option value="08:00PM">08:00PM</option>
                                                <option value="08:30PM">08:30PM</option>
                                                <option value="09:00PM">09:00PM</option>
                                                <option value="09:30PM">09:30PM</option>
                                                <option value="10:00PM">10:00PM</option>
                                                <option value="10:30PM">10:30PM</option>
                                                <option value="11:00PM">11:00PM</option>
                                                <option value="11:30PM">11:30PM</option>
                                            </select>

                                            <select name="end_time" id="day-end" value="<?php echo $row['end_time']?>">
                                                <option value="12:00AM">12:00AM</option>
                                                <option value="12:30AM">12:30AM</option>
                                                <option value="01:00AM">01:00AM</option>
                                                <option value="01:30AM">01:30AM</option>
                                                <option value="02:00AM">02:00AM</option>
                                                <option value="02:30AM">02:30AM</option>
                                                <option value="03:00AM">03:00AM</option>
                                                <option value="04:00AM">04:00AM</option>
                                                <option value="04:30AM">04:30AM</option>
                                                <option value="05:00AM">05:00AM</option>
                                                <option value="05:30AM">05:30AM</option>
                                                <option value="06:00AM">06:00AM</option>
                                                <option value="06:30AM">06:30AM</option>
                                                <option value="07:00AM">07:00AM</option>
                                                <option value="07:30AM">07:30AM</option>
                                                <option value="08:00AM">08:00AM</option>
                                                <option value="08:30AM">08:30AM</option>
                                                <option value="09:00AM">09:00AM</option>
                                                <option value="09:30AM">09:30AM</option>
                                                <option value="10:00AM">10:00AM</option>
                                                <option value="10:30AM">10:30AM</option>
                                                <option value="11:00AM">11:00AM</option>
                                                <option value="11:30AM">11:30AM</option>
                                                <option value="12:00PM">12:00M</option>
                                                <option value="12:30PM">12:30M</option>
                                                <option value="01:00PM">01:00PM</option>
                                                <option value="01:30PM">01:30PM</option>
                                                <option value="02:00PM">02:00PM</option>
                                                <option value="02:30PM">02:30PM</option>
                                                <option value="03:00PM">03:00PM</option>
                                                <option value="03:30PM">03:30PM</option>
                                                <option value="04:00PM">04:00PM</option>
                                                <option value="04:30PM">04:30PM</option>
                                                <option value="05:00PM" selected>05:00PM</option>
                                                <option value="05:30PM">05:30PM</option>
                                                <option value="06:00PM">06:00PM</option>
                                                <option value="06:30PM">06:30PM</option>
                                                <option value="07:00PM">07:00PM</option>
                                                <option value="07:30PM">07:30PM</option>
                                                <option value="08:00PM">08:00PM</option>
                                                <option value="08:30PM">08:30PM</option>
                                                <option value="09:00PM">09:00PM</option>
                                                <option value="09:30PM">09:30PM</option>
                                                <option value="10:00PM">10:00PM</option>
                                                <option value="10:30PM">10:30PM</option>
                                                <option value="11:00PM">11:00PM</option>
                                                <option value="11:30PM">11:30PM</option>
                                            </select>

                                            <div class="24hours">
                                                <label for="24hours">
                                                    <input type="checkbox" name="24-hours-work" id="24-hours-work"  value="<?php echo $row['is_24hours']?>" >
                                                    24 Hours
                                                </label>
                                            </div>
                                        </div>

                                        <div class="add-day">
                                            <i class="fa-solid fa-square-plus"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-6">
                                    <h6>Social Media</h6>
                                    <hr>
                                    <div class="input-field input-field-4">
                                        <div class="first-field">
                                            <label for="category">Select</label>
                                            <select name="category" id="category" value="<?php echo $row['category']?>">
                                                <option value="chooseWhat" name="choose-social-media" disabled selected>Please select
                                                </option>
                                                <option value="instagram" name="choose-social-media">Instagram</option>
                                                <option value="youtube" name="choose-social-media">Youtube</option>
                                                <option value="linkedin" name="choose-social-media">LinkedIn</option>
                                                <option value="facebook" name="choose-social-media">Facebook</option>
                                                <option value="twitter" name="choose-social-media">Twitter</option>
                                            </select>
                                            <input type="text" name="choose-social-media" id="choose-social-media" value="<?php echo $row['category']?>">
                                        </div>
                                        <div class="add-day">
                                            <i class="fa-solid fa-square-plus"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-7">
                                    <h6>Frequently asked questions</h6>
                                    <hr>
                                    <div class="faq-container">
                                        <div id="faq-list">
                                            <div class="faq-item" data-index="1">
                                                <p>FAQ</p>
                                                <div class="inputs-box">
                                                    <input type="text" name="faq" id="faq" placeholder="FAQ">
                                                    <textarea name="faq_answer" id="faq-answer"
                                                        placeholder="Answer" value="<?php echo $row['faq_answer']?>"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="add-btn" id="add-faq">
                                            <i class="fa-solid fa-square-plus"></i>
                                            Add New
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-8">
                                    <h6>More info</h6>
                                    <hr>
                                    <label for="editor">Description <span style="color: red;">*</span></label>
                                    <textarea id="editor" name="description" value="<?php echo $row['description']?>">Detail description about your listing</textarea>

                                    <div class="input-field">
                                        <label for="geoLocation">
                                            Tags you keywords (Comma seprated)
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="These keywords or tags will help your listing to find in search. Add a comma separated list of keywords related to your business.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <textarea name="tags-keywords" id="tags-keywords"
                                            placeholder="Enter tags or keywords comma separated..."></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-9">
                                    <h6>Media</h6>
                                    <hr>
                                    <div class="input-field">
                                        <label for="geoLocation">
                                            Your Business Video (Optional)
                                        </label>
                                        <input type="url" name="video_link" id="video-link"
                                            placeholder="ex: https://youtu.be/IY2yjAdbvdQ" value="<?php echo $row['video_link']?>">
                                    </div>
                                    <div class="input-field">
                                        <div class="upload-container" id="upload-area">
                                            <label for="upload-file">Image</label>
                                            <div class="drop-zone">
                                                <p>Drop files here or click to upload</p>
                                                <input type="file" name="images[]" id="file-input" value="<?php echo $row['image_links']?>  class="file-input" multiple>
                                                <button class="btn browse-btn" id="browse-btn">Browse Files</button>
                                            </div>

                                            <label for="upload-logo">Upload Business Logo</label>
                                            <div class="drop-zone drop-logo">
                                                <button class="btn upload-button">Browser</button>
                                                <span>Choose A File...</span>
                                                <input type="file" name="logo" id="business_logo"  value="<?php echo $row['logo']?>" required><?php include 'preview.php'?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-10">
                                    <!-- first input field -->
                                    <div class="input-field" id="email-field">
                                        <label for="email-for-signUp">Enter Email to Signup & Receive Notification Upon
                                            Listing Approval</label>
                                        <input type="email" name="email-for-signUp" id="email-for-signUp"
                                            placeholder="your contact email">
                                    </div>

                                    <!-- Checkbox -->
                                    <div class="form-group">
                                        <input type="checkbox" id="toggle-account"> <label for="toggle-account">Already
                                            Have Account?</label>
                                    </div>

                                    <!-- second input field -->
                                    <div class="toggle-fields">
                                        <div class="input-field-2">
                                            <div class="first-field">
                                                <label for="username">Username</label>
                                                <input type="text" name="username" id="username" placeholder="Username">
                                            </div>
                                            <div class="second-field">
                                                <label for="password">Password</label>
                                                <input type="password" name="password" id="password"
                                                    placeholder="Password">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="submit-form">
                                <input type="submit" class="btn btn-success w-100" name="save_preview" value="Save & Preview">
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="scroll-card-container">
                        <div class="scroll-card" id="scroll-card">
                            <div class="card-content">
                                <h4 id="scroll-card-heading" name="buiness_title">Title</h4>
                                <p id="scroll-card-text" name="business_description">Enter your complete business name for when people who know
                                    your business by name and are looking you up.</p>
                                <img id="scroll-card-image" src="assets/imgs/scroll-title.png" alt="Image 1">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}

?>

    <!-- footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="copyright">Copyright © 2025 Bizvility</p>
                    <p class="developBy">Developed by Bizvility</p>
                    <div class="social-media">
                        <i class="fa-brands fa-square-facebook"></i>
                        <i class="fa-brands fa-square-x-twitter"></i>
                        <i class="fa-brands fa-square-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                        <i class="fa-solid fa-whiskey-glass"></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/7.6.0/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places"></script>
<script>
  function initAutocomplete() {
      var input = document.getElementById('address');
      var autocomplete = new google.maps.places.Autocomplete(input);

      autocomplete.addListener('place_changed', function () {
          var place = autocomplete.getPlace();
          console.log(place);
      });
  }

  google.maps.event.addDomListener(window, 'load', initAutocomplete);
</script>
<script>
    document.getElementById("business-image").addEventListener("change", function(event) {
        event.preventDefault(); // Prevent default form submission
    
        let formData = new FormData();
        formData.append("file", this.files[0]);
    
        fetch("upload.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            console.log(data);
            alert("File Uploaded Successfully!");
        })
        .catch(error => {
            console.error("Error:", error);
            alert("File upload failed!");
        });
    });
    </script>
    

</body>

</html>

<?php

if($_POST['save_preview'])
{
    $hotelName=$_POST['hotelName'];
    $tagline=$_POST['tagline'];
    $tagline_checkbox=$_POST['tagline_checkbox'];
    $full_address=$_POST['full_address'];
    $geolocation=$_POST['geolocation'];
    $city=$_POST['city'];
    $phone=$_POST['phone'];
    $website=$_POST['website'];
    $custom_address=$_POST['custom_address'];
    $latitude=$_POST['latitude'];
    $longitude=$_POST['longitude'];
    $business_category=$_POST['business_category'];
    $pinLocation=$_POST['pinLocation'];
    $action_type=$_POST['action_type'];
    $category=$_POST['category'];
    $delivery=$_POST['delivery'];
    $takeout=$_POST['takeout'];
    $air_conditioning=$_POST['air_conditioning']; 
    $dog_allowed=$_POST['dog_allowed'];
    $twenty_four_hours=$_POST['twenty_four_hours_open'];
    $wheelchair_accessible=$_POST['wheelchair_accessible'];
    $gender=$_POST['gender'];
    $payment_modes=$_POST['payment_modes'];
    $price_range=$_POST['price_range'];
    $price_from=$_POST['price_from'];
    $price_to=$_POST['price_to'];
    $business_hours=$_POST['business_hours'];
    $weekday=$_POST['weekday'];
    $start_time=$_POST['start_time'];
    $end_time=$_POST['end_time'];
    $is_24hours=$_POST['is_24hours'];
    $social_mdeia=$_POST['choose-social-media'];
    $faq_question=$_POST['faq_question'];
    $faq_answer=$_POST['faq_answer'];
    $file_name=$_POST['file_name'];
    $image_links=$_POST['image links'];
    $description=$_POST['description'];
    $tags=$_POST['tags'];
    $video_link=$_POST['video_link'];
    $email=$_POST['email'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $image_files=$_POST['image_files'];
    $logo=$_POST['logo'];

$query="NSERT INTO Users VALUES('$hotelName','$tagline','$tagline_checkbox','$full_address','$geolocation','$city','$phone','$website','$custom_address','$latitude','$longitude','$business_category','$pinLocation','$action_type','$category','$delivery','$takeout','$air_conditioning','$dog_allowed','$twenty_four_hours','$wheelchair_accessible','$gender','$payment_modes','$price_range','$price_from','$price_to','$business_hours','$weekday','$start_time','$end_time','$is_24hours','$faq_question','$faq_answer','$file_name','$image_links','$description','$tags','$video_link','$email',' $username','$password','$image_files',' $logo')"

require 'preview.php';
require 'submit.php';


$data=mysqli_query($conn,$query);

if($data)
{
    echo "Form data stored successfully.";
}
else{
    echo "failed to store data";
}
}
?>
