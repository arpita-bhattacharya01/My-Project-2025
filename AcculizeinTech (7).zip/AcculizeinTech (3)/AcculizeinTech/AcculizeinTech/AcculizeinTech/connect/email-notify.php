<?php
include_once 'config.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $status = $_POST['status']; // 'approved' or 'rejected'

    // Fetch user email
    $query = "SELECT email FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($email);
    $stmt->fetch();
    $stmt->close();

    if ($email) {
        $subject = "Your Listing Status Update";
        $message = "Hello,\n\nYour listing has been $status.\n\nRegards,\nBizvility Team";
        $headers = "From: bizvility@gmail.com";
     echo "<script>  window.location.href = 'index.html'; </script>";

        if (mail($email, $subject, $message, $headers)) {
            echo "Email notification sent!";
        } else {
            echo "Failed to send email.";
        }
    } else {
        echo "User not found.";
    }
}

?>
