<?php
include_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $enquiry_id = $_POST['enquiry_id'];
    $status = isset($_POST['approve']) ? 'approved' : 'rejected';

    // Fetch user email
    $sql = "SELECT email FROM enquiry WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $enquiry_id);
    $stmt->execute();
    $stmt->bind_result($email);
    $stmt->fetch();
    $stmt->close();

    // Update approval status
    $sql = "UPDATE enquiry SET approval_status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $enquiry_id);

    if ($stmt->execute()) {
        // Send email notification
        sendApprovalEmail($email, $status);
        echo "<script>
                alert('Enquiry has been " . ucfirst($status) . " successfully!');
                window.location.href = 'admin_dashboard.php';
              </script>";
    } else {
        echo "<script>alert('Error updating status!');</script>";
    }

    $stmt->close();
    $conn->close();
}

// Function to send email notification
function sendApprovalEmail($email, $status)
{
    $subject = "Enquiry Status Update";
    $message = ($status == 'approved') ?
        "Congratulations! Your enquiry has been approved. You may now proceed with further inquiries." :
        "We regret to inform you that your enquiry has been rejected. Please contact support for more information.";

    $headers = "From: bizvility@gamil.com\r\n";

    mail($email, $subject, $message, $headers);
}
