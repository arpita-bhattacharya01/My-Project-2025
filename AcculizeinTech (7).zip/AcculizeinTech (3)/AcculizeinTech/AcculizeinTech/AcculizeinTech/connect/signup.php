<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
session_start();

include_once 'config.php'; // Ensure correct path to config.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and validate input fields
    $errors = [];

    $fullname = isset($_POST['fullname']) ? trim($_POST['fullname']) : "";
    $email = isset($_POST['email']) ? trim($_POST['email']) : "";
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : "";
    $city = isset($_POST['city']) ? trim($_POST['city']) : "";
    $state = isset($_POST['state']) ? trim($_POST['state']) : "";
    $pincode = isset($_POST['pincode']) ? trim($_POST['pincode']) : "";
    $username = isset($_POST['username']) ? trim($_POST['username']) : "";
    $user_type = isset($_POST['user_type']) ? trim($_POST['user_type']) : "user"; // Default is 'user'
    $password = isset($_POST['password']) ? trim($_POST['password']) : "";
    $confirm_password = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : "";

    // Check for empty fields
    if (empty($fullname)) $errors[] = "Full Name is required.";
    if (empty($email)) $errors[] = "Email is required.";
    if (empty($phone)) $errors[] = "Phone is required.";
    if (empty($city)) $errors[] = "City is required.";
    if (empty($state)) $errors[] = "State is required.";
    if (empty($pincode)) $errors[] = "Pincode is required.";
    if (empty($username)) $errors[] = "Username is required.";
    if (empty($password)) $errors[] = "Password is required.";
    if (strlen($password) < 6) $errors[] = "Password must be at least 6 characters.";
    if (empty($confirm_password)) $errors[] = "Confirm Password is required.";
    if ($password !== $confirm_password) $errors[] = "Passwords do not match.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";

    // If user_type is 'admin', check registration limit (only 2 allowed)
    if ($user_type === 'admin') {
        $checkAdminQuery = "SELECT COUNT(*) FROM users WHERE user_type = 'admin'";
        $adminResult = $conn->query($checkAdminQuery);
        $adminCount = $adminResult->fetch_row()[0];

        if ($adminCount >= 2) {
            echo "<script>alert('Admin registrations are limited to 2.'); window.history.back();</script>";
            exit();
        }
    }

    // If there are errors, show them and stop execution
    if (!empty($errors)) {
        echo "<script>alert('" . implode("\n", $errors) . "'); window.history.back();</script>";
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Check if email already exists
    $checkQuery = "SELECT id FROM users WHERE email = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        echo "<script>alert('Email already registered! Please use another email.'); window.history.back();</script>";
        exit();
    }
    $checkStmt->close();

    // Insert new user into database
    $insertQuery = "INSERT INTO users (fullname, email, phone, city, state, pincode, username, password, user_type) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("sssssssss", $fullname, $email, $phone, $city, $state, $pincode, $username, $hashed_password, $user_type);

    if ($stmt->execute()) {
        // Store user details in session
        $_SESSION['user_id'] = $stmt->insert_id;
        $_SESSION['fullname'] = $fullname;
        $_SESSION['user_type'] = $user_type;

        // Redirect after successful registration
        echo "<script>
                alert('Account created successfully! Redirecting to the listing page.');
                window.location.href = '../index.html';
              </script>";
        exit();
    } else {
        echo "<script>alert('Registration failed! Please try again.'); window.history.back();</script>";
        exit();
    }

    $stmt->close();
    $conn->close();
}

?>
