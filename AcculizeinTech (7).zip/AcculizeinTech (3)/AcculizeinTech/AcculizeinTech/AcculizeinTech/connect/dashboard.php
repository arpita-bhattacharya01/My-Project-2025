<?php
// session_start();

// Redirect to index.html if not logged in
if (!isset($_SESSION['email'])) {
    header("Location: ../index.html");
    exit();
}

// Prevent going back to dashboard after logout
if (isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], 'logout.php') !== false) {
    header("Location: ../index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bizvility Dashboard</title>
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
</head>
<body>
    <h2>Welcome, <?php echo isset($_SESSION['fullname']) ? $_SESSION['fullname'] : 'User'; ?>!</h2>
    <a href="logout.php">Logout</a>
</body>
</html>
