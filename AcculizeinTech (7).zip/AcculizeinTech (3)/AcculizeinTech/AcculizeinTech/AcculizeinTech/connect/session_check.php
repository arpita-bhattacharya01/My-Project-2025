<?php
ob_start(); // Start output buffering
session_start();
require 'config.php'; //database connection
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}
?>