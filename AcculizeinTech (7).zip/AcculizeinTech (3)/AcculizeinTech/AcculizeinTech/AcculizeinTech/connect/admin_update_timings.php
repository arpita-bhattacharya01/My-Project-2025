<?php

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = $_POST['doctor_id'];
    foreach ($_POST['timings'] as $day => $times) {
        $opening_time = ($times['opening'] === 'Closed') ? 'Closed' : date("H:i:s", strtotime($times['opening']));
        $closing_time = ($times['closing'] === 'Closed') ? 'Closed' : date("H:i:s", strtotime($times['closing']));

        $stmt = $conn->prepare("UPDATE doctor_timings SET opening_time = ?, closing_time = ? WHERE doctor_id = ? AND day = ?");
        $stmt->bind_param("ssis", $opening_time, $closing_time, $doctor_id, $day);
        $stmt->execute();
    }
    echo "Timings updated successfully!";
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Timings</title>
</head>
<body>
    <h2>Update Doctor Timings</h2>
    <form method="POST">
        <input type="hidden" name="doctor_id" value="1">
        <?php
        $conn = new mysqli("localhost", "root", "", "doctor_portfolio");
        $timings_result = $conn->query("SELECT * FROM doctor_timings WHERE doctor_id = 1");
        while ($row = $timings_result->fetch_assoc()) { ?>
            <label><?php echo $row['day']; ?>:</label>
            <input type="text" name="timings[<?php echo $row['day']; ?>][opening]" value="<?php echo $row['opening_time']; ?>">
            <input type="text" name="timings[<?php echo $row['day']; ?>][closing]" value="<?php echo $row['closing_time']; ?>">
            <br>
        <?php } ?>
        <button type="submit">Update Timings</button>
    </form>
</body>
</html>
