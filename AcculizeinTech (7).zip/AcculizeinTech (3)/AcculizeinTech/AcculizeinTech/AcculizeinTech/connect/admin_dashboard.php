<?php
session_start();
require 'config.php'; //database connection

// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\Exception;

// require 'PHPMailer/Exception.php';
// require 'PHPMailer/PHPMailer.php';
// require 'PHPMailer/SMTP.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: connect/login.php");
    exit();
}

// Fetch user details
$user_id = $_SESSION['user_id'];
$query = $con->prepare("SELECT * FROM users WHERE user_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

$user_type = $user['user_type']; // Get user user_type
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css"> <!-- Your CSS File -->
</head>
<body>

<div class="sidebar">
    <h2>Dashboard</h2>
    <ul>
        <li><a href="admin_dashboard.php">Profile</a></li>
        <?php if ($user_type == 'admin') { ?>
            <li><a href="manage_enquiries.php">Manage Enquiries</a></li>
            <li><a href="manage_users.php">Manage Users</a></li>
        <?php } ?>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>

<div class="content">
    <h2>Update Profile Details</h2>

    <form action="admin_dashboard.php" method="POST">
        <label>Full Name:</label>
        <input type="text" name="fullname" value="<?= $user['fullname']; ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?= $user['email']; ?>" readonly>

        <label>Phone:</label>
        <input type="text" name="phone" value="<?= $user['phone']; ?>" required>

        <label>City:</label>
        <input type="text" name="city" value="<?= $user['city']; ?>">

        <label>State:</label>
        <input type="text" name="state" value="<?= $user['state']; ?>">

        <label>Pincode:</label>
        <input type="text" name="pincode" value="<?= $user['pincode']; ?>">

        <button type="submit" name="update_profile">Update Profile</button>
    </form>

    <h2>Update Password</h2>
    <form action="admin_dashboard.php" method="POST">
        <label>New Password:</label>
        <input type="password" name="new_password" required>

        <label>Confirm Password:</label>
        <input type="password" name="confirm_password" required>

        <button type="submit" name="update_password">Update Password</button>
    </form>

    <form action="download_pdf.php" method="POST">
        <button type="submit" name="download_pdf">Download Profile as PDF</button>
    </form>

    <?php if ($user_type == 'admin') { ?>
        <h2>Manage Enquiries</h2>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Category</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php
            $enq_query = $con->query("SELECT * FROM enquiry");
            while ($enquiry = $enq_query->fetch_assoc()) {
                echo "<tr>
                    <td>{$enquiry['id']}</td>
                    <td>{$enquiry['fullname']}</td>
                    <td>{$enquiry['email']}</td>
                    <td>{$enquiry['category']}</td>
                    <td>{$enquiry['approval_status']}</td>
                    <td>
                        <form method='POST'>
                            <input type='hidden' name='enquiry_id' value='{$enquiry['id']}'>
                            <button type='submit' name='approve'>Approve</button>
                            <button type='submit' name='reject'>Reject</button>
                        </form>
                    </td>
                </tr>";
            }
            ?>
        </table>
    <?php } ?>
</div>

</body>
</html>

<?php
// Handle Profile Update
if (isset($_POST['update_profile'])) {
    $fullname = $_POST['fullname'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];

    $stmt = $con->prepare("UPDATE users SET fullname=?, phone=?, city=?, state=?, pincode=? WHERE user_id=?");
    $stmt->bind_param("sssssi", $fullname, $phone, $city, $state, $pincode, $user_id);
    if ($stmt->execute()) {
        echo "<script>alert('Profile updated successfully!'); window.location='admin_dashboard.php';</script>";
    }
}

// Handle Password Update
if (isset($_POST['update_password'])) {
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $stmt = $con->prepare("UPDATE users SET password=? WHERE user_id=?");
    $stmt->bind_param("si", $new_password, $user_id);
    if ($stmt->execute()) {
        echo "<script>alert('Password updated successfully!'); window.location='admin_dashboard.php';</script>";
    }
}

// Handle Enquiry Approval/Rejection with Email
if (isset($_POST['approve']) || isset($_POST['reject'])) {
    $enquiry_id = $_POST['enquiry_id'];
    $status = isset($_POST['approve']) ? 'approved' : 'rejected';

    $stmt = $con->prepare("UPDATE enquiry SET approval_status=? WHERE id=?");
    $stmt->bind_param("si", $status, $enquiry_id);
    if ($stmt->execute()) {
        $enq_query = $con->prepare("SELECT email FROM enquiry WHERE id=?");
        $enq_query->bind_param("i", $enquiry_id);
        $enq_query->execute();
        $result = $enq_query->get_result();
        $enq = $result->fetch_assoc();
        
        sendEmail($enq['email'], $status);
        echo "<script>alert('Enquiry $status successfully!'); window.location='admin_dashboard.php';</script>";
    }
}

// Send Email Function
function sendEmail($to, $status) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@gmail.com';
        $mail->Password = 'your-email-password';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('your-email@gmail.com', 'Admin');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = "Enquiry Status Update";
        $mail->Body = "Your enquiry has been <b>$status</b>. Please proceed with payment if approved.";

        $mail->send();
    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
    }
}
?>
