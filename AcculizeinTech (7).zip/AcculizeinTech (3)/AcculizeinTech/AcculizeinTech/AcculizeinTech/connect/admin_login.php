<?php
session_start();
include_once "../config.php"; // Database connection
$hashed_password = password_hash("admin123", PASSWORD_BCRYPT);
$sql = "INSERT INTO admin (email, password) VALUES ('admin@example.com', '$hashed_password')";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_email = $_POST['email'];
    $admin_password = $_POST['password'];

    // Check credentials in database
    $sql = "SELECT id, password FROM admin WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admin_email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($admin_id, $hashed_password);
        $stmt->fetch();

        
        // Verify password
        if (password_verify($admin_password, $hashed_password)) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin_id;
            header("Location: admin_enquiries.php"); // Redirect to admin panel
            exit();
        } else {
            echo "<script>alert('Incorrect password!'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Admin not found!'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
