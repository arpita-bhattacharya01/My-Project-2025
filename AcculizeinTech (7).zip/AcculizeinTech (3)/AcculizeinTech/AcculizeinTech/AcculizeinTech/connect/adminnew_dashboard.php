<?php

session_start();
require_once 'config.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['user_type'])) {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['id'];
$user_type = $_SESSION['user_type'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Store user details in session
$_SESSION['fullname'] = $user['fullname'];
$_SESSION['phone'] = $user['phone'];
$_SESSION['city'] = $user['city']; // Ensure city is stored
$_SESSION['state'] = $user['state'];
$_SESSION['pincode'] = $user['pincode'];
$_SESSION['country'] = $user['country'];
$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name'] = $user['last_name'];
$_SESSION['about'] = $user['about'];
$_SESSION['facebook'] = $user['facebook'];
$_SESSION['instagram'] = $user['instagram'];
$_SESSION['twitter'] = $user['twitter'];
$_SESSION['linkedin'] = $user['linkedin'];
$_SESSION['pinterest'] = $user['pinterest'];
$_SESSION['address_line_1'] = $user['address_line_1'];
$_SESSION['address_line_2'] = $user['address_line_2'];
$_SESSION['image'] = $user['image'];




// Debug session image
// echo "<pre>Session Image on Dashboard Load: " . htmlspecialchars($_SESSION['image']) . "</pre>";


// Update Profile


// if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
//     $fullname = trim($_POST['fullname']);
//     $phone = trim($_POST['phone']);
//     $city = trim($_POST['city']);
//     $state = trim($_POST['state']);
//     $pincode = trim($_POST['pincode']);

//     $stmt = $conn->prepare("UPDATE users SET fullname = ?, phone = ?, city = ?, state = ?, pincode = ? WHERE id = ?");
//     $stmt->bind_param("sssssi", $fullname, $phone, $city, $state, $pincode, $user_id);

//     if ($stmt->execute()) {
//         echo "<script>alert('Profile updated successfully!'); window.location.href='admin_dashboard.php';</script>";
//     } else {
//         echo "<script>alert('Error updating profile!');</script>";
//     }
//     $stmt->close();
// }
// Check if the 'update' parameter is set in the URL



// Update Password
// if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_password'])) {
//     $new_password = $_POST['new_password'];
//     $connfirm_password = $_POST['confirm_password'];

//     if ($new_password === $connfirm_password) {
//         $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
//         $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
//         $stmt->bind_param("si", $hashed_password, $user_id);

//         if ($stmt->execute()) {
//             echo "<script>alert('Password updated successfully!'); window.location.href='admin_dashboard.php';</script>";
//         } else {
//             echo "<script>alert('Error updating password!');</script>";
//         }
//         $stmt->close();
//     } else {
//         echo "<script>alert('Passwords do not match!');</script>";
//     }
// }


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Update</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link rel="stylesheet" href="../assets/css/styles.css">
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="../assets//imgs/logo.png" alt="biZvility Logo">
            </div>
            <i class="fas fa-bars hamburger" id="sidebar-toggle"></i>
        </div>

        <ul>
            <a href="#">
                <li><i class="fa-solid fa-gauge"></i> <span>Dashboard</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-tags"></i> <span>Pricing-Plans</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-utensils"></i> <span>Users</span></li>
            </a>
            <a href="../listing.php">
                <li><i class="fa-solid fa-location-dot"></i> <span>Enquiry</span></li>
            </a>
            <a href="#">
                <li><i class="fa-regular fa-envelope"></i> <span>Inbox</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-paper-plane"></i> <span>Invoices</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-paper-plane"></i> <span>Ads Invoices</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-heart"></i> <span>Saved</span></li>
            </a>
            <a href="logout.php" style="text-decoration: none; color: inherit;">
                <i class="fa-solid fa-sign-out-alt"></i> <span>Logout</span>
            </a>

            </a>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="main-content">

        <!-- Top Navigation -->
        <div class="top-nav">
            <div class="nav-links">
                <a href="../pricing-plan.php">+ Add Listing</a>
                <a href="#">📞 Contact Support</a>
                <p><?php echo htmlspecialchars($_SESSION['fullname']); ?></p>
                <div class="leftdata">
                    <img id="profileImageforleft" src="<?php
                        $imageSrc = '';
                        if (!empty($_SESSION['image']) && $_SESSION['image'] !== 'default.jpg' && !strpos($_SESSION['image'], 'flaticon.com')) {
                            $imageSrc = '../uploads/profile_images/' . $_SESSION['image'];
                        } else {
                            $imageSrc = 'default.jpg'; // Adjust this to the correct path/URL of your default image
                        }
                        // Handle NULL or empty explicitly
                        if (empty($_SESSION['image']) || $_SESSION['image'] === null) {
                            $imageSrc = 'default.jpg'; // Or your placeholder image path
                        }
                        echo htmlspecialchars($imageSrc);
                    ?>" alt="Profile Picture">
                </div>
                <i class="fas fa-bars top-nav-hamburger" id="top-nav-toggle"></i> <!-- Hamburger Icon Added Here -->
            </div>
        </div>
        <div class="open-profile-box">
            <ul>
                <a href="#">
                    <li>
                        <i class="fa-solid fa-circle-user"></i>
                        My Profile
                    </li>
                </a>
                <a href="../connect/logout.php">
                    <li>
                        <i class="fa-solid fa-lock"></i>
                        Logout
                    </li>
                </a>
            </ul>
        </div>
        <div class="container-title">
            <h2>Update Profile Details</h2>
        </div>

        <!-- Profile Update Section -->
        <form method="POST" action="updateprofile.php" enctype="multipart/form-data">
            <div class="container">
                <div class="profile-pic">
                    <!-- Profile Preview Image -->
                    <img id="profilePreview" src="<?php
                        $imageSrc = '';
                        if (!empty($_SESSION['image']) && $_SESSION['image'] !== 'default.jpg' && !strpos($_SESSION['image'], 'flaticon.com')) {
                            $imageSrc = '../uploads/profile_images/' . $_SESSION['image'];
                        } else {
                            $imageSrc = 'default.jpg'; // Adjust this to the correct path/URL of your default image
                        }
                        // Handle NULL or empty explicitly
                        if (empty($_SESSION['image']) || $_SESSION['image'] === null) {
                            $imageSrc = 'default.jpg'; // Or your placeholder image path
                        }
                        echo htmlspecialchars($imageSrc);
                    ?>" alt="Profile"  >

                    <!-- <img id="profileImage" src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                        alt="Profile Picture"> -->
                    <div class="update-profile-text">
                        <p>Update your photo manually If the photo is not set the default Gravatar will be the same as
                            your
                            login email account</p>
                        <button type="button" class="upload-btn" onclick="document.getElementById('fileInput').click();">
                            <i class="fas fa-upload"></i> Upload Photo
                        </button>
                    </div>
                    <input type="file" id="fileInput" name="profile_image" style="display: none;" accept="image/*">

                </div>
                <div class="input-field input-field-1">
                    <div class="input-box">
                        <label>First Name</label>
                        <input type="text" name="first-name" value="<?php echo htmlspecialchars($_SESSION['first_name']); ?>" placeholder="Enter First Name">
                    </div>
                    <div class="input-box">
                        <label>Last Name</label>
                        <input type="text" name="last-name" value="<?php echo htmlspecialchars($_SESSION['last_name']); ?>" placeholder="Enter Last Name">
                    </div>
                    <div class="input-box">
                        <label>Display Name</label>
                        <input type="text" name="display-name" value="<?php echo htmlspecialchars($_SESSION['fullname']); ?>" placeholder="admin">

                    </div>
                </div>
                <div class="input-field input-field-2">
                    <div class="full-width input-box">
                        <label>Email*</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" placeholder="Enter Email">
                    </div>
                    <div class="input-box">
                        <label>Phone</label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($_SESSION['phone']); ?>" name="phone" id="phone" placeholder="+91 12345 78900">
                    </div>
                </div>
                <div class="input-field input-field-2">
                    <div class="full-width input-box">
                        <label>Adress 1st Line</label>
                        <input type="text" name="address-line-1" value="<?php echo htmlspecialchars($_SESSION['address_line_1']); ?>" placeholder="Your Address (1st line)">
                    </div>
                    <div class="input-box">
                        <label>Adress 2nd Line</label>
                        <input type="text" name="address-line-2" value="<?php echo htmlspecialchars($_SESSION['address_line_2']); ?>" placeholder="Your Address (2nd line)">
                    </div>
                </div>
                <div class="input-field input-field-3">
                    <div class="full-width input-box">
                        <label>City</label>
                        <input type="text" name="city" value="<?php echo htmlspecialchars($_SESSION['city']); ?>" placeholder="Your City">
                    </div>
                    <div class="input-box">
                        <label>Zip Code</label>
                        <input type="number" name="zip-code" value="<?php echo htmlspecialchars($_SESSION['pincode']); ?>" placeholder="Zip Code">
                    </div>
                    <div class="input-box">
                        <label>State</label>
                        <input type="text" name="state" value="<?php echo htmlspecialchars($_SESSION['state']); ?>" name="state" id="state" placeholder="State">
                    </div>
                    <div class="input-box">
                        <label>Country*</label>
                        <input type="text" name="country" value="<?php echo htmlspecialchars($_SESSION['country']); ?>" name="country" id="country" placeholder="Country">
                    </div>
                </div>
                <div class="input-field input-field-textarea">
                    <div class="input-box">
                        <label>About Yourself</label>
                        <textarea name="about-message" value="<?php echo htmlspecialchars($_SESSION['about']); ?>" id="about-message" placeholder="Write about yourself"></textarea>
                    </div>
                </div>
                <div class="input-field input-field-2">
                    <div class="input-box">
                        <label>Facebook</label>
                        <input type="text" value="<?php echo htmlspecialchars($_SESSION['facebook']); ?>" name="facebook-url" placeholder="Enter facebook profile url">
                    </div>
                    <div class="full-width input-box">
                        <label>Twitter</label>
                        <input type="text" value="<?php echo htmlspecialchars($_SESSION['twitter']); ?>" name="twitter-url" placeholder="Enter twitter profile url">
                    </div>
                </div>
                <div class="input-field input-field-2">
                    <div class="input-box">
                        <label>Linkedin</label>
                        <input type="text" value="<?php echo htmlspecialchars($_SESSION['linkedin']); ?>" name="linkedin-url" placeholder="Enter linkedin profile url">
                    </div>
                    <div class="full-width input-box">
                        <label>Instagram</label>
                        <input type="text" value="<?php echo htmlspecialchars($_SESSION['instagram']); ?>" name="instagram-url" placeholder="Enter instagram profile url">
                    </div>
                </div>
                <div class="input-field input-field-2">
                    <div class="input-box">
                        <label>Pinterest</label>
                        <input type="text" value="<?php echo htmlspecialchars($_SESSION['pinterest']); ?>" name="pinterest-url" placeholder="Enter pinterest profile url">
                    </div>
                    <div class="input-box"></div>
                </div>
            </div>

            <div class="container-title container-title-2">
                <h2>Update Password</h2>
            </div>
            <div class="container">
                <div class="input-field input-field-2">
                    <div class="input-box">
                        <label>New Password</label>
                        <input type="password" class="new-password-input" name="password" placeholder="Enter new password">
                    </div>
                    <div class="full-width input-box">
                        <label>Repeat Password</label>
                        <input type="text" placeholder="Write again your new password">
                    </div>
                </div>
                <p>Enter same password in both fields Use an uppercase letter and a number for stronger password.</p>
                <div class="submit-btn">
                    <button type="submit" class="update-profile-btn">Update Profile</button>
                </div>
            </div>

        </form>


        <div class="download-pdf">
            <button type="button"><a href="#"><i class="fa-solid fa-download"></i>Download Profile</a></button>
        </div>
    </div>
    <!-- JavaScript to preview image -->
    <script>
        const fileInput = document.getElementById('fileInput');
        const profilePreview = document.getElementById('profilePreview');

        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    profilePreview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            } else {
                // If no file is selected, revert to the original or default image
                profilePreview.src = "<?php echo htmlspecialchars($_SESSION['image'] ?? 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'); ?>";
            }
        });
    </script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="../assets/js/scripts.js"></script>


</body>

</html>