<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = $_POST['doctor_id'];
    $claimed = $_POST['claimed'] == '1' ? 1 : 0;

    $stmt = $conn->prepare("UPDATE doctors SET claimed = ? WHERE id = ?");
    $stmt->bind_param("ii", $claimed, $doctor_id);
    $stmt->execute();
    
    echo "Doctor's claim status updated!";
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Claim Status</title>
</head>
<body>
    <h2>Update Claim Status</h2>
    <form method="POST">
        <input type="hidden" name="doctor_id" value="1">
        <label>Claimed:</label>
        <select name="claimed">
            <option value="1">✔️ Claimed</option>
            <option value="0">❌ Not Claimed</option>
        </select>
        <button type="submit">Update</button>
    </form>
</body>
</html>
