<?php
session_start();
require 'config.php'; //database connection

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch all enquiries
$query = $con->query("SELECT * FROM enquiry");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

function sendEmail($to, $status) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '01arpitabhattacharya@gmail.com';
        $mail->Password = '1234';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('01arpitabhattacharya@gmail.com', 'Admin');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = "Enquiry Status Update";
        $mail->Body = "Your enquiry has been <b>$status</b>. Please proceed with payment if approved.";

        $mail->send();
    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
    }
}

// Handle Approval/Rejection
if (isset($_POST['approve']) || isset($_POST['reject'])) {
    $enquiry_id = $_POST['enquiry_id'];
    $status = isset($_POST['approve']) ? 'approved' : 'rejected';

    $stmt = $con->prepare("UPDATE enquiry SET approval_status=? WHERE id=?");
    $stmt->bind_param("si", $status, $enquiry_id);
    if ($stmt->execute()) {
        $enq_query = $con->prepare("SELECT email FROM enquiry WHERE id=?");
        $enq_query->bind_param("i", $enquiry_id);
        $enq_query->execute();
        $result = $enq_query->get_result();
        $enq = $result->fetch_assoc();

        sendEmail($enq['email'], $status);
        echo "<script>alert('Enquiry $status successfully!'); window.location='manage_enquiries.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Enquiries</title>
</head>
<body>
    <h2>Manage Enquiries</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Category</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($enquiry = $query->fetch_assoc()) { ?>
            <tr>
                <td><?= $enquiry['id']; ?></td>
                <td><?= $enquiry['fullname']; ?></td>
                <td><?= $enquiry['email']; ?></td>
                <td><?= $enquiry['category']; ?></td>
                <td><?= $enquiry['approval_status']; ?></td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="enquiry_id" value="<?= $enquiry['id']; ?>">
                        <button type="submit" name="approve">Approve</button>
                        <button type="submit" name="reject">Reject</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>
    <br>
    <a href="admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
