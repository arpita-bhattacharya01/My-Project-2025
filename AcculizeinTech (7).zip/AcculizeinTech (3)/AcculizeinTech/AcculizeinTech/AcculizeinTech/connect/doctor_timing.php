<?php
// Include database connection
include 'config.php';

// Fetch doctor's timing (modify according to database structure)
$sql = "SELECT * FROM timings WHERE doctor_id = 1"; // Change ID dynamically if needed
$result = $conn->query($sql);

// Store timings in an array
$timings = [];
while ($row = $result->fetch_assoc()) {
    $timings[$row['day']] = $row['opening_time'] . " - " . $row['closing_time'];
}

$conn->close();
?>

<div class="open-closing-timing">
    <div class="timing-list">
        <div class="time">
            <div class="day-time-icon">
                <i class="fa-regular fa-clock"></i>
                <p class="close"><?= (date('H:i') < "09:00" || date('H:i') > "17:00") ? "Close Now" : "Open Now" ?></p>
            </div>
            <span><?= $timings['Monday'] ?? "09:00AM - 05:00PM" ?></span>
        </div>

        <?php
        $days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
        foreach ($days as $day) :
        ?>
            <div class="time">
                <div class="day-time-icon">
                    <p><?= $day ?></p>
                </div>
                <span><?= $timings[$day] ?? "09:00AM - 05:00PM" ?></span>
            </div>
        <?php endforeach; ?>
    </div>
</div>
