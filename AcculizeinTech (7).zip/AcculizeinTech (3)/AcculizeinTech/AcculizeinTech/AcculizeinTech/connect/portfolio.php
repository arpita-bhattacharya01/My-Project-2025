<?php 
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$doctor_id = 1; 
$sql = "SELECT * FROM doctors WHERE id = $doctor_id";
$result = $conn->query($sql);
$doctor = $result->fetch_assoc();

$sql_reviews = "SELECT * FROM reviews WHERE doctor_id = $doctor_id";
$reviews = $conn->query($sql_reviews);

$sql="ALTER TABLE doctors ADD COLUMN claimed BOOLEAN DEFAULT 0";

$sql="UPDATE doctors SET claimed = 1 WHERE id = 1";


$doctor_id = 1; 

// Fetch doctor details
$sql = "SELECT * FROM doctors WHERE id = $doctor_id";
$result = $conn->query($sql);
$doctor = $result->fetch_assoc();

// Fetch working hours
$sql_timings = "SELECT * FROM doctor_timings WHERE doctor_id = $doctor_id";
$timings_result = $conn->query($sql_timings);
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $doctor['name']; ?> - Profile</title>
</head>
<body>

<h1>
        <?php echo $doctor['name']; ?>
        <?php if ($doctor['claimed']) { ?>
            <span class="verified">✔️ Claimed</span>
        <?php } else { ?>
            <span class="not-verified">❌ Not Claimed</span>
        <?php } ?>
    </h1>

    <?php echo $doctor['specialty']; ?>
  <?php echo $doctor['description']; ?>
 <?php echo $doctor['address']; ?>
   <?php echo $doctor['contact']; ?>
    <img src="<?php echo $doctor['image']; ?>" width="200">

    <video src="<?php echo $video['video'];?>" width="200"></video>

    <p><strong>Services:</strong> <?php echo $service['service']; ?></p>
    
    <p><a href="<?php echo $doctor['map_link']; ?>" target="_blank">Get Directions</a></p>
    
    <h2>Reviews</h2>
    <?php while ($row = $reviews->fetch_assoc()) { ?>
        <p><strong>Rating:</strong> <?php echo $row['rating']; ?>/5</p>
        <p><?php echo $row['comment']; ?></p>
    <?php } ?>

    <h2>Working Hours</h2>
    <table border="1">
        <tr>
            <th>Day</th>
            <th>Opening Time</th>
            <th>Closing Time</th>
        </tr>
        <?php while ($row = $timings_result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['day']; ?></td>
            <td><?php echo ($row['opening_time'] == 'Closed') ? 'Closed' : date("h:i A", strtotime($row['opening_time'])); ?></td>
            <td><?php echo ($row['closing_time'] == 'Closed') ? 'Closed' : date("h:i A", strtotime($row['closing_time'])); ?></td>
        </tr>
        <?php } ?>

    <h3>Submit a Review</h3>
    <form method="POST" action="submit_review.php">
        <input type="hidden" name="doctor_id" value="<?php echo $doctor_id; ?>">
        <label>Rating (out of 5):</label>
        <input type="number" name="rating" step="0.1" min="1" max="5" required>
        <label>Comment:</label>
        <textarea name="comment" required></textarea>
        <button type="submit">Submit</button>
    </form>
</body>
</html>

<?php $conn->close(); ?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = $_POST["doctor_id"];
    $rating = $_POST["rating"];
    $comment = $_POST["comment"];

    $conn = new mysqli($host, $user, $pass, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO reviews (doctor_id, rating, comment) VALUES (?, ?, ?)");
    $stmt->bind_param("ids", $doctor_id, $rating, $comment);

    if ($stmt->execute()) {
        echo "Review submitted successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
