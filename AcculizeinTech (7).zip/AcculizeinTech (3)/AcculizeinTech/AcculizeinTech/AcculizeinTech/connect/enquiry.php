<?php
session_start();
ob_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once 'config.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plan_id = $_POST['planId'];
    $category = $_POST['category'];
    $other_category = $_POST['other_category'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $user_id = $_SESSION['id'] ?? null;
    $user_fullname_db = $_SESSION['fullname'] ?? '';
    $user_email_db = $_SESSION['email'] ?? '';
    $user_phone_db = $_SESSION['phone'] ?? '';

    if (!$user_id) {
        $_SESSION['mismatch_message'] = "User session expired. Please log in again.";
        header("Location: ../pricing-plan.php?error=session_expired");
        exit;
    }

    if (
        $fullname !== $user_fullname_db ||
        $email !== $user_email_db ||
        $phone !== $user_phone_db
    ) {
        $_SESSION['mismatch_message'] = "The Full Name, Email, or Phone Number does not match your profile.";
        header("Location: ../pricing-plan.php?error=mismatch");
        exit;
    }

    // Step 1: Fetch duration of the selected plan
    $stmt_check_plan = $conn->prepare("SELECT duration FROM plans WHERE id = ?");
    $stmt_check_plan->bind_param("i", $plan_id);
    $stmt_check_plan->execute();
    $plan_result = $stmt_check_plan->get_result()->fetch_assoc();
    $stmt_check_plan->close();

    // Step 2: Set approval_status based on duration
    $approval_status = 'pending';
    $redirect_url_param = 'success=true';

    if ($plan_result && $plan_result['duration'] === 'yearly') {
        $approval_status = 'approved';
        $_SESSION['success_message'] = "Your enquiry for the yearly plan was submitted and will be processed. Check your email shortly.";
        $redirect_url_param = 'yearly_approved=true';
    } else {
        $_SESSION['success_message'] = "Your enquiry was submitted successfully! We will review it shortly.";
    }

    // Step 3: Insert the enquiry into the database
    $stmt_insert = $conn->prepare("INSERT INTO enquiry (user_id, plan_id, category, other_category, approval_status) VALUES (?, ?, ?, ?, ?)");
    $stmt_insert->bind_param("iisss", $user_id, $plan_id, $category, $other_category, $approval_status);

    if ($stmt_insert->execute()) {
        // ✅ Step 4: Get the ID of the inserted enquiry
        $enquiry_id = $conn->insert_id;  // 🔥 THIS IS WHERE IT'S DEFINED

        // 🔍 Optional safety: If insert_id fails (edge case), fetch the last inserted enquiry manually
        if (!$enquiry_id) {
            $stmt_last_id = $conn->prepare("SELECT id FROM enquiry WHERE user_id = ? ORDER BY id DESC LIMIT 1");
            $stmt_last_id->bind_param("i", $user_id);
            $stmt_last_id->execute();
            $result = $stmt_last_id->get_result()->fetch_assoc();
            $enquiry_id = $result['id'] ?? null;
            $stmt_last_id->close();   
        }

        // ✅ Step 5: If it's a yearly plan (already marked approved), call function with enquiry ID
        if ($approval_status === 'approved' && $enquiry_id) {
            require_once 'update_enquiry_status.php';

            // 🔁 Pass enquiry_id to the function to update and send email
            $result = updateEnquiryStatusAndSendEmail($enquiry_id, "approved");

            if ($result === true) {
                header("Location: ../pricing-plan.php?" . $redirect_url_param);
            } else {
                $_SESSION['warning_message'] = "Enquiry approved but email sending failed.";
                header("Location: ../pricing-plan.php?email_failed=true");
            }
            exit();
        } else {
            // ✅ For pending plans
            header("Location: ../pricing-plan.php?" . $redirect_url_param);
            exit();
        }
    } else {
        // 🔴 Insert failed
        $_SESSION['db_error'] = "Failed to submit enquiry: " . $stmt_insert->error;
        header("Location: ../pricing-plan.php?error=db");
        exit();
    }

    $stmt_insert->close();
}
?>
