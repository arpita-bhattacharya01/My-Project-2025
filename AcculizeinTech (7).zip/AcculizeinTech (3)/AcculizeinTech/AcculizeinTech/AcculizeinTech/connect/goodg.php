<?php

session_start();
require_once 'config.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['user_type'])) {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['id'];
$user_type = $_SESSION['user_type'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Store user details in session
$_SESSION['fullname'] = $user['fullname'];
$_SESSION['phone'] = $user['phone'];
$_SESSION['city'] = $user['city']; // Ensure city is stored
$_SESSION['state'] = $user['state'];
$_SESSION['pincode'] = $user['pincode'];
$_SESSION['country'] = $user['country'];
$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name'] = $user['last_name'];
$_SESSION['about'] = $user['about'];
$_SESSION['facebook'] = $user['facebook'];
$_SESSION['instagram'] = $user['instagram'];
$_SESSION['twitter'] = $user['twitter'];
$_SESSION['linkedin'] = $user['linkedin'];
$_SESSION['pinterest'] = $user['pinterest'];
$_SESSION['address_line_1'] = $user['address_line_1'];
$_SESSION['address_line_2'] = $user['address_line_2'];
$_SESSION['image'] = $user['image'];




// session_start();
// require_once 'config.php'; // Database connection

// // Check if the user is logged in
// if (!isset($_SESSION['id']) || !isset($_SESSION['user_type'])) {
//     header("Location: signin.php");
//     exit;
// }

// $user_id = $_SESSION['id'];
// $user_type = $_SESSION['fullname'];






// // Fetch user details
// $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
// $stmt->bind_param("i", $user_id);
// $stmt->execute();
// $user = $stmt->get_result()->fetch_assoc();
// $stmt->close();

// // Store user details in session
// $_SESSION['image'] = $user_image['image'];
// 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bizvility &#8211; Dare To Grow</title>
    <link rel="shortcut icon" type="image/x-icon" href="../assets/imgs/bizvility-logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<style>

</style>

<body>

    <!-- navbar -->
    <nav class="navbar">
        <div class="logo ms-3">
            <a href="index.html">
                <img src="../assets/imgs/logo.png" width="220" height="70" alt="">
            </a>
        </div>
        <ul class="nav-btns me-3">
            <div class="d-flex align-items-center gap-4">
                <a href="../career.html" class="btn btn-outline-light">Career</a>

                <div class="dropdown">
                    <button class="d-flex align-items-center border-0 bg-transparent dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <img id="profilePreview" src="<?php
                                                        $imageSrc = '';
                                                        if (!empty($_SESSION['image']) && $_SESSION['image'] !== 'default.jpg' && !strpos($_SESSION['image'], 'flaticon.com')) {
                                                            $imageSrc = '../uploads/profile_images/' . $_SESSION['image'];
                                                        } else {
                                                            $imageSrc = '../assets/imgs/avatar.jpg'; // Correct path to your default image
                                                        }
                                                        // Handle NULL or empty explicitly
                                                        if (empty($_SESSION['image']) || $_SESSION['image'] === null) {
                                                            $imageSrc = '../assets/imgs/avatar.jpg'; // Correct path to your default image
                                                        }
                                                        echo htmlspecialchars($imageSrc);
                                                        ?>" alt="User Profile Picture" style="width: 45px; height: 45px; border-radius: 100%;">
                        <!-- <img src="../assets/imgs/avatar.jpg" alt="User Image" class="rounded-circle" width="30" height="30"> -->
                        <p class="mb-0 ms-2" style="font-size: 16px; color:white;">
                            <?= htmlspecialchars($user['fullname']); ?> <?= $user['is_admin'] ? '<span class="badge bg-warning text-dark"></span>' : ''; ?>
                        </p>
                    </button>

                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <?php if ($user['is_admin']) : ?>
                            <!-- Admin Links -->
                            <li><a class="dropdown-item" style="color: black;" href="adminnew_dashboard.php">Admin Dashboard</a></li>
                            <li><a class="dropdown-item" style="color: black;" href="adminnew_dashboard.php">Update Profile</a></li>
                            <!-- <li><a class="dropdown-item" style="color: black;" href="manage-users.php">Manage Users</a></li> -->
                        <?php else : ?>
                            <!-- Regular User Links -->
                            <li><a class="dropdown-item" style="color: black;" href="userss_dashboard.php">Dashboard</a></li>
                            <li><a class="dropdown-item" style="color: black;" href="userss_dashboard.php">Update Profile</a></li>
                        <?php endif; ?>


                        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                    </ul>
                </div>

        </ul>
        <i class="fa-solid fa-bars menu-open"></i>
        <i class="fa-solid fa-xmark menu-close"></i>
    </nav>

    <div class="side-menu">
        <ul class="side-links">
            <button class="btn btn-outline-light">Career</button>
            <button class="btn btn-primary">
                <a href="pricing-plan.html">
                    <i class="fa-solid fa-circle-plus"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
    </div>

    <!-- Modal -->
    <div class="popup_main">
        <div class="popup_body">
            <div class="popup_back"></div>
            <div class="popup_contain">
                <div class="popup_close">&times;</div>
                <div class="left">
                    <img src="../assets/imgs/signIn-img.jpg" alt="Placeholder Image">
                    <button class="toggle-btn" id="toggle-auth">Click to Sign In</button>
                </div>
                <div class="right">
                    <div class="form-container active" id="signup-form">
                        <h3>Create new account</h3>
                        <hr>
                        <form action="connect/signup.php" method="post">
                            <input type="text" name="fullname" id="fullName" placeholder="Your Full Name" required>
                            <input type="email" name="email" id="email" placeholder="Your Email" required>
                            <input type="tel" name="phone" id="phone" placeholder="Your Phone Number" required>
                            <input type="text" name="city" id="state" placeholder="City" required>
                            <input type="text" name="state" id="state" placeholder="State" required>
                            <input type="number" name="pincode" id="pincode" placeholder="Pincode" required>
                            <input type="text" name="username" id="username" placeholder="Username" required>
                            <!-- User Type Dropdown -->
                            <!-- <select name="user_type" id="user_type" required>
                                <option value="" disabled selected>Select User Type</option>
                                <option value="user">User</option>
                                <option value="seller">Seller</option>
                                <option value="admin">Admin</option>
                            </select> -->
                            <div class="form-group">
                                <input type="password" name="password" id="password" placeholder="Password" required>
                                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                            </div>

                            <div class="form-group">
                                <input type="password" name="confirm_password" id="confirm_password"
                                    placeholder="Confirm Password" required>
                                <span class="toggle-password" onclick="togglePassword('confirm_password')">👁</span>
                            </div>
                            <div class="form-btns">
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <button type="submit" class="btn btn-primary">Sign Up</button>
                            </div>
                        </form>
                        <div class="form-toggle">
                            <button class="toggle-btn" id="toggle-auth-2">Click to Sign In</button>
                        </div>
                    </div>
                </div>
                <div class="form-container" id="signin-form">
                    <h3>Sign In</h3>
                    <form action="connect/signin.php" method="post">
                        <input type="text" class="mb-2" name="username" placeholder="Username" required>
                        <div class="form-group">
                            <input type="password" name="signin-password" id="signin-password" placeholder="Password"
                                required>
                            <span class="toggle-password" onclick="togglePassword('signin-password')">👁</span>
                        </div>
                        <div class="form-btns">
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <button type="submit" class="btn btn-primary">Sign In</button>
                        </div>
                    </form>
                    <div class="form-toggle">
                        <button class="toggle-btn" id="toggle-auth-3">Click to Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- main -->
    <div class="main">
        <div class="container main-container">
            <div class="row">

                <div class="col-lg-12 col-md-12">
                    <div class="title">
                        <h2>Explore Your City</h2>
                        <p>Let's uncover the best places to eat, drink, and shop nearest to you.</p>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12">
                    <div class="select-what-where">
                        <div class="selection-area">
                            <div class="dropdown-container">
                                <label for="what">What</label>
                                <div class="dropdown">
                                    <input type="text" class="dropdown-input" id="what-input"
                                        placeholder="Ex: food, service, barber, hotel">
                                    <div class="dropdown-list" id="what-list">
                                        <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment
                                        </option>
                                        <option class="dropdown-item" value="automotive">Automotive</option>
                                        <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                                        <option class="dropdown-item" value="health&medical">Health & Medical</option>
                                        <option class="dropdown-item" value="hotels">Hotels</option>
                                        <option class="dropdown-item" value="italian">Italian</option>
                                    </div>
                                </div>
                            </div>

                            <div class="dropdown-container">
                                <label for="where">Where</label>
                                <div class="dropdown">
                                    <input type="text" class="dropdown-input" id="where-input"
                                        placeholder="Your City...">
                                    <div class="dropdown-list" id="where-list"></div>
                                </div>
                            </div>

                            <button class="btn search-btn btn-primary">
                                <i class="fa-solid fa-magnifying-glass"></i>
                                Search
                            </button>
                        </div>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12">
                    <div class="btn-categories">
                        <button class="btn doctors">
                            <a href="../doctors-list.html">
                                <i class="fa-solid fa-stethoscope"></i>
                                Doctors
                            </a>
                        </button>
                        <button class="btn beauty-spa">
                            <a href="listing.html">
                                <i class="fa-solid fa-spa"></i>
                                Beauty & Spa
                            </a>
                        </button>
                        <button class="btn hotels">
                            <a href="listing.html">
                                <i class="fa-solid fa-hotel"></i>
                                Hotels
                            </a>
                        </button>
                        <button class="btn automative">
                            <a href="listing.html">
                                <i class="fa-solid fa-car"></i>
                                Automative
                            </a>
                        </button>
                    </div>
                </div>

                <div class="btn-categories btn-categories-2">
                    <div class="col-md-12">
                        <div class="first-category">
                            <button class="btn doctors-2">
                                <a href="doctors-list.html">
                                    <i class="fa-solid fa-stethoscope"></i>
                                    Doctor
                                </a>
                            </button>
                            <button class="btn beauty-spa-2">
                                <a href="listing.html">
                                    <i class="fa-solid fa-spa"></i>
                                    Beauty & Spa
                                </a>
                            </button>
                            <button class="btn hotels-2">
                                <a href="listing.html">
                                    <i class="fa-solid fa-hotel"></i>
                                    Hotels
                                </a>
                            </button>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="second-category">
                            <button class="btn hotels-2 hotels-3">
                                <a href="listing.html">
                                    <i class="fa-solid fa-hotel"></i>
                                    Hotels
                                </a>
                            </button>

                            <button class="btn automative-2">
                                <a href="listing.html">
                                    <i class="fa-solid fa-car"></i>
                                    Automative
                                </a>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- happening cities -->
    <div class="happening-cities">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-md-12">
                    <div class="title">
                        <h2>Happening Cities</h2>
                        <p>Cities You Must Explore This Summer</p>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="agra">
                        <img src="../assets/imgs/AgraFort.jpg" alt="">
                        <div class="img-layer">
                            <h5>Agra</h5>
                            <p>7 Listing</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="three-cities">
                        <div class="firozabad">
                            <img src="../assets/imgs/glass-bangles.jpeg" alt="">
                            <div class="img-layer">
                                <h5>Firozabad</h5>
                                <p>0 Listing</p>
                            </div>
                        </div>

                        <div class="two-cities">
                            <div class="col-lg-6 col-md-6">
                                <div class="mathura-vrindavan">
                                    <img src="../assets/imgs/mathura-vrindavan.jpg" alt="">
                                    <div class="img-layer">
                                        <h5>Mathura</h5>
                                        <p>0 Listing</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="new-delhi">
                                    <img src="../assets/imgs/New-Delhi.jpg" alt="">
                                    <div class="img-layer">
                                        <h5>New Delhi</h5>
                                        <p>0 Listing</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="firozabad firozabad-2">
                        <img src="../assets/imgs/glass-bangles.jpeg" alt="">
                        <div class="img-layer">
                            <h5>Firozabad</h5>
                            <p>0 Listing</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="mathura-2">
                        <img src="../assets/imgs/mathura-vrindavan.jpg" alt="">
                        <div class="img-layer">
                            <h5>Mathura</h5>
                            <p>0 Listing</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="new-delhi-2">
                        <img src="../assets/imgs/New-Delhi.jpg" alt="">
                        <div class="img-layer">
                            <h5>New Delhi</h5>
                            <p>0 Listing</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- community -->
    <div class="community-section">
        <div class="container">
            <div class="row">

                <div class="col-lg-12">
                    <div class="community">
                        <div class="community-layer">
                            <h2>Are You a Local Business?</h2>
                            <p>Join the community of hundreds of flourishing local business in your city.</p>
                            <div class="btn-groups">
                                <button class="btn btn-primary get-started">Get Started</button>
                                <button class="btn claim-business">Claim Your Business</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Background Overlay (Custom Div for Blur) -->
    <div class="custom-background" id="backgroundOverlay"></div>

    <!-- Modal Overlay -->
    <div class="modal-overlay" id="popupOverlay">
        <div class="custom-modal" id="popupBox">
            <span class="custom-modalclose-btn" onclick="closePopup()">&times;</span>
            <div class="welcome">
                <img src="../assets/imgs/logo.png" class="modal-logo" alt="Logo">
                <div class="text">
                    <h6>Welcome</h6>
                    <p>Login for a seamless experience</p>
                </div>
            </div>
            <div class="custom-number-input">
                <span class="country-code">+91</span>
                <input type="tel" placeholder="Enter Mobile Number" maxlength="10">
            </div>
            <div class="checkbox-condition">
                <input type="checkbox" class="modal-checkbox" id="termsCheck">
                <label for="termsCheck">I Agree to Terms and Conditions</label>
            </div>
            <button class="modal-btn">Login with OTP</button>
            <p class="maybe-later" onclick="closePopup()">Maybe Later</p>
        </div>
    </div>


    <!-- footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="copyright">Copyright © 2025 Bizvility</p>
                    <p class="developBy">Developed by Bizvility</p>
                    <div class="social-media">
                        <i class="fa-brands fa-square-facebook"></i>
                        <i class="fa-brands fa-square-x-twitter"></i>
                        <i class="fa-brands fa-square-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                        <i class="fa-solid fa-whiskey-glass"></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        window.history.pushState(null, "", window.location.href);
        window.onpopstate = function() {
            window.history.pushState(null, "", window.location.href);
        };
    </script>
    <script>
        // Function to open modal after 5 seconds
        document.addEventListener("DOMContentLoaded", function() {
            let isLoggedIn = <?php echo json_encode($user_id); ?>; // Get PHP session value

            if (!isLoggedIn) {
                setTimeout(function() {
                    let overlay = document.getElementById("popupOverlay");
                    let background = document.getElementById("backgroundOverlay");
                    let popup = document.getElementById("popupBox");

                    overlay.style.display = "flex";
                    background.style.display = "block"; // Show background overlay

                    // Use setTimeout for smooth fade-in effect
                    setTimeout(() => {
                        overlay.classList.add("show");
                        background.classList.add("show");
                        popup.classList.add("show");
                        document.body.classList.add("no-scroll"); // Disable scrolling
                    }, 50);
                }, 3000);
            }
        });

        // Function to close modal with fade effect
        function closePopup() {
            let overlay = document.getElementById("popupOverlay");
            let background = document.getElementById("backgroundOverlay");
            let popup = document.getElementById("popupBox");

            // Add fade-out effect
            overlay.classList.remove("show");
            background.classList.remove("show");
            popup.classList.remove("show");

            // Wait for animation to complete before hiding
            setTimeout(() => {
                overlay.style.display = "none";
                background.style.display = "none";
                document.body.classList.remove("no-scroll"); // Enable scrolling
            }, 500); // Matches CSS transition time
        }
    </script>
</body>

</html>