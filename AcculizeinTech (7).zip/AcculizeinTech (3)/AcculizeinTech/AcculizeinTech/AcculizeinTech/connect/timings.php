<?php
$sql="INSERT INTO doctor_timings (doctor_id, day, opening_time, closing_time) VALUES
(1, 'Monday', '09:00:00', '17:00:00'),
(1, 'Tuesday', '09:00:00', '17:00:00'),
(1, 'Wednesday', '09:00:00', '17:00:00'),
(1, 'Thursday', '09:00:00', '17:00:00'),
(1, 'Friday', '09:00:00', '17:00:00'),
(1, 'Saturday', '10:00:00', '14:00:00'),
(1, 'Sunday', 'Closed', 'Closed');"
?>