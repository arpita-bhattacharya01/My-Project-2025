<?php
session_start();
include_once "../config.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$query = "SELECT fullname, email, plan_name, plan_price, plan_status FROM adminUsers WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($fullname, $email, $plan_name, $plan_price, $plan_status);
    $stmt->fetch();
} else {
    echo "User not found.";
    exit();
}

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $new_fullname = $_POST['fullname'];
    $new_email = $_POST['email'];

    // Email validation
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format. Please try again.'); window.history.back();</script>";
        exit();
    }

    $update_query = "UPDATE Users SET fullname = ?, email = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("ssi", $new_fullname, $new_email, $user_id);

    if ($update_stmt->execute()) {
        $_SESSION['fullname'] = $new_fullname; // Update session
        echo "<script>alert('Profile updated successfully.'); window.location.href = 'user_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error updating profile.'); window.history.back();</script>";
    }
}

// Handle account deletion
if (isset($_POST['delete_account'])) {
    $delete_query = "DELETE FROM users WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("i", $user_id);

    if ($delete_stmt->execute()) {
        session_destroy(); // Destroy the session
        header('Location: login.php'); // Redirect to login page after deletion
        exit();
    } else {
        echo "<script>alert('Error deleting account.'); window.history.back();</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>

<h2>User Dashboard</h2>

<p>Welcome, <?php echo $fullname; ?>!</p>
<p>Plan: <?php echo $plan_name; ?> (<?php echo $plan_status; ?>)</p>
<p>Price: $<?php echo $plan_price; ?></p>

<h3>Update Profile</h3>
<form method="POST" action="">
    <label for="fullname">Full Name: </label>
    <input type="text" name="fullname" value="<?php echo $fullname; ?>" required><br>

    <label for="email">Email: </label>
    <input type="email" name="email" value="<?php echo $email; ?>" required><br>

    <button type="submit" name="update_profile">Update Profile</button>
</form>

<h3>Delete Account</h3>
<form method="POST" action="">
    <p>Are you sure you want to delete your account? This action cannot be undone.</p>
    <button type="submit" name="delete_account">Delete Account</button>
</form>

<a href="logout.php">Logout</a>

</body>
</html>

<?php $conn->close(); ?>






























<!-- <?php
session_start();
include_once "../config.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header('Location: signin.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$query = "SELECT fullname, email, plan_name, plan_price, plan_status FROM Users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($fullname, $email, $plan_name, $plan_price, $plan_status);
    $stmt->fetch();
} else {
    echo "User not found.";
    exit();
}

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $new_fullname = $_POST['fullname'];
    $new_email = $_POST['email'];

    // Email validation
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format. Please try again.'); window.history.back();</script>";
        exit();
    }

    $update_query = "UPDATE users SET fullname = ?, email = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("ssi", $new_fullname, $new_email, $user_id);

    if ($update_stmt->execute()) {
        $_SESSION['fullname'] = $new_fullname; // Update session
        echo "<script>alert('Profile updated successfully.'); window.location.href = 'user_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error updating profile.'); window.history.back();</script>";
    }
}

// Handle account deletion
if (isset($_POST['delete_account'])) {
    $delete_query = "DELETE FROM users WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("i", $user_id);

    if ($delete_stmt->execute()) {
        session_destroy(); // Destroy the session
        header('Location: signin.php'); // Redirect to login page after deletion
        exit();
    } else {
        echo "<script>alert('Error deleting account.'); window.history.back();</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>

<h2>User Dashboard</h2>

<p>Welcome, <?php echo $fullname; ?>!</p>
<p>Plan: <?php echo $plan_name; ?> (<?php echo $plan_status; ?>)</p>
<p>Price: $<?php echo $plan_price; ?></p>

<h3>Update Profile</h3>
<form method="POST" action="">
    <label for="fullname">Full Name: </label>
    <input type="text" name="fullname" value="<?php echo $fullname; ?>" required><br>

    <label for="email">Email: </label>
    <input type="email" name="email" value="<?php echo $email; ?>" required><br>

    <button type="submit" name="update_profile">Update Profile</button>
</form>

<h3>Delete Account</h3>
<form method="POST" action="">
    <p>Are you sure you want to delete your account? This action cannot be undone.</p>
    <button type="submit" name="delete_account">Delete Account</button>
</form>

<a href="logout.php">Logout</a>

</body>
</html>

<?php $conn->close(); ?> -->
