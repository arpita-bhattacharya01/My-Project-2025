<!-- filepath: c:\xampp\htdocs\AcculizeinTech (3)\AcculizeinTech\AcculizeinTech\AcculizeinTech\connect\publish.php -->
<?php
session_start();
include 'config.php'; // Include your database connection file

// Retrieve form data
$hotelName = $_POST['hotelName'];
$tagline = $_POST['tagline'];
$geoLocation = $_POST['geoLocation'];
$city = $_POST['city'];
$phone = $_POST['phone'];
$website = $_POST['website'];
$category = $_POST['category'];
$description = $_POST['description'];
$tags = $_POST['tags'];
$logo = $_POST['logo'];
$image = explode(',', $_POST['image']);
$businessHours = json_decode($_POST['businessHours'], true);
$socialMedia = json_decode($_POST['socialMedia'], true);
$faq = json_decode($_POST['faq'], true);

// Simulate Payment Gateway (Replace this with actual payment gateway integration)
echo "<script>
    alert('Redirecting to payment gateway...');
    window.location.href = 'payment_gateway.php';
</script>";
exit;

// After successful payment, save data to the database
if (isset($_GET['payment_status']) && $_GET['payment_status'] === 'success') {
    // Insert data into the `listing` table
    $sql = "INSERT INTO listing (hotel_name, tagline, geo_location, city, phone, website, category, description, tags, logo, images, business_hours, social_media, faq)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        'ssssssssssssss',
        $hotelName,
        $tagline,
        $geoLocation,
        $city,
        $phone,
        $website,
        $category,
        $description,
        $tags,
        $logo,
        json_encode($image),
        json_encode($businessHours),
        json_encode($socialMedia),
        json_encode($faq)
    );

    if ($stmt->execute()) {
        echo "<script>
            alert('Listing published successfully!');
            window.location.href = 'profile.php';
        </script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>