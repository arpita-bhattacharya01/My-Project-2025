<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['id'])) {
        die("User not logged in.");
    }

    $userId = $_SESSION['id'];

    // Get is_admin
    $stmt = $conn->prepare("SELECT is_admin, image FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($is_admin, $previousImage);
    $stmt->fetch();
    $stmt->close();

    // Sanitize inputs (rest of your sanitization code remains the same)
    $first_name     = htmlspecialchars($_POST['first-name']);
    $last_name      = htmlspecialchars($_POST['last-name']);
    $fullname       = htmlspecialchars($_POST['display-name']);
    $email          = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone          = htmlspecialchars($_POST['phone']);
    $address_line_1 = htmlspecialchars($_POST['address-line-1']);
    $address_line_2 = htmlspecialchars($_POST['address-line-2']);
    $city           = htmlspecialchars($_POST['city']);
    $pincode        = preg_replace('/\D/', '', $_POST['zip-code']);
    $state          = htmlspecialchars($_POST['state']);
    $country        = htmlspecialchars($_POST['country']);
    $about          = htmlspecialchars($_POST['about-message']);
    $password       = $_POST['password'];
    $facebook       = filter_var($_POST['facebook-url'], FILTER_SANITIZE_URL);
    $twitter        = filter_var($_POST['twitter-url'], FILTER_SANITIZE_URL);
    $linkedin       = filter_var($_POST['linkedin-url'], FILTER_SANITIZE_URL);
    $instagram      = filter_var($_POST['instagram-url'], FILTER_SANITIZE_URL);
    $pinterest      = filter_var($_POST['pinterest-url'], FILTER_SANITIZE_URL);

    // Password: hash if updated, else keep existing (remains the same)
    if (!empty($password)) {
        $hashedPassword = password_hash(htmlspecialchars($password), PASSWORD_DEFAULT);
    } else {
        $stmtPwd = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmtPwd->bind_param("i", $userId);
        $stmtPwd->execute();
        $stmtPwd->bind_result($currentPassword);
        $stmtPwd->fetch();
        $stmtPwd->close();
        $hashedPassword = $currentPassword;
    }

    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp']; // Define $allowedTypes here
    $newImageUploaded = false;

    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === 0) {
        $tmpFile = $_FILES['profile_image']['tmp_name'];
        $originalName = basename($_FILES['profile_image']['name']);
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

        // Define upload directory RELATIVE to the current script's location
        $uploadDir = dirname(__FILE__) . '/../uploads/profile_images/';

        if (!is_dir($uploadDir)) {
            if (!mkdir($uploadDir, 0755, true)) {
                file_put_contents('debug_upload.txt', "❌ Failed to create upload directory: " . $uploadDir . PHP_EOL, FILE_APPEND);
            }
        }

        if (in_array($extension, $allowedTypes)) {
            if ($_FILES['profile_image']['size'] <= 2 * 1024 * 1024) {
                $uniqueName = uniqid('profile_', true) . '.' . $extension;
                $destPath = $uploadDir . $uniqueName;
                $imageFilename = $uniqueName; // Store only the filename in the database
                $imagePath = $imageFilename;
                $newImageUploaded = true;

                if (move_uploaded_file($tmpFile, $destPath)) {
                    // 🔴 DEBUG - Store final path
                    file_put_contents('debug_upload.txt', "✅ Image moved: " . $destPath . " (DB Filename: " . $imageFilename . ")" . PHP_EOL, FILE_APPEND);
                } else {
                    file_put_contents('debug_upload.txt', "❌ move_uploaded_file failed from " . $tmpFile . " to " . $destPath . PHP_EOL, FILE_APPEND);
                    $imagePath = $previousImage; // Revert to previous image on upload failure
                    $imageFilename = $previousImage;
                }
            } else {
                file_put_contents('debug_upload.txt', "❌ File too large" . PHP_EOL, FILE_APPEND);
                $imagePath = $previousImage; // Revert to previous image on size failure
                $imageFilename = $previousImage;
            }
        } else {
            file_put_contents('debug_upload.txt', "❌ Invalid extension: $extension" . PHP_EOL, FILE_APPEND);
            $imagePath = $previousImage; // Revert to previous image on extension failure
            $imageFilename = $previousImage;
        }
    } else {
        // No new image uploaded, keep the previous one
        $imagePath = $previousImage;
        $imageFilename = $previousImage;
    }

    // Update user in DB
    $sql = "UPDATE users SET first_name = ?, last_name = ?, fullname = ?, email = ?, phone = ?,
                address_line_1 = ?, address_line_2 = ?, city = ?, pincode = ?, state = ?, country = ?,
                about = ?, password = ?, facebook = ?, twitter = ?, linkedin = ?, instagram = ?,
                pinterest = ?, image = ? WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssssssssssssssssi",
        $first_name, $last_name, $fullname, $email, $phone,
        $address_line_1, $address_line_2, $city, $pincode, $state,
        $country, $about, $hashedPassword, $facebook, $twitter,
        $linkedin, $instagram, $pinterest, $imageFilename, $userId
    );

    // 🔴 DEBUGGING - Check the value of $imageFilename just before executing the query
    file_put_contents('debug_upload.txt', "➡️ Before DB Update - Image Filename: " . $imageFilename . PHP_EOL, FILE_APPEND);

    if ($stmt->execute()) {
        // Delete the previous image if a new one was successfully uploaded AND the previous image is not the default
        if ($newImageUploaded && !empty($previousImage) && !strpos($previousImage, 'flaticon.com')) {
            $oldImagePath = dirname(__FILE__) . '/../uploads/profile_images/' . $previousImage;
            if (file_exists($oldImagePath)) {
                unlink($oldImagePath);
                file_put_contents('debug_upload.txt', "🗑️ Old image deleted: " . $oldImagePath . PHP_EOL, FILE_APPEND);
            } else {
                file_put_contents('debug_upload.txt', "⚠️ Old image not found, cannot delete: " . $oldImagePath . PHP_EOL, FILE_APPEND);
            }
        }

        // Update session values
        $_SESSION = array_merge($_SESSION, [
            'first_name'     => $first_name,
            'last_name'      => $last_name,
            'fullname'       => $fullname,
            'email'          => $email,
            'phone'          => $phone,
            'address_line_1' => $address_line_1,
            'address_line_2' => $address_line_2,
            'city'           => $city,
            'pincode'        => $pincode,
            'state'          => $state,
            'country'        => $country,
            'facebook'       => $facebook,
            'twitter'        => $twitter,
            'linkedin'       => $linkedin,
            'instagram'      => $instagram,
            'pinterest'      => $pinterest,
            'image' => $imageFilename, 
            'is_admin'       => $is_admin,
            // 'image'          => $imageFilename // Update session with the new filename
        ]);

        $redirect = ($is_admin == 1) ? 'adminnew_dashboard.php' : 'userss_dashboard.php';
        header("Location: $redirect?update=success");
        exit();
    } else {
        // 🔴 DEBUGGING - Output the database error
        file_put_contents('debug_upload.txt', "❌ Database update failed: " . $stmt->error . PHP_EOL, FILE_APPEND);
        $redirect = ($is_admin == 1) ? 'adminnew_dashboard.php' : 'userss_dashboard.php';
        header("Location: $redirect?update=error");
        exit();
    }
}
?>