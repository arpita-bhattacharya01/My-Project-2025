<?php
include_once 'config.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $plan = $_POST['plan'];

    $sql = "INSERT INTO plans (fullname, phone, email, plan) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $fullname, $phone,$email,  $plan);

    if ($stmt->execute()) {
        echo "<script>
                alert('Plan selected successfully! We will contact you soon.');
                window.location.href = 'enquiry.php'; 
              </script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
