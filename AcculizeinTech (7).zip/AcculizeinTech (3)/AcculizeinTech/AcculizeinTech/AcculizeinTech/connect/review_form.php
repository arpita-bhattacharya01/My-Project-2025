<?php
include_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = $_POST['doctor_id'];
    $reviewer_name = $_POST['reviewer_name'];
    $review_text = $_POST['review_text'];
    $rating = $_POST['rating'];
    $review_date = date("Y-m-d H:i:s");

    $sql = "INSERT INTO reviews (doctor_id, reviewer_name, review_text, rating, review_date) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issis", $doctor_id, $reviewer_name, $review_text, $rating, $review_date);

    if ($stmt->execute()) {
        echo "Review submitted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
