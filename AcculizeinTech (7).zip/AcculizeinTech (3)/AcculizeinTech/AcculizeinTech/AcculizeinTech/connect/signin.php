<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// session_start();

require_once 'config.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = isset($_POST['username']) ? trim($_POST['username']) : null;
    $password = isset($_POST['signin-password']) ? trim($_POST['signin-password']) : null;


    // Validate input
    if (empty($email) || empty($password)) {
        echo "<script>alert('Email and Password are required!'); window.history.back();</script>";
        exit;
    }

    // Check if user_type exists in the database before querying
    // $sql_check_columns = "SHOW COLUMNS FROM users LIKE 'user_type'";
    // $result_check = $conn->query($sql_check_columns);

    // if ($result_check->num_rows == 0) {
    //     die("Error: 'user_type' column does not exist in the users table.");
    // }

    // Fetch user details
    $sql = "SELECT id, fullname, password, user_type FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);


    if (!$stmt) {
        die("Query preparation failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    // $result = $stmt->store_result();

    // Corrected bind_result() with the exact number of columns
    $stmt->bind_result($id, $fullname, $hashed_password, $user_type);

    if ($stmt->fetch()) {
        // Verify password
        if (password_verify($password, $hashed_password)) {
            session_start();
            $_SESSION['id'] = $id;
            $_SESSION['email'] = $email;
            $_SESSION['fullname'] = $fullname;
            $_SESSION['user_type'] = $user_type;

            // Redirect based on user type
            // Redirect to goodg.php for all users
            echo "<script>
        // alert('Login successful! Redirecting...');
        window.location.href = 'goodg.php';
      </script>";
        } else {
            echo "<script>alert('Invalid email or password!'); window.history.back();</script>";
        }
    }
    //         if ($user_type === 'admin') {
    //             $redirectPage = 'adminnew_dashboard.php';
    //         } elseif ($user_type === 'seller') {
    //             $redirectPage = 'sellsnew_dashboard.php';
    //         } else {
    //             $redirectPage = 'goodg.php';
    //         }

    //         echo "<script>
    //                 alert('Login successful! Redirecting...');
    //                 window.location.href = '$redirectPage';
    //               </script>";
    //     } else {
    //         echo "<script>alert('Invalid email or password!'); window.history.back();</script>";
    //     }
    // } 

    $stmt->close();
    $conn->close();
}
