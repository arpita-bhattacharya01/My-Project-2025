<?php

session_start();

include 'config.php';
// include 'career.html';

// Fetch latest job
// $sql = "SELECT * FROM jobs ORDER BY id DESC LIMIT 1";
// $result = $conn->query($sql);

// $job = [];
// if ($result->num_rows > 0) {
//     $job = $result->fetch_assoc();
// }

// // Fetch responsibilities for the job
// $responsibilities = [];
// if (!empty($job)) {
//     $job_id = $job['id'];
//     $sql = "SELECT responsibility FROM job_responsibilities WHERE job_id = $job_id";
//     $result = $conn->query($sql);
    
//     if ($result->num_rows > 0) {
//         while ($row = $result->fetch_assoc()) {
//             $responsibilities[] = $row['responsibility'];
//         }
//     }
// }

// // Fetch job requirements
// $requirements = [];
// if (!empty($job)) {
//     $job_id = $job['id'];
//     $sql = "SELECT requirement FROM job_requirements WHERE job_id = $job_id";
//     $result = $conn->query($sql);

//     while ($row = $result->fetch_assoc()) {
//         $requirements[] = $row['requirement'];
//     }
// }

// // Fetch preferred qualifications
// $qualifications = [];
// if (!empty($job)) {
//     $sql = "SELECT qualification FROM job_qualifications WHERE job_id = $job_id";
//     $result = $conn->query($sql);

//     while ($row = $result->fetch_assoc()) {
//         $qualifications[] = $row['qualification'];
//     }
// }

// // Fetch benefits (Why Join Us?)
// $benefits = [];
// if (!empty($job)) {
//     $sql = "SELECT benefit FROM job_benefits WHERE job_id = $job_id";
//     $result = $conn->query($sql);

//     while ($row = $result->fetch_assoc()) {
//         $benefits[] = $row['benefit'];
//     }
// }



    // $stmt->close();
    // $con->close();



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bizvility &#8211; Dare To Grow</title>
    <link rel="shortcut icon" type="image/x-icon" href="../assets/imgs/bizvility-logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <!-- navbar -->
    <header class="navbar navbar-2">
        <!-- logo -->
        <div class="logo ms-2">
            <a href="index.html">
                <img src="../assets/imgs/logo.png" width="220" height="70" alt="">
            </a>
        </div>

        <!-- select-what-where -->
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn btn-primary search-btn">
                    <i class="fa-magnifying-glass fa-solid"></i>
                </button>
            </div>
        </div>

        <!-- nav-buttons -->
        <ul class="nav-btns me-3">
            <button class="btn btn-outline-light career-nav-link">
                <a href="career.html">
                    Career
                </a>
            </button>
            <button class="btn btn-outline-light btn-primary">
                <a href="pricing-plan.html">
                    <i class="fa-circle-plus fa-solid"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
        <i class="fa-bars fa-solid menu-open"></i>
        <i class="fa-solid fa-xmark menu-close"></i>
    </header>

    <div class="side-menu side-menu-2">
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn btn-primary search-btn">
                    <i class="fa-magnifying-glass fa-solid"></i>
                </button>
            </div>
        </div>
        <ul class="side-links">
            <button class="btn btn-outline-light career-nav-link">
                <a href="career.html">
                    Career
                </a>
            </button>
            <button class="btn btn-outline-light btn-primary">
                <a href="pricing-plan.html">
                    <i class="fa-circle-plus fa-solid"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
    </div>

    <!-- signIn & signUp Modal -->
    <div class="popup_main">
        <div class="popup_body">
            <div class="popup_back"></div>
            <div class="popup_contain">
                <div class="popup_close">&times;</div>
                <div class="left">
                    <img src="../assets/imgs/signIn-img.jpg" alt="Placeholder Image">
                    <button class="toggle-btn" id="toggle-auth">Click to Sign In</button>
                </div>
                <div class="right">
                    <div class="form-container active" id="signup-form">
                        <h3>Create new account</h3>
                        <hr>
                        <form>
                            <input type="text" name="fullName" id="fullName" placeholder="Your Full Name" required>
                            <input type="email" name="email" id="email" placeholder="Your Email" required>
                            <input type="tel" name="phone" id="phone" placeholder="Your Phone Number" required>
                            <input type="text" name="city" id="state" placeholder="City" required>
                            <input type="text" name="state" id="state" placeholder="State" required>
                            <input type="number" name="pincode" id="pincode" placeholder="Pincode" required>
                            <input type="text" name="username" id="username" placeholder="Username" required>
                            <div class="form-group">
                                <input type="password" id="password" placeholder="Password" required>
                                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                            </div>
                            <div class="form-group">
                                <input type="password" id="confirm-password" placeholder="Confirm Password" required>
                                <span class="toggle-password" onclick="togglePassword('confirm-password')">👁</span>
                            </div>
                            <div class="form-btns">
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <button type="submit" class="btn btn-primary">Sign Up</button>
                            </div>
                        </form>
                        <div class="form-toggle">
                            <button class="toggle-btn" id="toggle-auth-2">Click to Sign In</button>
                        </div>
                    </div>
                </div>
                <div class="form-container" id="signin-form">
                    <h3>Sign In</h3>
                    <form>
                        <input type="text" class="mb-2" placeholder="Username" required>
                        <div class="form-group">
                            <input type="password" id="signin-password" placeholder="Password" required>
                            <span class="toggle-password" onclick="togglePassword('signin-password')">👁</span>
                        </div>
                        <div class="form-btns">
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <button type="submit" class="btn btn-primary">Sign In</button>
                        </div>
                    </form>
                    <div class="form-toggle">
                        <button class="toggle-btn" id="toggle-auth-3">Click to Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- welcome section start -->
    <div class="welcome-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="welcome-container">
                        <h2>Welcome to the Bizvility Job Page!</h2>
                        <div class="search-job-area">
                            <h5>See where you fit in • Search jobs by location or team</h5>
                            <div class="search-job-select-options">
                                <div class="search-job-dropdown">
                                    <input hidden class="sr-only" name="state-dropdown-1" id="state-dropdown-1"
                                        type="checkbox" />
                                    <label aria-label="dropdown scrollbar" for="state-dropdown-1"
                                        class="trigger" onclick="toggleDropdown('locationList')">Location</label>
                                    <ul class="list webkit-scrollbar" role="list" dir="auto">
                                        <li class="listitem" role="locationList">
                                            <p onclick="selectOption('locationList', this)">Agra</p>
                                            <p onclick="selectOption('locationList', this)">Aligarh</p>
                                            <p onclick="selectOption('locationList', this)">Bareilly</p>
                                            <p onclick="selectOption('locationList', this)">Bharatpur</p>
                                            <p onclick="selectOption('locationList', this)">Bhind</p>
                                            <p onclick="selectOption('locationList', this)">Chandigarh</p>
                                            <p onclick="selectOption('locationList', this)">Delhi</p>
                                            <p onclick="selectOption('locationList', this)">Delhi NCR</p>
                                            <p onclick="selectOption('locationList', this)">Dholpur</p>
                                            <p onclick="selectOption('locationList', this)">Etah</p>
                                            <p onclick="selectOption('locationList', this)">Etawa</p>
                                            <p onclick="selectOption('locationList', this)">Faridabad</p>
                                            <p onclick="selectOption('locationList', this)">Firozabad</p>
                                            <p onclick="selectOption('locationList', this)">Ghaziabad</p>
                                            <p onclick="selectOption('locationList', this)">Gwalior</p>
                                            <p onclick="selectOption('locationList', this)">Greater Noida</p>
                                            <p onclick="selectOption('locationList', this)">Gurugram</p>
                                            <p onclick="selectOption('locationList', this)">Hathras</p>
                                            <p onclick="selectOption('locationList', this)">Indor</p>
                                            <p onclick="selectOption('locationList', this)">Jaipur</p>
                                            <p onclick="selectOption('locationList', this)">Kanpur</p>
                                            <p onclick="selectOption('locationList', this)">Kasganj</p>
                                            <p onclick="selectOption('locationList', this)">Lucknow</p>
                                            <p onclick="selectOption('locationList', this)">Mainpuri</p>
                                            <p onclick="selectOption('locationList', this)">Mathura</p>
                                            <p onclick="selectOption('locationList', this)">Morena</p>
                                            <p onclick="selectOption('locationList', this)">Noida</p>
                                            <p onclick="selectOption('locationList', this)">Sadabad</p>
                                            <p onclick="selectOption('locationList', this)">Shikohabad</p>
                                            <p onclick="selectOption('locationList', this)">Tundla</p>
                                            <p onclick="selectOption('locationList', this)">Ujjain</p>
                                        </li>
                                    </ul>
                                </div>

                                <div class="search-job-dropdown">
                                    <input hidden class="sr-only" name="state-dropdown-2" id="state-dropdown-2"
                                        type="checkbox" />
                                    <label aria-label="dropdown scrollbar" for="state-dropdown-2"
                                        class="trigger" onclick="toggleDropdown('departmentList')">Department</label>
                                    <ul class="list webkit-scrollbar" role="list" dir="auto">
                                        <li class="listitem" role="departmentList">
                                            <p onclick="selectOption('departmentList', this)">Android developer</p>
                                            <p onclick="selectOption('departmentList', this)">App developer (or Application developer)</p>
                                            <p onclick="selectOption('departmentList', this)">Content creator</p>
                                            <p onclick="selectOption('departmentList', this)">Digital marketer</p>
                                            <p onclick="selectOption('departmentList', this)">Graphic designer</p>
                                            <p onclick="selectOption('departmentList', this)">Human Resources</p>
                                            <p onclick="selectOption('departmentList', this)">Information Technology</p>
                                            <p onclick="selectOption('departmentList', this)">Marketing</p>
                                            <p onclick="selectOption('departmentList', this)">Operations</p>
                                            <p onclick="selectOption('departmentList', this)">Photo-video cinematographer</p>
                                            <p onclick="selectOption('departmentList', this)">Software developer</p>
                                            <p onclick="selectOption('departmentList', this)">Sales/Sales B2B</p>
                                            <p onclick="selectOption('departmentList', this)">Telecom/Telecaller</p>
                                            <p onclick="selectOption('departmentList', this)">Web Developer</p>
                                        </li>
                                    </ul>
                                </div>

                                <button type="button" class="btn btn-primary search-job-btn">
                                    <a href="coming-soon.html">Search</a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- welcome section end -->


    <!-- job details section start -->
    <div class="job-details-section">
        <div class="container">
            <div class="row">

                <div class="col-lg-12">
                    <div class="headings">
                        <div class="links-path">
                            <a href="index.html">Home</a>&#11166;
                            <a href="career.html">Career</a>
                        </div>
                        <div class="urgent-hiring">
                            <p>Urgent Hiring</p>
                        </div>
                    </div>
                </div>

                <!-- card 1 -->
                <div class="col-lg-12">
                    <div class="job-card">
                        <div class="job-card-header">
                            <h3 class="mb-0">App Developer</h3>
                            <div class="open-jobs-counting">
                                <p>12 Open Position</p>
                                <i class='bx bx-chevron-down bx-sm'></i>
                            </div>
                        </div>
                        <div class="job-card-header job-card-header-2">
                            <div class="open-jobs-counting">
                                <h3 class="mb-0">App Developer</h3>
                                <p>12 Open Position</p>
                            </div>
                            <i class='bx bx-chevron-down bx-sm'></i>
                        </div>
                        <div class="job-cards-container">

                            <!-- body 1 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>Mobile App Developer</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>12</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: Be responsible for designing, building,
                                                and maintaining high-quality mobile applications for both Android and iOS platforms...</p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="mobile-app-developer.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- card 2 -->
                <div class="col-lg-12">
                    <div class="job-card">
                        <div class="job-card-header">
                            <h3 class="mb-0">Customer Support</h3>
                            <div class="open-jobs-counting">
                                <p>1 Open Position</p>
                                <i class='bx bx-chevron-down bx-sm'></i>
                            </div>
                        </div>
                        <div class="job-card-header job-card-header-2">
                            <div class="open-jobs-counting">
                                <h3 class="mb-0">Customer Support</h3>
                                <p>1 Open Position</p>
                            </div>
                            <i class='bx bx-chevron-down bx-sm'></i>
                        </div>
                        <div class="job-cards-container">

                            <!-- body 1 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>Customer Support -Voice Process</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Part time / Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: Job Title: Information Retrieval Officer Grade: G12
                                                Department:
                                                Voice Operations Section: IRO Operations Reports to (...</p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="customer-care.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>                

                <!-- card 3 -->
                <div class="col-lg-12">
                    <div class="job-card">
                        <div class="job-card-header">
                            <h3 class="mb-0">Graphic Designer</h3>
                            <div class="open-jobs-counting">
                                <p>12 Open Position</p>
                                <i class='bx bx-chevron-down bx-sm'></i>
                            </div>
                        </div>
                        <!-- responsive header(425px) -->
                        <div class="job-card-header job-card-header-2">
                            <div class="open-jobs-counting">
                                <h3 class="mb-0">Graphic Designer</h3>
                                <p>12 Open Position</p>
                            </div>
                            <i class='bx bx-chevron-down bx-sm'></i>
                        </div>
                        <div class="job-cards-container">

                            <!-- body 1 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>Graphic Designer</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common work-place">
                                                <i class='bx bx-desktop'></i>
                                                <p>WFO</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>10</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: For producing
                                                visually appealing designs that communicate our brand message and captivate
                                                our audience...</p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="graphic-designer.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>

                            <!-- body 2 -->
                            
                        </div>
                    </div>
                </div>

                <!-- card 4 -->
                <div class="col-lg-12">
                    <div class="job-card">
                        <div class="job-card-header">
                            <h3 class="mb-0">Operations</h3>
                            <div class="open-jobs-counting">
                                <p>10 Open Position</p>
                                <i class='bx bx-chevron-down bx-sm'></i>
                            </div>
                        </div>
                        <!-- responsive header(425px) -->
                        <div class="job-card-header job-card-header-2">
                            <div class="open-jobs-counting">
                                <h3 class="mb-0">Operations</h3>
                                <p>2 Open Position</p>
                            </div>
                            <i class='bx bx-chevron-down bx-sm'></i>
                        </div>
                        <div class="job-cards-container">

                            <!-- body 1 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>UGC Content Creator</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>10</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: crucial role in producing engaging and relatable content that resonates with our audience across various social media platforms...
                                            </p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="content-creater.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>

                            <!-- body 2 -->
                            
                        </div>
                    </div>
                </div>

                <!-- card 5 -->
                <div class="col-lg-12">
                    <div class="job-card">
                        <div class="job-card-header">
                            <h3 class="mb-0">Photo-video cinematographer</h3>
                            <div class="open-jobs-counting">
                                <p>20 Open Position</p>
                                <i class='bx bx-chevron-down bx-sm'></i>
                            </div>
                        </div>
                        <!-- responsive header(425px) -->
                        <div class="job-card-header job-card-header-2">
                            <div class="open-jobs-counting">
                                <h3 class="mb-0">Photo-video cinematographer</h3>
                                <p>20 Open Position</p>
                            </div>
                            <i class='bx bx-chevron-down bx-sm'></i>
                        </div>
                        <div class="job-cards-container">

                            <!-- body 1 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>Video Editor</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common work-place">
                                                <i class='bx bx-desktop'></i>
                                                <p>WFO</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>10</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: Editing high-quality video content for a variety of platforms, including social media,
                                                websites, advertisements, and promotional materials...</p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="video-editor.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>

                            <!-- body 2 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>Photo & Video Cinematographer</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common work-place">
                                                <i class='bx bx-desktop'></i>
                                                <p>WFO</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>10</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: Capturing high-quality photographs and videos that align with our brand’s vision, storytelling, and
                                                creative direction...</p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="video-photo-cinematographer.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>

                            <!-- body 3 -->
                            
                        </div>
                    </div>
                </div>


                <!-- card 6 -->
                <div class="col-lg-12">
                    <div class="job-card">
                        <div class="job-card-header">
                            <h3 class="mb-0">Sales/Sales B2B</h3>
                            <div class="open-jobs-counting">
                                <p>30 Open Position</p>
                                <i class='bx bx-chevron-down bx-sm'></i>
                            </div>
                        </div>
                        <!-- responsive header(425px) -->
                        <div class="job-card-header job-card-header-2">
                            <div class="open-jobs-counting">
                                <h3 class="mb-0">Sales/Sales B2B</h3>
                                <p>30 Open Position</p>
                            </div>
                            <i class='bx bx-chevron-down bx-sm'></i>
                        </div>
                        <div class="job-cards-container">

                            <!-- body 1 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>Business Development Executive (EdTech)</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>20</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p> Job Description: For identifying and developing new business
                                                opportunities, driving partnerships, and expanding our customer base...
                                            </p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="business-executive.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>

                            <!-- body 2 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>IT Sales</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>10</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: Identify and reach out to potential clients to understand their IT needs &  Develop and maintain strong client relationships...</p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="IT-sales.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>

                            <!-- body 3 -->
                            

                            <!-- body 4 -->
                            
                        </div>
                    </div>
                </div>

                <!-- card 6 -->
                <div class="col-lg-12">
                    <div class="job-card">
                        <div class="job-card-header">
                            <h3 class="mb-0">Web Developer</h3>
                            <div class="open-jobs-counting">
                                <p>12 Open Position</p>
                                <i class='bx bx-chevron-down bx-sm'></i>
                            </div>
                        </div>
                        <!-- responsive header(425px) -->
                        <div class="job-card-header job-card-header-2">
                            <div class="open-jobs-counting">
                                <h3 class="mb-0">Web Developer</h3>
                                <p>12 Open Position</p>
                            </div>
                            <i class='bx bx-chevron-down bx-sm'></i>
                        </div>
                        <div class="job-cards-container">

                            <!-- body 1 -->
                            <div class="job-card-body">
                                <div class="job-content">
                                    <div class="first-box">
                                        <h4>Full Stack Developer</h4>
                                        <div class="about-job">
                                            <div class="common loaction">
                                                <i class='bx bx-map'></i>
                                                <p>Agra</p>
                                            </div>
                                            <div class="common job-type">
                                                <i class='bx bx-briefcase'></i>
                                                <p>Full time</p>
                                            </div>
                                            <div class="common job-experience">
                                                <i class='bx bx-time-five'></i>
                                                <p>0-3 Years</p>
                                            </div>
                                            <div class="common needed-person">
                                                <i class='bx bx-user' ></i>
                                                <p>12</p>
                                            </div>
                                        </div>
                                        <div class="job-description">
                                            <p>Job Description: Responsible for designing, building, and maintaining both the front-end and back-end of web
                                                applications...
                                            </p>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-primary job-apply-btn">
                                        <a href="full-stack-developer.html">
                                            Apply Now
                                        </a>
                                    </button>
                                </div>
                            </div>

                            <!-- body 2 -->
                            

                            <!-- body 3 -->
                            

                            <!-- body 4 -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- footer start -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="copyright">Copyright © 2025 Bizvility</p>
                    <p class="developBy">Developed by Bizvility</p>
                    <div class="social-media">
                        <i class="fa-brands fa-square-facebook"></i>
                        <i class="fa-brands fa-square-x-twitter"></i>
                        <i class="fa-brands fa-square-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                        <i class="fa-solid fa-whiskey-glass"></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer end -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/7.6.0/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>

</body>

</html>