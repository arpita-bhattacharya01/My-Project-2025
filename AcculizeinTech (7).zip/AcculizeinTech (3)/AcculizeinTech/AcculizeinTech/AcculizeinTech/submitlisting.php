<?php
session_start();
require_once './connect/config.php';
// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: signin.php");
    exit;
}
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve user ID from session
    $user_id = $_SESSION['id'];

    // Retrieve form data
    // $business_name = htmlspecialchars($_POST['name'] ?? '');
    // $phone = htmlspecialchars($_POST['phone'] ?? '');
    // $email = htmlspecialchars($_POST['email-for-signUp'] ?? '');
    // $category = htmlspecialchars($_POST['category'] ?? '');
    // $address = htmlspecialchars($_POST['geoLocation'] ?? '');
    // $city = htmlspecialchars($_POST['city'] ?? '');
    // $state = htmlspecialchars($_POST['state'] ?? '');
    // $pincode = htmlspecialchars($_POST['pincode'] ?? '');
    // $website = htmlspecialchars($_POST['website'] ?? '');
    // $description = htmlspecialchars($_POST['editor'] ?? '');
    // $googlemap = htmlspecialchars($_POST['geoLocation'] ?? '');
    // $video_link = htmlspecialchars($_POST['video-link'] ?? '');
    // $faq = htmlspecialchars($_POST['faq'] ?? '');
    // $sociallinks = json_encode([
    //     'facebook' => htmlspecialchars($_POST['facebook'] ?? ''),
    //     'instagram' => htmlspecialchars($_POST['instagram'] ?? ''),
    //     'twitter' => htmlspecialchars($_POST['twitter'] ?? ''),
    //     'linkedin' => htmlspecialchars($_POST['linkedin'] ?? ''),
    //     'youtube' => htmlspecialchars($_POST['youtube'] ?? '')
    // ]);
    // $business_hour = htmlspecialchars($_POST['business_hour'] ?? '');

    // // Handle file uploads
    // $logo = '';
    // $image = '';
    // $video = '';

    // Upload logo
    // if (!empty($_FILES['logo']['name'])) {
    //     $logoDir = 'uploads/logo/';
    //     if (!is_dir($logoDir)) {
    //         mkdir($logoDir, 0777, true);
    //     }
    //     $logoName = time() . '_' . basename($_FILES['logo']['name']);
    //     $logoPath = $logoDir . $logoName;
    //     if (move_uploaded_file($_FILES['logo']['tmp_name'], $logoPath)) {
    //         $logo = $logoName;
    //     }
    // }

    // // Upload images
    // if (!empty($_FILES['image']['name'][0])) {
    //     $imageDir = 'uploads/image/';
    //     if (!is_dir($imageDir)) {
    //         mkdir($imageDir, 0777, true);
    //     }
    //     $imageNames = [];
    //     foreach ($_FILES['image']['tmp_name'] as $key => $tmpName) {
    //         if (!empty($tmpName)) {
    //             $imageName = time() . '_' . basename($_FILES['image']['name'][$key]);
    //             $imagePath = $imageDir . $imageName;
    //             if (move_uploaded_file($tmpName, $imagePath)) {
    //                 $imageNames[] = $imageName;
    //             }
    //         }
    //     }
    //     $image = json_encode($imageNames); // Store as JSON
    // }

    // // Upload video
    // if (!empty($_FILES['video']['name'])) {
    //     $videoDir = 'uploads/video/';
    //     if (!is_dir($videoDir)) {
    //         mkdir($videoDir, 0777, true);
    //     }
    //     $videoName = time() . '_' . basename($_FILES['video']['name']);
    //     $videoPath = $videoDir . $videoName;
    //     if (move_uploaded_file($_FILES['video']['tmp_name'], $videoPath)) {
    //         $video = $videoName;
    //     }
    // }

    // Validate required fields
    // if (empty($business_name) || empty($phone) || empty($category) || empty($address) || empty($city)) {
    //     echo "<script>alert('Please fill in all required fields.'); window.history.back();</script>";
    //     exit;
    // }

    // Insert data into the listings table
    // $stmt = $conn->prepare("INSERT INTO listings (business_name, phone, email, category, address, city, state, pincode, website, description, googlemap, logo, image, video, faq, sociallinks, business_hour, email_owner, video_link) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    // $stmt->bind_param(
    //     "sssssssssssssssssss",
    //     $business_name,
    //     $phone,
    //     $email,
    //     $category,
    //     $address,
    //     $city,
    //     $state,
    //     $pincode,
    //     $website,
    //     $description,
    //     $googlemap,
    //     $logo,
    //     $image,
    //     $video,
    //     $faq,
    //     $sociallinks,
    //     $business_hour,
    //     $email,
    //     $video_link
    // );
    //     if ($stmt->execute()) {
    //         // Redirect to profile.php after successful insertion
    //         header("Location: connect/profile.php");
    //         exit;
    //     } else {
    //         echo "<script>alert('Failed to save the listing. Error: " . $stmt->error . "'); window.history.back();</script>";
    //     }

    //     $stmt->close();

    // }
}

// Debug: Check if plan_id is being passed
if (isset($_GET['plan_id'])) {
    echo "<script>console.log('Plan ID from URL:', " . json_encode($_GET['plan_id']) . ");</script>";
} else {
    echo "<script>console.log('Plan ID is not set in the URL.');</script>";
}

// Check if the user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['fullname'])) {
    echo "<script>
        alert('Please sign in before filling out the form.');
        window.location.href = 'signin.php?redirect=submitlisting.php';
    </script>";
    exit;
}
// Check if the user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['fullname'])) {
    // If not logged in, display a message and redirect to the sign-in page
    echo "<script>
        alert('Please sign in before filling out the form.');
        window.location.href = 'signin.php?redirect=submitlisting.php';
    </script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bizvility &#8211; Dare To Grow</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/bizvility-logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.5.0/semantic.min.css">
    <link rel="stylesheet" href="./assets/css/submitlisting.css">
</head>
<style>
    #editor {
    width: 800px;
    height: 150px;
    resize: vertical;
    padding: 10px;
    font-size: 1rem;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
}
</style>

<body>

    <!-- navbar -->
    <header class="navbar navbar-2">
        <!-- logo -->
        <div class="logo ms-2">
            <a href="index.html">
                <img src="assets/imgs/logo.png" width="220" height="70" alt="">
            </a>
        </div>

        <!-- select-what-where -->
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn btn-primary search-btn">
                    <i class="fa-magnifying-glass fa-solid"></i>
                </button>
            </div>
        </div>

        <!-- nav-buttons -->
        <ul class="nav-btns me-3">
            <button class="btn btn-outline-light career-nav-link">
                <a href="career.html">
                    Career
                </a>
            </button>
            <!-- <button class="btn btn-outline-light btn-primary">
                <a href="pricing-plan.html">
                    <i class="fa-circle-plus fa-solid"></i>
                    Add Listing
                </a>
            </button> -->
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
        <i class="fa-bars fa-solid menu-open"></i>
        <i class="fa-solid fa-xmark menu-close"></i>
    </header>

    <div class="side-menu side-menu-2">
        <div class="select-what-where">
            <div class="selection-area">
                <div class="dropdown-container">
                    <label for="what">What</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="what-input"
                            placeholder="Ex: food, service, barber, hotel">
                        <div class="dropdown-list" id="what-list">
                            <option class="dropdown-item" value="arts&entertainment">Arts & Entertainment</option>
                            <option class="dropdown-item" value="automotive">Automotive</option>
                            <option class="dropdown-item" value="beauty&spa">Beauty & Spa</option>
                            <option class="dropdown-item" value="health&medical">Health & Medical</option>
                            <option class="dropdown-item" value="hotels">Hotels</option>
                            <option class="dropdown-item" value="italian">Italian</option>
                        </div>
                    </div>
                </div>

                <div class="dropdown-container">
                    <label for="where">Where</label>
                    <div class="dropdown">
                        <input type="text" class="dropdown-input" id="where-input" placeholder="Your City...">
                        <div class="dropdown-list" id="where-list"></div>
                    </div>
                </div>

                <button class="btn btn-primary search-btn">
                    <i class="fa-magnifying-glass fa-solid"></i>
                </button>
            </div>
        </div>
        <ul class="side-links">
            <button class="btn btn-outline-light career-nav-link">
                <a href="career.html">
                    Career
                </a>
            </button>
            <button class="btn btn-outline-light btn-primary">
                <a href="pricing-plan.html">
                    <i class="fa-circle-plus fa-solid"></i>
                    Add Listing
                </a>
            </button>
            <!-- Button trigger modal -->
            <button class="btn btn-outline-light open_popup">Sign In</button>
        </ul>
    </div>

    <!-- signIn & signUp Modal -->
    <div class="popup_main">
        <div class="popup_body">
            <div class="popup_back"></div>
            <div class="popup_contain">
                <div class="popup_close">&times;</div>
                <div class="left">
                    <img src="assets/imgs/signIn-img.jpg" alt="Placeholder Image">
                    <button class="toggle-btn" id="toggle-auth">Click to Sign In</button>
                </div>
                <div class="right">
                    <div class="form-container active" id="signup-form">
                        <h3>Create new account</h3>
                        <hr>
                        <form>
                            <input type="text" name="fullName" id="fullName" placeholder="Your Full Name" required>
                            <input type="email" name="email" id="email" placeholder="Your Email" required>
                            <input type="tel" name="phone" id="phone" placeholder="Your Phone Number" required>
                            <input type="text" name="city" id="state" placeholder="City" required>
                            <input type="text" name="state" id="state" placeholder="State" required>
                            <input type="number" name="pincode" id="pincode" placeholder="Pincode" required>
                            <input type="text" name="username" id="username" placeholder="Username" required>
                            <div class="form-group">
                                <input type="password" id="password" placeholder="Password" required>
                                <span class="toggle-password" onclick="togglePassword('password')">👁</span>
                            </div>
                            <div class="form-group">
                                <input type="password" id="confirm-password" placeholder="Confirm Password" required>
                                <span class="toggle-password" onclick="togglePassword('confirm-password')">👁</span>
                            </div>
                            <div class="form-btns">
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <button type="submit" class="btn btn-primary">Sign Up</button>
                            </div>
                        </form>
                        <div class="form-toggle">
                            <button class="toggle-btn" id="toggle-auth-2">Click to Sign In</button>
                        </div>
                    </div>
                </div>
                <div class="form-container" id="signin-form">
                    <h3>Sign In</h3>
                    <form>
                        <input type="text" class="mb-2" placeholder="Username" required>
                        <div class="form-group">
                            <input type="password" id="signin-password" placeholder="Password" required>
                            <span class="toggle-password" onclick="togglePassword('signin-password')">👁</span>
                        </div>
                        <div class="form-btns">
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <button type="submit" class="btn btn-primary">Sign In</button>
                        </div>
                    </form>
                    <div class="form-toggle">
                        <button class="toggle-btn" id="toggle-auth-3">Click to Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- submit listing form -->
    <div class="submit-listing">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-md-12">
                    <div class="reminder-header">
                        <p>Returning User? Please <span data-bs-toggle="modal" data-bs-target="#exampleModal">
                                Sign In
                            </span> and if you are a New User, continue below and register along with this submission.
                        </p>
                    </div>
                    <hr>
                </div>

                <div class="col-lg-8 col-md-12">
                    <div class="form-section">
                        <form action="connect/profile.php" method="POST" enctype="multipart/form-data">
                            <div class="form-separate-box">
                            <input type="hidden" name="plan_id" value="<?php echo isset($_GET['plan_id']) ? htmlspecialchars($_GET['plan_id']) : ''; ?>">

                                <h6>Primary listing details</h6>
                                <hr>
                                <div class="input-field">
                                    <label for="hotelName">
                                        Listing Title
                                        <span>*</span>
                                        <a href="#" data-bs-toggle="tooltip"
                                            data-bs-title="Put your listing title here and tell the name of your business to the world.">
                                            <i class='bx bx-question-mark'></i>
                                        </a>
                                    </label>
                                    <input type="text" name="name" id="hotelName"
                                        placeholder="Staple & Fancy Hotel">
                                </div>

                                <div class="checkbox-field">
                                    <label>
                                        <input type="checkbox" name="tagline-checkbox" id="toggle-extra"> Does Your
                                        Business
                                        Have A
                                        Tagline?
                                    </label>

                                    <div id="extra-input" class="hidden-input">
                                        <label>Tagline</label>
                                        <input type="text" name="tagline" id="tagline"
                                            placeholder="Tagline Example: Best Express Mexican Grill">
                                    </div>
                                </div>

                                <div class="form-btns-group">
                                    <button type="button" class="active toggle-form" data-form="toggle1">Search By
                                        Google</button>
                                    <button type="button" class="toggle-form" data-form="toggle2">Menual
                                        Coordinates</button>
                                    <button type="button" class="toggle-form" data-form="toggle3">
                                        <i class="fa-map-pin fa-solid"></i>
                                        Drop Pin
                                    </button>
                                </div>

                                <div id="toggle1" class="form-container">
                                    <!-- first input field -->
                                    <div class="input-field">
                                        <label for="geoLocation">
                                            Full Address (Geolocation)
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="Start typing and select your google location from google suggestions. This is for the map and also for locating your business.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <input type="text" name="geoLocation" id="geoLocation"
                                            placeholder="Start typing and find your place in google map">
                                    </div>

                                    <!-- second input field -->
                                    <div class="input-field">
                                        <label for="city">
                                            City
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="The city name will help users find you in search filters.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <input type="text" name="city" id="city"
                                            placeholder="Select your listing region">
                                    </div>

                                    <!-- third input field -->
                                    <div class="input-field">
                                        <label for="phone">Phone</label>
                                        <input type="tel" name="phone" id="phone" maxlength="10"
                                            placeholder="111-111-1234">
                                    </div>

                                    <!-- fourth input field -->
                                    <div class="input-field">
                                        <label for="website">Website</label>
                                        <input type="text" name="website" id="website" placeholder="http://">
                                    </div>
                                </div>

                                <div id="toggle2" class="form-container">
                                    <!-- first input field -->
                                    <div class="input-field">
                                        <label for="custome-address">Add Custome Address</label>
                                        <input type="text" name="custome-address" id="custome-address"
                                            placeholder="Add address here">
                                    </div>

                                    <!-- second input field -->
                                    <div class="input-field-2">
                                        <div class="first-field">
                                            <label for="latitude">Latitude</label>
                                            <input type="text" name="latitude" id="latitude" placeholder="40.7143528">
                                        </div>
                                        <div class="second-field">
                                            <label for="longitude">Longitude</label>
                                            <input type="text" name="longitude" id="longitude"
                                                placeholder="-74.0059731">
                                        </div>
                                    </div>

                                    <!-- third input field -->
                                    <div class="input-field">
                                        <label for="city">
                                            City
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="The city name will help users find you in search filters.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <input type="text" name="city" id="city"
                                            placeholder="Select your listing region">
                                    </div>

                                    <!-- fourth input field -->
                                    <div class="input-field">
                                        <label for="phone">Phone</label>
                                        <input type="tel" name="phone" id="phone" maxlength="10"
                                            placeholder="111-111-1234">
                                    </div>

                                    <!-- fifth input field -->
                                    <div class="input-field">
                                        <label for="website">Website</label>
                                        <input type="text" name="website" id="website" placeholder="http://">
                                    </div>
                                </div>

                                <!-- <div id="toggle3" class="form-container">
                                <label>Phone:</label>
                                <input type="tel">
                            </div> -->

                            </div>

                            <div class="form-separate-box">
                                <div class="box-2">
                                    <h6>Category & services</h6>
                                    <hr>
                                    <div class="input-field">
                                        <label for="category">Category<span>*</span></label>
                                        <select name="category" id="category">
                                            <option value="chooseWhat" disabled selected>Choose Your Business Category
                                            </option>
                                            <option value="arts&entertainment">Arts & Entertainment</option>
                                            <option value="automotive">Automotive</option>
                                            <option value="beauty&spa">Beauty & Spa</option>
                                            <option value="health&medical">Health & Medical</option>
                                            <option value="hotels">Hotels</option>
                                            <option value="italian">Italian</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-3">
                                    <div class="toggle-container">
                                        <div class="toggle-box">
                                            <label for="toggle-delivery">
                                                <input type="checkbox" id="toggle-delivery" class="toggle-checkbox">
                                                <span class="toggle-label"></span>
                                                Delivery
                                            </label>
                                        </div>

                                        <div class="toggle-box">
                                            <label for="toggle-takeout">
                                                <input type="checkbox" id="toggle-takeout" class="toggle-checkbox">
                                                <span class="toggle-label"></span>
                                                Take Out
                                            </label>
                                        </div>
                                    </div>

                                    <div class="checkbox-container">
                                        <div class="checkboxes">
                                            <label for="air-conditioning">
                                                <input type="checkbox" name="air-conditioning-checkbox"
                                                    id="air-conditioning-checkbox">
                                                Air Conditioning
                                            </label>
                                            <label for="dog-allowed">
                                                <input type="checkbox" name="dog-allowed-checkbox"
                                                    id="dog-allowed-checkbox">
                                                Dog Allowed
                                            </label>
                                            <label for="24hours-open">
                                                <input type="checkbox" name="24hours-open-checkbox"
                                                    id="24hours-open-checkbox">
                                                24 Hours Open
                                            </label>
                                            <label for="wheelchair-accesible">
                                                <input type="checkbox" name="wheelchair-accesible-checkbox"
                                                    id="wheelchair-accesible-checkbox">
                                                Wheelchair Accessible
                                            </label>
                                        </div>
                                    </div>

                                    <div class="radio-container">
                                        <span>Gender</span>
                                        <div class="radioes">
                                            <label for="male">
                                                <input type="radio" name="gender" id="male">
                                                Male
                                            </label>
                                            <label for="female">
                                                <input type="radio" name="gender" id="female">
                                                Female
                                            </label>
                                        </div>
                                    </div>

                                    <div class="checkbox-container">
                                        <span>Accept Payments</span>
                                        <div class="checkboxes checkboxes-2">
                                            <label for="credit-card">
                                                <input type="checkbox" name="credit-card-checkbox"
                                                    id="credit-card-checkbox">
                                                Credit Card
                                            </label>
                                            <label for="bank-transfer">
                                                <input type="checkbox" name="bank-transfer-checkbox"
                                                    id="bank-transfer-checkbox">
                                                Bank Transfer
                                            </label>
                                            <label for="mobile-payment">
                                                <input type="checkbox" name="mobile-payment-checkbox"
                                                    id="mobile-payment-checkbox">
                                                Mobile Payments
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-4">
                                    <h6>Price details</h6>
                                    <hr>
                                    <div class="input-field input-field-3">
                                        <div class="first-field">
                                            <label for="price-range">Price Range</label>
                                            <select name="price-range" id="">
                                                <option value="not-to-say">Not to say</option>
                                                <option value="not-to-say">&#8377;-Inexpensive</option>
                                                <option value="not-to-say">&#8377;&#8377;-Moderate</option>
                                                <option value="not-to-say">&#8377;&#8377;&#8377;-Pricey</option>
                                                <option value="not-to-say">&#8377;&#8377;&#8377;&#8377;-Ultra High
                                                </option>
                                            </select>
                                        </div>
                                        <div class="second-field">
                                            <label for="price-from">Price From</label>
                                            <input type="text" name="price-from" id="price-from"
                                                placeholder="Price From">
                                        </div>
                                        <div class="third-field">
                                            <label for="price-to">Price To</label>
                                            <input type="text" name="price-to" id="price-to" placeholder="Price To">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-5">
                                    <h6>Business hours</h6>
                                    <hr>
                                    <div class="business-time">
                                        <span>Monday</span>
                                        <div class="time">
                                            <p class="starting">09:00AM -</p>
                                            <p class="ending">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-circle-xmark fa-solid"></i>
                                        </div>
                                    </div>
                                    <div class="business-time">
                                        <span>Tuesday</span>
                                        <div class="time">
                                            <p class="starting">09:00AM -</p>
                                            <p class="ending">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-circle-xmark fa-solid"></i>
                                        </div>
                                    </div>
                                    <div class="business-time">
                                        <span>Wednesday</span>
                                        <div class="time">
                                            <p class="starting">09:00AM -</p>
                                            <p class="ending">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-circle-xmark fa-solid"></i>
                                        </div>
                                    </div>
                                    <div class="business-time">
                                        <span>Thursday</span>
                                        <div class="time">
                                            <p class="starting">09:00AM -</p>
                                            <p class="ending">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-circle-xmark fa-solid"></i>
                                        </div>
                                    </div>
                                    <div class="business-time">
                                        <span>Friday</span>
                                        <div class="time">
                                            <p class="starting">09:00AM -</p>
                                            <p class="ending">05:00PM</p>
                                        </div>
                                        <div class="close-day">
                                            <i class="fa-circle-xmark fa-solid"></i>
                                        </div>
                                    </div>

                                    <div class="add-another-days-container">
                                        <div class="add-another-days">
                                            <select name="weekdays" id="weekdays">
                                                <option value="monday">Monday</option>
                                                <option value="tuesday">Tuesday</option>
                                                <option value="wednesday">Wednesday</option>
                                                <option value="thursday">Thursday</option>
                                                <option value="friday">Friday</option>
                                                <option value="saturday">Saturday</option>
                                                <option value="sunday">Sunday</option>
                                            </select>

                                            <select name="day-start" id="day-start">
                                                <option value="12:00AM">12:00AM</option>
                                                <option value="12:30AM">12:30AM</option>
                                                <option value="01:00AM">01:00AM</option>
                                                <option value="01:30AM">01:30AM</option>
                                                <option value="02:00AM">02:00AM</option>
                                                <option value="02:30AM">02:30AM</option>
                                                <option value="03:00AM">03:00AM</option>
                                                <option value="04:00AM">04:00AM</option>
                                                <option value="04:30AM">04:30AM</option>
                                                <option value="05:00AM">05:00AM</option>
                                                <option value="05:30AM">05:30AM</option>
                                                <option value="06:00AM">06:00AM</option>
                                                <option value="06:30AM">06:30AM</option>
                                                <option value="07:00AM">07:00AM</option>
                                                <option value="07:30AM">07:30AM</option>
                                                <option value="08:00AM">08:00AM</option>
                                                <option value="08:30AM">08:30AM</option>
                                                <option value="09:00AM" selected>09:00AM</option>
                                                <option value="09:30AM">09:30AM</option>
                                                <option value="10:00AM">10:00AM</option>
                                                <option value="10:30AM">10:30AM</option>
                                                <option value="11:00AM">11:00AM</option>
                                                <option value="11:30AM">11:30AM</option>
                                                <option value="12:00PM">12:00M</option>
                                                <option value="12:30PM">12:30M</option>
                                                <option value="01:00PM">01:00PM</option>
                                                <option value="01:30PM">01:30PM</option>
                                                <option value="02:00PM">02:00PM</option>
                                                <option value="02:30PM">02:30PM</option>
                                                <option value="03:00PM">03:00PM</option>
                                                <option value="03:30PM">03:30PM</option>
                                                <option value="04:00PM">04:00PM</option>
                                                <option value="04:30PM">04:30PM</option>
                                                <option value="05:00PM">05:00PM</option>
                                                <option value="05:30PM">05:30PM</option>
                                                <option value="06:00PM">06:00PM</option>
                                                <option value="06:30PM">06:30PM</option>
                                                <option value="07:00PM">07:00PM</option>
                                                <option value="07:30PM">07:30PM</option>
                                                <option value="08:00PM">08:00PM</option>
                                                <option value="08:30PM">08:30PM</option>
                                                <option value="09:00PM">09:00PM</option>
                                                <option value="09:30PM">09:30PM</option>
                                                <option value="10:00PM">10:00PM</option>
                                                <option value="10:30PM">10:30PM</option>
                                                <option value="11:00PM">11:00PM</option>
                                                <option value="11:30PM">11:30PM</option>
                                            </select>

                                            <select name="day-end" id="day-end">
                                                <option value="12:00AM">12:00AM</option>
                                                <option value="12:30AM">12:30AM</option>
                                                <option value="01:00AM">01:00AM</option>
                                                <option value="01:30AM">01:30AM</option>
                                                <option value="02:00AM">02:00AM</option>
                                                <option value="02:30AM">02:30AM</option>
                                                <option value="03:00AM">03:00AM</option>
                                                <option value="04:00AM">04:00AM</option>
                                                <option value="04:30AM">04:30AM</option>
                                                <option value="05:00AM">05:00AM</option>
                                                <option value="05:30AM">05:30AM</option>
                                                <option value="06:00AM">06:00AM</option>
                                                <option value="06:30AM">06:30AM</option>
                                                <option value="07:00AM">07:00AM</option>
                                                <option value="07:30AM">07:30AM</option>
                                                <option value="08:00AM">08:00AM</option>
                                                <option value="08:30AM">08:30AM</option>
                                                <option value="09:00AM">09:00AM</option>
                                                <option value="09:30AM">09:30AM</option>
                                                <option value="10:00AM">10:00AM</option>
                                                <option value="10:30AM">10:30AM</option>
                                                <option value="11:00AM">11:00AM</option>
                                                <option value="11:30AM">11:30AM</option>
                                                <option value="12:00PM">12:00M</option>
                                                <option value="12:30PM">12:30M</option>
                                                <option value="01:00PM">01:00PM</option>
                                                <option value="01:30PM">01:30PM</option>
                                                <option value="02:00PM">02:00PM</option>
                                                <option value="02:30PM">02:30PM</option>
                                                <option value="03:00PM">03:00PM</option>
                                                <option value="03:30PM">03:30PM</option>
                                                <option value="04:00PM">04:00PM</option>
                                                <option value="04:30PM">04:30PM</option>
                                                <option value="05:00PM" selected>05:00PM</option>
                                                <option value="05:30PM">05:30PM</option>
                                                <option value="06:00PM">06:00PM</option>
                                                <option value="06:30PM">06:30PM</option>
                                                <option value="07:00PM">07:00PM</option>
                                                <option value="07:30PM">07:30PM</option>
                                                <option value="08:00PM">08:00PM</option>
                                                <option value="08:30PM">08:30PM</option>
                                                <option value="09:00PM">09:00PM</option>
                                                <option value="09:30PM">09:30PM</option>
                                                <option value="10:00PM">10:00PM</option>
                                                <option value="10:30PM">10:30PM</option>
                                                <option value="11:00PM">11:00PM</option>
                                                <option value="11:30PM">11:30PM</option>
                                            </select>

                                            <div class="24hours">
                                                <label for="24hours">
                                                    <input type="checkbox" name="24-hours-work" id="24-hours-work">
                                                    24 Hours
                                                </label>
                                            </div>
                                        </div>

                                        <div class="add-day">
                                            <i class="fa-solid fa-square-plus"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-6">
                                    <h6>Social Media</h6>
                                    <hr>
                                    <div class="socia-media-wrapper" id="social-media-list">
                                        <div class="input-field input-field-4">
                                            <div class="first-field">
                                                <label for="category">Select</label>
                                                <select name="categoryy" id="category">
                                                    <option value="chooseWhat" disabled selected>Please select
                                                    </option>
                                                    <option name="instagram" value="instagram">Instagram</option>
                                                    <option name="youtube" value="youtube">Youtube</option>
                                                    <option name="linkedin" value="linkedin">LinkedIn</option>
                                                    <option name="facebook" value="facebook">Facebook</option>
                                                    <option name="twitter" value="twitter">Twitter</option>
                                                </select>
                                                <input type="text" name="choose-social-media" id="choose-social-media">
                                            </div>
                                            <div class="add-day">
                                                <i class="fa-solid fa-square-plus"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-7">
                                    <h6>Frequently asked questions</h6>
                                    <hr>
                                    <div class="faq-container">
                                        <div id="faq-list">
                                            <div class="faq-item" data-index="1">
                                                <p>FAQ</p>
                                                <div class="inputs-box">
                                                    <input type="text" name="faq" id="faq" placeholder="FAQ">
                                                    <textarea name="faq-answer" id="faq-answer"
                                                        placeholder="Answer"></textarea>
                                                </div>
                                                <div class="remove-faq">
                                                    <i class="fa-solid fa-square-minus"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="add-btn" id="add-faq">
                                            <i class="fa-solid fa-square-plus"></i>
                                            Add New
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-8">
                                    <h6>More info</h6>
                                    <hr>
                                    <label for="editor">Description <span style="color: red;">*</span></label>
                                    <textarea id="editor">Detail description about your listing</textarea>

                                    <div class="input-field">
                                        <label for="geoLocation">
                                            Tags you keywords (Comma seprated)
                                            <a href="#" data-bs-toggle="tooltip"
                                                data-bs-title="These keywords or tags will help your listing to find in search. Add a comma separated list of keywords related to your business.">
                                                <i class='bx bx-question-mark'></i>
                                            </a>
                                        </label>
                                        <textarea name="tags-keywords" id="tags-keywords"
                                            placeholder="Enter tags or keywords comma separated..."></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-9">
                                    <h6>Media</h6>
                                    <hr>
                                    <div class="input-field">
                                        <label for="geoLocation">
                                            Your Business Video (Optional)
                                        </label>
                                        <input type="url" name="video-link" id="video-link"
                                            placeholder="ex: https://youtu.be/IY2yjAdbvdQ">
                                    </div>
                                    <div class="input-field">
                                        <div class="upload-container" id="upload-area">
                                            <label for="upload-file">Image</label>
                                            <div class="drop-zone">
                                                <p>Drop files here or click to upload</p>
                                                <input type="file" id="image" name="image[]" class="file-input" multiple>
                                                <button type="button" class="btn browse-btn" id="browse-btn">Browse Files</button>
                                            </div>

                                            <label for="upload-logo">Upload Business Logo</label>
                                            <div class="input-field">
                                                <label for="image"></label>
                                                <input type="file" name="image[]" id="image" multiple>
                                            </div>
                                        </div>
                                        <!-- Video Upload -->
                                        <div class="input-field">
                                            <label for="video">Upload Business Video</label>
                                            <input type="file" name="video" id="video" accept="video/*">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-separate-box">
                                <div class="box-10">
                                    <!-- first input field -->
                                    <div class="input-field" id="email-field">
                                        <label for="email-for-signUp">Enter Email to Signup & Receive Notification Upon
                                            Listing Approval</label>
                                        <input type="email" name="email-for-signUp" id="email-for-signUp"
                                            placeholder="your contact email">
                                    </div>

                                    <!-- Checkbox -->
                                    <div class="form-group">
                                        <input type="checkbox" id="toggle-account"> <label for="toggle-account">Already
                                            Have Account?</label>
                                    </div>

                                    <!-- second input field -->
                                    <div class="toggle-fields">
                                        <div class="input-field-2">
                                            <div class="first-field">
                                                <label for="username">Username</label>
                                                <input type="text" name="username" id="username" placeholder="Username">
                                            </div>
                                            <div class="second-field">
                                                <label for="password">Password</label>
                                                <input type="password" name="password" id="password"
                                                    placeholder="Password">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="submit-form">
                                <!-- Add this button just before the closing </form> tag -->
                                <!-- Replace the Save & Preview button -->
                                <button type="submit" id="savePreviewBtn" class="btn btn-primary" formaction="connect/profile.php" formmethod="POST">
                                    Save & Preview
                                </button>

                            </div>
                        </form>
                        <div id="previewSection" style="display: none; margin-top: 20px; border: 1px solid #ccc; padding: 15px;">
                            <h3>Preview Details</h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="scroll-card-container">
                        <div class="scroll-card" id="scroll-card">
                            <div class="card-content">
                                <h4 id="scroll-card-heading">Title</h4>
                                <p id="scroll-card-text">Enter your complete business name for when people who know
                                    your business by name and are looking you up.</p>
                                <img id="scroll-card-image" src="assets/imgs/scroll-title.png" alt="Image 1">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="copyright">Copyright © 2025 Bizvility</p>
                    <p class="developBy">Developed by Bizvility</p>
                    <div class="social-media">
                        <i class="fa-brands fa-square-facebook"></i>
                        <i class="fa-brands fa-square-x-twitter"></i>
                        <i class="fa-brands fa-square-instagram"></i>
                        <i class="fa-brands fa-youtube"></i>
                        <i class="fa-solid fa-whiskey-glass"></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/7.6.0/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/js/submitlisting.js"></script>

</body>
<!-- Add this script tag at the end of the body, just before the closing </body> tag -->
<script>
    // Get the query parameters from the URL
    const urlParams = new URLSearchParams(window.location.search);

    // Retrieve the plan_id from the query parameters
    const planId = urlParams.get('plan_id');

    // Log the plan_id to the console
    console.log('Plan ID:', planId);

    // Optional: Display the plan_id in an alert (for testing purposes)
    if (planId) {
        // alert('Plan ID: ' + planId);
    }

    document.getElementById("browse-btn").addEventListener("click", function() {
        document.getElementById("image").click();
        document.getElementById("savePreviewBtn").addEventListener("click", function() {
            // Collect form data
            const hotelName = document.getElementById("hotelName").value;
            const tagline = document.getElementById("tagline").value;
            const geoLocation = document.getElementById("geoLocation").value;
            const city = document.getElementById("city").value;
            const phone = document.getElementById("phone").value;
            const website = document.getElementById("website").value;
            // Trigger the file input click
        });


        // Create preview content
        const previewContent = `
            <p><strong>Listing Title:</strong> ${hotelName}</p>
            <p><strong>Tagline:</strong> ${tagline}</p>
            <p><strong>Full Address:</strong> ${geoLocation}</p>
            <p><strong>City:</strong> ${city}</p>
            <p><strong>Phone:</strong> ${phone}</p>
            <p><strong>Website:</strong> <a href="${website}" target="_blank">${website}</a></p>
        `;

        // Display preview content in the section
        const previewSection = document.getElementById("previewSection");
        previewSection.innerHTML = previewContent;
        previewSection.style.display = "block"; // Make it visible
    });
</script>


</html>