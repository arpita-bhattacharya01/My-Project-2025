<?php
session_start();
require_once './connect/config.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['id']) || !isset($_SESSION['fullname'])) {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['id'];
$user_fullname = $_SESSION['fullname'];
$user_image = $_SESSION['image'];
// $_SESSION['image'] = $user['image'];


// Fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Modified SQL query to join tables
$stmt2 = $conn->prepare("SELECT 
        e.*, 
        u.fullname, 
        u.email, 
        u.phone, 
        u.image,
        p.title AS plan_title,
        p.price AS plan_price,
        p.duration AS plan_duration
    FROM enquiry e
    LEFT JOIN users u ON e.user_id = u.id
    LEFT JOIN plans p ON e.plan_id = p.id");
$stmt2->execute();
$enquiries = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt2->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Update</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<style>
    /* Sidebar Toggle */
    .sidebar {
        width: 250px;
        transition: width 0.3s ease;
    }

    .sidebar.collapsed {
        width: 0;
        overflow: hidden;
    }

    /* Profile Dropdown */
    .profile-dropdown {
        position: relative;
        display: inline-block;
        cursor: pointer;
    }

    .profile-dropdown .dropdown-menu {
        display: none;
        position: absolute;
        right: 0;
        background: #fff;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        border-radius: 5px;
        min-width: 150px;
        z-index: 100;
    }

    .profile-dropdown .dropdown-menu ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .profile-dropdown .dropdown-menu ul li {
        padding: 10px;
        border-bottom: 1px solid #ddd;
        cursor: pointer;
    }

    .profile-dropdown .dropdown-menu ul li:hover {
        background: #f5f5f5;
    }

    /* Modal styles */
    /* .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 500px;
        border-radius: 5px;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    } */
     /* Enhanced Modal Styles */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1000; /* High z-index to be on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
}

.modal-content {
    background-color: #fefefe;
    margin: 10% auto; /* Center vertically and horizontally */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Adjust width as needed */
    max-width: 500px; /* Maximum width */
    border-radius: 8px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Subtle shadow */
    position: relative; /* For close button positioning */
}

.close {
    color: #aaa;
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

.modal-content h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #333;
    text-align: center;
}

.modal-content label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #555;
}

.modal-content select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box; /* Prevent padding from increasing width */
    font-size: 1em;
}

.modal-content button#saveStatusBtn {
    background-color: #007bff; /* Primary blue */
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1em;
    transition: background-color 0.3s ease;
    display: block; /* Make it a block-level element */
    width: 100%; /* Full width button */
}

.modal-content button#saveStatusBtn:hover {
    background-color: #0056b3;
}

/* Optional: Add some spacing between elements */
.modal-content > * {
    margin-bottom: 15px;
}

.modal-content > *:last-child {
    margin-bottom: 0; /* Remove margin from the last element */
}

    /* Status badge styles */
    /* .status-badge {
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 0.8em;
        color: #fff;
    }

    .status-badge.Approved {
        background-color: #28a745;
    }

    .status-badge.Pending {
        background-color: #ffc107;
    }

    .status-badge.Rejected {
        background-color: #dc3545;
    } */
    .status-badge {
        display: inline-block;
        /* Or inline, block depending on layout */
        padding: 5px 10px;
        border-radius: 5px;
        color: black;
        /* Default text color */
        font-size: 0.9em;
        margin-right: 5px;
        /* Add some space between badge and icon */
    }

    .pending {
        background-color: oldlace;
    }

    .approved {
        background-color: green;
    }

    .rejected {
        background-color: red;
    }

    .edit-icon {
        /* Style your edit icon as needed */
        cursor: pointer;
        font-size: 1em;
        color: blue;
        /* Example color */
    }

    /* Add this CSS for better presentation */
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin-right: 10px;
    }

    .user-info {
        display: flex;
        align-items: center;
    }
</style>

<body>

    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="assets//imgs/logo.png" alt="biZvility Logo">
            </div>
            <!-- <i class="fas fa-bars hamburger" id="sidebar-toggle"></i> -->
            <i class="fas fa-bars hamburger" id="sidebar-toggle"></i>

        </div>

        <ul>
            <a href="./connect/adminnew_dashboard.php">
                <li><i class="fa-solid fa-gauge"></i> <span>Dashboard</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-tags"></i> <span>Pricing-Plans</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-utensils"></i> <span>Users</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-location-dot"></i> <span>Enquiry</span></li>
            </a>
            <a href="#">
                <li><i class="fa-regular fa-envelope"></i> <span>Inbox</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-paper-plane"></i> <span>Invoices</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-paper-plane"></i> <span>Ads Invoices</span></li>
            </a>
            <a href="#">
                <li><i class="fa-solid fa-heart"></i> <span>Saved</span></li>
            </a>
            <a href="./connect/logout.php" style="text-decoration: none; color: inherit;">
                <i class="fa-solid fa-sign-out-alt"></i> <span>Logout</span>
            </a>

            </a>
        </ul>
    </div>


    <div class="main-content" id="main-content">

        <div class="top-nav">
            <div class="nav-links">
                <a href="pricing-plan.php">+ Add Listing</a>
                <a href="#">📞 Contact Support</a>
                <p><?php echo htmlspecialchars($_SESSION['fullname']); ?></p>
                <div class="leftdata">
                    <img id="profileImageforleft" src="<?php
                                                        $imageSrc = '';
                                                        if (!empty($_SESSION['image']) && $_SESSION['image'] !== 'default.jpg' && !strpos($_SESSION['image'], 'flaticon.com')) {
                                                            $imageSrc = './uploads/profile_images/' . $_SESSION['image'];
                                                        } else {
                                                            $imageSrc = 'default.jpg'; // Adjust this to the correct path/URL of your default image
                                                        }
                                                        // Handle NULL or empty explicitly
                                                        if (empty($_SESSION['image']) || $_SESSION['image'] === null) {
                                                            $imageSrc = 'default.jpg'; // Or your placeholder image path
                                                        }
                                                        echo htmlspecialchars($imageSrc);
                                                        ?>" alt="Profile Picture">
                </div>
                <i class="fas fa-bars top-nav-hamburger" id="sidebar-toggle"></i>
            </div>
        </div>
        <div class="open-profile-box">
            <ul>
                <a href="./connect/adminnew_dashboard.php">
                    <li>
                        <i class="fa-solid fa-circle-user"></i>
                        My Profile
                    </li>
                </a>
                <a href="./connect/logout.php">
                    <li>
                        <i class="fa-solid fa-lock"></i>
                        Logout
                    </li>
                </a>
            </ul>
        </div>

        <div class="container listing-container">
            <h4>All Listings</h4>
            <div class="listing-header">
                <div class="listing-btns">
                    <button type="button" class="btn all-btn active">All</button>
                    <button type="button" class="btn published-btn">Approved</button>
                    <button type="button" class="btn pending-btn">Pending</button>
                    <button type="button" class="btn expired-btn">Expired</button>
                </div>
                <div class="analystics-user-div">
                    <strong>Add Google Analytics User ID</strong>
                    <input type="text" placeholder="Analystics User ID">
                    <button type="submit" class="save-btn">Save</button>
                </div>
            </div>

            <!-- Status Update Modal -->
            <div id="statusModal" class="modal">
                <div class="modal-content">
                    <span class="close">&times;</span>
                    <h3>Edit Status</h3>
                    <input type="hidden" id="selectedEnquiryId">
                    <select id="statusDropdown">
                        <option value="Approved">Approved</option>
                        <option value="Pending">Pending</option>
                        <option value="Rejected">Rejected</option>
                    </select>
                    <button id="saveStatusBtn">Save</button>
                </div>
            </div>

            <!-- Table Section -->
            <div class="table-wrapper">
                <div class="table-container all-table active">
                    <table>

                        <colgroup>
                            <col width="150">
                            <col width="400">
                            <col width="300">
                            <col width="300">
                            <col width="250">
                            <col width="200">
                            <col width="300">
                        </colgroup>

                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>User</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Plan Title & Price</th>
                                <th>Associated Plan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $profileLinks = [
                                "Dr. Meghal Goyal" => "dr-meghal.html",
                                "Dr. Chitra Janu" => "dr-chitra.html",
                                "Dr. Khushboo Goyal" => "dr-khushboo.html",
                                "Dr. Reecha Agarwal" => "dr-richa.html",
                                "Dr. Saumyata Neeraj" => "dr-saumyata.html",
                                "Dr. Shriyansh Chahar" => "dr-shriyansh.html",
                                "Dr. Arun Gupta" => "dr-arun.html"
                            ];
                            if (!empty($enquiries)) {
                                foreach ($enquiries as $row) {
                                    echo "<tr class='" . strtolower(htmlspecialchars($row['approval_status'])) . "'>";
                                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";

                                    // Title with Profile Link and Category
                                    $profileLink = isset($profileLinks[$row['fullname']]) ? $profileLinks[$row['fullname']] : "#";
                                    echo "<td>
                                        <div class='user-info'>
                                            <img src='./uploads/profile_images/" . htmlspecialchars($row['image'] ?? 'default.jpg') . "' 
                                                 class='user-avatar' 
                                                 alt='" . htmlspecialchars($row['fullname']) . "'>
                                            <a href='" . htmlspecialchars($profileLink) . "'>
                                                <strong>" . htmlspecialchars($row['fullname']) . "</strong>
                                            </a>
                                        </div>
                                        <br><small>" . htmlspecialchars($row['category']) . "</small>
                                    </td>";
                                    echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
                                    // Status Column with Edit Button
                                    echo "<td class='status-cell' data-id='" . htmlspecialchars($row['id']) . "'>";
                                    echo "<span class='status-badge " . htmlspecialchars($row['approval_status']) . "'>" . htmlspecialchars($row['approval_status']) . "</span>";
                                    echo " <i class='fa fa-edit edit-icon' data-id='" . htmlspecialchars($row['id']) . "'></i>";
                                    echo "</td>";
                                    // plan_title and price
                                    echo "<td>";
                                    if (isset($row['plan_title']) && isset($row['plan_price'])) {
                                        echo htmlspecialchars($row['plan_title']) . "<br>₹" . htmlspecialchars($row['plan_price']);
                                    } else {
                                        echo "N/A";
                                    }
                                    echo "</td>";
                                    // plan_duration
                                    echo "<td>" . htmlspecialchars($row['plan_duration'] ?? 'N/A') . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No records found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="table-container published-table">
                    <table>

                        <colgroup>
                            <col width="150">
                            <col width="450">
                            <col width="300">
                            <col width="200">
                            <col width="300">
                            <col width="200">
                            <col width="300">
                        </colgroup>

                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Associated Plan</th>
                            </tr>
                        </thead>
                        <tbody id="published-table-body">
                        </tbody>
                    </table>
                </div>

                <div class="table-container pending-table">
                    <table>

                        <colgroup>
                            <col width="150">
                            <col width="450">
                            <col width="300">
                            <col width="200">
                            <col width="300">
                            <col width="200">
                            <col width="300">
                        </colgroup>

                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Associated Plan</th>
                            </tr>
                        </thead>
                        <tbody id="pending-table-body">
                        </tbody>
                    </table>
                </div>

                <div class="table-container expired-table">
                    <table>

                        <colgroup>
                            <col width="150">
                            <col width="450">
                            <col width="300">
                            <col width="200">
                            <col width="300">
                            <col width="200">
                            <col width="300">
                        </colgroup>

                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Associated Plan</th>
                            </tr>
                        </thead>
                        <tbody id="expired-table-body">
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="assets/js/scripts.js"></script>
    <script>
        $(document).ready(function() {
            // Sidebar toggle functionality
            $('#sidebar-toggle').click(function() {
                $('.sidebar').toggleClass('collapsed');
                $('.main-content').toggleClass('expanded');
            });

            // Status update functionality
            $('.edit-icon').click(function() {
                var enquiryId = $(this).data('id');
                $('#selectedEnquiryId').val(enquiryId);
                $('#statusModal').css('display', 'block');

                // Optionally, fetch the current status and set the dropdown
                var currentStatus = $(this).siblings('.status-badge').text().trim();
                $('#statusDropdown').val(currentStatus);
            });

            $('.close').click(function() {
                $('#statusModal').css('display', 'none');
            });

            $('#saveStatusBtn').click(function() {
                var enquiryId = $('#selectedEnquiryId').val();
                // Get the value from the dropdown and convert it to lowercase
                var newStatus = $('#statusDropdown').val().toLowerCase();

                $.ajax({
                    url: 'connect/update_enquiry_status.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        enquiry_id: enquiryId,
                        status: newStatus
                    },
                    success: function(response) {
                        console.log("Status Updated successfully");

                        if (response.status === 'success') {
                            console.log("Status updated successfully!");
                            $('#statusModal').css('display', 'none');
                            // // Update the UI with the lowercase status (capitalize for display if needed)
                            var displayStatus = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
                            $('.status-cell[data-id="' + enquiryId + '"]')
                                .html('<span class="status-badge ' + newStatus + '">' + displayStatus + '</span> <i class="fa fa-edit edit-icon" data-id="' + enquiryId + '"></i>');

                            var activeFilter = $('.listing-btns .btn.active').data('status');
                            filterTable(activeFilter);
                            // Re-bind the click event to the newly added edit icon
                            $('.edit-icon').off('click').on('click', function() {
                                var enquiryId = $(this).data('id');
                                $('#selectedEnquiryId').val(enquiryId);
                                $('#statusModal').css('display', 'block');

                                // Optionally, fetch the current status and set the dropdown
                                var currentStatus = $(this).siblings('.status-badge').text().trim();
                                $('#statusDropdown').val(currentStatus);
                            });

                        } else if (response.status === 'error') {
                            console.error("Error updating status:", response.message);
                            alert("Error updating status: " + response.message);
                        } else {
                            console.warn("Unexpected response:", response);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX request failed:", status, error);
                        console.log("Raw response from server:", xhr.responseText); // <-- Add this line
                        alert("AJAX request failed: " + error);
                    }
                });
            });
        });
        // Function to filter the table based on the status
        function filterTable(status) {
            // Hide all rows first
            $('table tbody tr').hide();

            // If status is "all", show all rows
            if (status === 'all') {
                $('table tbody tr').show();
            } else {
                // Show only rows that match the data-status
                $('table tbody tr').filter(function() {
                    return $(this).find('.status-badge').text().trim() === status;
                }).show();
            }
        }

        // Add click event listener to all filter buttons
        $('.listing-btns .btn').click(function() {
            // Remove active class from all buttons
            $('.listing-btns .btn').removeClass('active');

            // Add active class to the clicked button
            $(this).addClass('active');

            // Get the status from the data-status attribute of the button
            var status = $(this).data('status');

            // Filter the table
            filterTable(status);
        });
        // Initial filtering based on the active button (if any) on page load
        // var initialActiveFilter = $('.listing-btns .btn.active').data('status');
        // filterTable(initialActiveFilter);
        // });
    </script>
</body>

</html>