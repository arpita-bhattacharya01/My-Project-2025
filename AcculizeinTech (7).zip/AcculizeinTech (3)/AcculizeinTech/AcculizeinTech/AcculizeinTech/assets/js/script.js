// scroll navbar
let nav = document.querySelector('nav')
window.addEventListener('scroll', function () {
    if (window.scrollY >= 80) {
        nav.classList.add('scroll')
    } else {
        nav.classList.remove('scroll')
    }
});

let nav2 = document.querySelector('header')
window.addEventListener('scroll', function () {
    if (window.scrollY >= 100) {
        nav2.classList.add('scroll-2')
    } else {
        nav2.classList.remove('scroll-2')
    }
});

// side-menu
$(document).on('click', '.menu-open', function () {
    $(this).css({
        display: 'none'
    })

    $('.menu-close').css({
        display: 'block'
    })

    $('.side-menu').slideDown()
})

$(document).on('click', '.menu-close', function () {
    $(this).css({
        display: 'none'
    })

    $('.menu-open').css({
        display: 'block'
    })

    $('.side-menu').slideUp()
})

// toggle-review-form
$(document).on('click', '.review-toggle', function () {
    $('.toggle-review-form').slideToggle()
});

// toggle-review-form tabs buttons
$(document).ready(function () {
    $(".tabs-doctor-about .btn").on("click", function () {
        if (!$(this).hasClass("active")) {
            $(".tabs-doctor-about .btn").removeClass("active");
            $(this).addClass("active");

            let tabId = $(this).data("tab");
            $(".tab-content.active").fadeOut(200, function () {
                $(this).removeClass("active").css("display", "none"); // अब यह double fadeOut नहीं होगा
                $("#" + tabId).css("display", "flex").hide().fadeIn(200).addClass("active"); // flex design नहीं बिगड़ेगा
            });
        }
    });
});

// doctor call
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".call-first a").forEach(function (link) {
        link.addEventListener("click", function (event) {
            event.preventDefault(); // Prevent the default link behavior

            let callFirst = this.closest(".call-first");
            let callSecond = callFirst.parentElement.querySelector(".call-second"); // Correct selection of call-second

            if (callSecond) {
                callFirst.style.display = "none"; // Hide the first link
                callSecond.style.display = "flex"; // Show the second link
            }
        });
    });
});

// Function to change the menu button icon
function menuBtnChange() {
    if (asidebar.classList.contains("open")) {
        closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); // Change icon to indicate closing
    } else {
        closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); // Change icon to indicate opening
    }
}

// what & where selection
$(document).ready(function () {
    function setupDropdown(inputSelector, listSelector) {
        const input = $(inputSelector);
        const list = $(listSelector);

        input.on("focus", function () {
            $(".dropdown-list").hide(); // Hide all dropdowns
            list.show(); // Show only the clicked one
        });

        input.on("input", function () {
            const searchText = input.val().toLowerCase();
            list.find(".dropdown-item").each(function () {
                $(this).toggle($(this).text().toLowerCase().includes(searchText));
            });
            list.toggle(list.find(".dropdown-item:visible").length > 0);
        });

        $(document).on("click", ".dropdown-item", function () {
            input.val($(this).text());
            list.hide();
        });

        $(document).on("click", function (event) {
            if (!input.is(event.target) && !list.is(event.target) && list.has(event.target).length === 0) {
                list.hide();
            }
        });
    }

    // Setup dropdowns for both .side-menu and .side-menu-2
    setupDropdown("#what-input", "#what-list");
    setupDropdown("#where-input", "#where-list");
    setupDropdown(".side-menu-2 #what-input", ".side-menu-2 #what-list");
    setupDropdown(".side-menu-2 #where-input", ".side-menu-2 #where-list");

    const apiUsername = "sharma9299"; // Replace with your API username
    fetch(`https://secure.geonames.org/searchJSON?country=IN&featureClass=P&maxRows=1000&username=${apiUsername}`)
        .then(response => response.json())
        .then(data => {
            const apiCitiesContainer1 = $("#where-list");
            const apiCitiesContainer2 = $(".side-menu-2 #where-list");

            apiCitiesContainer1.empty();
            apiCitiesContainer2.empty();

            data.geonames.forEach(city => {
                const cityItem = `<div class="dropdown-item">${city.name}, ${city.adminName1}</div>`;
                apiCitiesContainer1.append(cityItem);
                apiCitiesContainer2.append(cityItem);
            });
        })
        .catch(error => console.error("❌ API Fetch Error:", error));
});


// sign In & sign Up modal(index)
$(document).ready(function () {
    const toggleAuthBtn = document.getElementById("toggle-auth");
    const toggleAuthBtn2 = document.getElementById("toggle-auth-2");
    const toggleAuthBtn3 = document.getElementById("toggle-auth-3");
    const signUpForm = document.getElementById("signup-form");
    const signInForm = document.getElementById("signin-form");
    const categorySelect = document.getElementById('category');
    const otherInput = document.getElementById('otherInput');
    let isSignUp = true;

    toggleAuthBtn.addEventListener("click", () => {
        isSignUp = !isSignUp;

        if (isSignUp) {
            signUpForm.style.display = "block";
            signInForm.style.display = "none";
            toggleAuthBtn.textContent = "Click to Sign In";
        } else {
            signUpForm.style.display = "none";
            signInForm.style.display = "block";
            toggleAuthBtn.textContent = "Click to Sign Up";
        }
    });

    toggleAuthBtn2.addEventListener("click", () => {
        isSignUp = !isSignUp;

        if (isSignUp) {
            signUpForm.style.display = "block";
            signInForm.style.display = "none";
        } else {
            signUpForm.style.display = "none";
            signInForm.style.display = "block";
        }
    });

    toggleAuthBtn3.addEventListener("click", () => {
        isSignUp = !isSignUp;

        if (isSignUp) {
            signUpForm.style.display = "block";
            signInForm.style.display = "none";
        } else {
            signUpForm.style.display = "none";
            signInForm.style.display = "block";
        }
    });

    // 'Other' category input show/hide
    categorySelect.addEventListener('change', function () {
        if (this.value === 'Other') {
            otherInput.style.display = 'block';
            otherInput.required = true;
        } else {
            otherInput.style.display = 'none';
            otherInput.required = false;
        }
    });
});

//see password
function togglePassword(id) {
    const input = document.getElementById(id);
    input.type = (input.type === "password") ? "text" : "password";
}

$(".open_popup").click(function () {
    $(".popup_main").children(".popup_body").addClass("popup_body_show");
});
$(".open_popup_2").click(function () {
    $(".popup_main_2").children(".popup_body").addClass("popup_body_show");
});
$(".popup_close").click(function () {
    $(".popup_body").removeClass("popup_body_show");
});
$(".popup_back").click(function () {
    $(".popup_body").removeClass("popup_body_show");
});


// pricing cards
$(document).ready(function () {
    console.log("✅ Document Ready - Initializing Tabs");

    // ✅ Set Default Active Tab (e.g., Monthly)
    let defaultTab = $('.card-tabs button.monthly'); // Change 'monthly' to the default tab you want

    // ✅ Ensure it is active
    $('.card-tabs button').removeClass('btn-primary').addClass('btn-outline-primary'); // Reset all buttons
    defaultTab.removeClass('btn-outline-primary').addClass('btn-primary'); // Set active class

    // ✅ Hide all cards and show the default one
    $('#monthly-cards, #yearly-cards, #custom-cards').css('display', 'none'); // Hide all
    $('#monthly-cards').css('display', 'flex'); // Show the default one (change accordingly)

    // ✅ On Click, Switch Tabs
    $(document).on('click', '.card-tabs button', function () {
        // Remove active class from all buttons
        $('.card-tabs button').removeClass('btn-primary').addClass('btn-outline-primary');

        // Add active class to the clicked button
        $(this).removeClass('btn-outline-primary').addClass('btn-primary');

        // Hide all cards
        $('#monthly-cards, #yearly-cards, #custom-cards').css('display', 'none');

        // Show the selected card section
        if ($(this).hasClass('monthly')) {
            $('#monthly-cards').css('display', 'flex');
        } else if ($(this).hasClass('yearly')) {
            $('#yearly-cards').css('display', 'flex');
        } else if ($(this).hasClass('custom')) {
            $('#custom-cards').css('display', 'flex');
        }
    });
});


// sorting dropdown
$(document).on('click', '.open-list', function () {
    $('.sort-list').toggle()
})

// show map
function openMap() {
    document.getElementById("mapModal").style.display = "flex";
}
function closeMap() {
    document.getElementById("mapModal").style.display = "none";
}

function openMap2() {
    document.getElementById("mapModal2").style.display = "flex";
}
function closeMap2() {
    document.getElementById("mapModal2").style.display = "none";
}

// see filters dropdown
$(document).on('click', '.see-filters-btn', function () {
    $('.see-filters').toggle()
})

// tooltip
const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

// toggle checkbox and form
$(document).ready(function () {
    // Show first form by default
    $("#toggle1").show();

    $(".toggle-form").click(function () {
        var formId = $(this).data("form");

        $(".form-container").slideUp();
        $("#" + formId).slideDown();

        $(".toggle-form").removeClass("active");
        $(this).addClass("active");
    });

    $("#toggle-extra").change(function () {
        $("#extra-input").slideToggle(this.checked);
    });
});


// add new FQA
$(document).ready(function () {
    let faqCount = 1;
    $("#add-faq").click(function () {
        faqCount++;
        let newFaq = `
            <div class="faq-item" data-index="${faqCount}">
                <p>FAQ ${faqCount}</p>
                <div class="inputs-box">
                    <input type="text" name="faq" id="faq" placeholder="FAQ">
                    <textarea name="faq-answer" id="faq-answer" placeholder="Answer"></textarea>
                </div>
            </div>
        `;
        $("#faq-list").append(newFaq);
    });
});


// tinymce
tinymce.init({
    selector: '#editor',
    height: 300,
    plugins: 'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table paste help wordcount',
    toolbar: 'undo redo | styles | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    branding: false,  // Remove "Powered by TinyMCE"
    statusbar: false,  // Remove status bar
    menubar: false,  // Hide the top menu bar
    paste_as_text: false, // Allow Word formatting
    paste_data_images: true, // Allow pasting images from Word
    promotion: false // Remove upgrade option
});


// upload file
const uploadArea = document.getElementById('upload-area');
const fileInput = document.getElementById('file-input');
const browseBtn = document.getElementById('browse-btn');

uploadArea.addEventListener('click', () => fileInput.click());
browseBtn.addEventListener('click', () => fileInput.click());

uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.style.borderColor = "#007bff";
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.style.borderColor = "#ccc";
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.style.borderColor = "#ccc";
    fileInput.files = e.dataTransfer.files;
    alert(`${fileInput.files.length} file(s) selected.`);
});


// email for signUp
$(document).ready(function () {
    $("#toggle-account").change(function () {
        if ($(this).is(":checked")) {
            $("#email-field").slideUp(); // Hide email input
            $(".toggle-fields").slideDown(); // Show username & password
        } else {
            $(".toggle-fields").slideUp(); // Hide username & password
            $("#email-field").slideDown(); // Show email input
        }
    });
});


// scroll card
let contents = [
    { heading: "Title", text: "Enter your complete business name for when people who know your business by name and are looking you up.", img: "assets/imgs/scroll-title.png", scroll: 0 },

    { heading: "Full Address", text: "Provide your full address for your business to show up on the map and your customer can get direction.", img: "assets/imgs/scroll-address.png", scroll: 50 },

    { heading: "Phone", text: "Local phone numbers drive 3x more calls than toll-free numbers. Always use a business phone number and avoid personal phone numbers if possible.", img: "assets/imgs/scroll-address.png", scroll: 100 },

    { heading: "Website", text: "Its recommended to provide official website url and avoid landing pages designed for a specific campaign", img: "assets/imgs/scroll-address.png", scroll: 130 },

    { heading: "Caregories", text: "The more specific you get with your categories, the better. You do still want to stay relevant to your business, though. If you ever choose to run ads campaign, your ad will be shown on those categories you select.", img: "assets/imgs/scroll-categories.png", scroll: 400 },

    { heading: "Price Range", text: "Setting a price range can help attract the right targeted audience and will avoid any awkward situations for both customers and the owner.", img: "assets/imgs/scroll-price.png", scroll: 570 },

    { heading: "Business Hours", text: "You dont want your customers to stop by when you are closed so always try to keep your hour up to date. Keeping your store closed when your business indicate its open on the directory could lead to a negative review.", img: "assets/imgs/scroll-business.png", scroll: 950 },

    { heading: "FAQ", text: "Share some of the most asked question and answers so they know you are serious about your business and truly care for your customers.", img: "assets/imgs/scroll-FAQ.png", scroll: 1550 },

    { heading: "Description", text: "Tell briefly what your customers what to hear about your business has to offer that is unique and you do better then everyone else.", img: "assets/imgs/scroll-description.png", scroll: 2080 },

    { heading: "Video", text: "Take it to next level and provide more details about what you have to offer. Select all that applies to you.", img: "assets/imgs/scroll-video.png", scroll: 2580 },

    { heading: "Gallery", text: "", img: "assets/imgs/scroll-gallery.png", scroll: 2890 },
    { heading: "Business Logo", text: "", img: "assets/imgs/scroll-gallery.png", scroll: 3000 }
];
let currentIndex = -1;

$(window).on("scroll", function () {
    let scrollPosition = $(this).scrollTop();

    // Content change logic based on custom scroll values
    for (let i = contents.length - 1; i >= 0; i--) {
        if (scrollPosition >= contents[i].scroll) {
            if (currentIndex !== i) {
                currentIndex = i;
                $("#scroll-card-heading").text(contents[i].heading);
                $("#scroll-card-text").text(contents[i].text);
                $("#scroll-card-image").attr("src", contents[i].img);
            }
            break;
        }
    }
});











