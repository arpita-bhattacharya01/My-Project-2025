
// // // Sidebar Toggle
// // $(document).ready(function () {
// //     $('.btn').on('click', function () {
// //         $('[class^="more-btn-box-"]').hide(); // Hides all "more-btn-box" elements
// //     });

// //     // Open listing table container
// //     const allBtn = $(".all-btn");
// //     const publishedBtn = $(".published-btn");
// //     const pendingBtn = $(".pending-btn");
// //     const expiredBtn = $(".expired-btn");

// //     const allTable = $(".all-table");
// //     const publishedTableContainer = $(".published-table");
// //     const pendingTableContainer = $(".pending-table");
// //     const expiredTableContainer = $(".expired-table");

// //     const allTableBody = $(".all-table tbody");
// //     const publishedTableBody = $("#published-table-body");
// //     const pendingTableBody = $("#pending-table-body");
// //     const expiredTableBody = $("#expired-table-body");

// //     // Function to populate a table body with filtered rows
// //     function populateTable(targetTableBody, filterStatus) {
// //         targetTableBody.empty();
// //         allTableBody.find('tr').each(function() {
// //             const status = $(this).find('td:nth-child(4)').text().toLowerCase();
// //             if (status === filterStatus) {
// //                 targetTableBody.append($(this).clone());
// //             }
// //         });
// //         if (targetTableBody.is(':empty')) {
// //             targetTableBody.append('<tr><td colspan="7">No records found with status: ' + filterStatus.charAt(0).toUpperCase() + filterStatus.slice(1) + '</td></tr>');
// //         }
// //     }

// //     // Set active table
// //     function setActiveTable(activeTableContainer, btn) {
// //         $(".table-container").removeClass("active");
// //         activeTableContainer.addClass("active");

// //         $(".btn").removeClass("active");
// //         btn.addClass("active");
// //     }

// //     // Event Listeners
// //     allBtn.on("click", function () {
// //         setActiveTable(allTable, $(this));
// //     });

// //     publishedBtn.on("click", function () {
// //         populateTable(publishedTableBody, 'approved');
// //         setActiveTable(publishedTableContainer, $(this));
// //     });

// //     pendingBtn.on("click", function () {
// //         populateTable(pendingTableBody, 'pending');
// //         setActiveTable(pendingTableContainer, $(this));
// //     });

// //     expiredBtn.on("click", function () {
// //         populateTable(expiredTableBody, 'expired');
// //         setActiveTable(expiredTableContainer, $(this));
// //     });

// //     // Initial population of other tables (optional, but good for initial state if JS is slow)
// //     populateTable(publishedTableBody, 'approved');
// //     populateTable(pendingTableBody, 'pending');
// //     populateTable(expiredTableBody, 'expired');
// // });

// // $(document).ready(function () {
// //     // Sidebar Toggle
// //     const sidebar = $('#sidebar');
// //     const mainContent = $('#main-content');
// //     const sidebarToggle = $('.sidebar .hamburger'); // Fix: Use correct selector
// //     const topNavHamburger = $('.top-nav .top-nav-hamburger');
// //     const openProfileBox = $('.open-profile-box');
// //     const leftdata = $('.leftdata');

// //     // Sidebar toggle
// //     sidebarToggle.on('click', function (event) {
// //         event.stopPropagation(); // Prevent click event from closing it immediately
// //         sidebar.toggleClass('open');
// //         mainContent.toggleClass('open');
// //     });

// //     // Top navigation profile menu toggle
// //     topNavHamburger.on('click', function (event) {
// //         event.stopPropagation();
// //         openProfileBox.toggleClass('active');
// //     });

// //     leftdata.on('click', function (event) {
// //         event.stopPropagation();
// //         openProfileBox.toggleClass('active');
// //     });

// //     // Click outside to close sidebar or profile box
// //     $(document).on('click', function (event) {
// //         let isClickInsideSidebar = $(event.target).closest('#sidebar, .sidebar .hamburger').length;
// //         let isClickInsideProfileBox = $(event.target).closest('.open-profile-box, .top-nav-hamburger').length;

// //         if (!isClickInsideSidebar) {
// //             sidebar.removeClass('open');
// //             mainContent.removeClass('open');
// //         }

// //         if (!isClickInsideProfileBox) {
// //             openProfileBox.removeClass('active');
// //         }
// //     });

// //     // Filtering functionality
// //     const allBtn = $(".all-btn");
// //     const publishedBtn = $(".published-btn");
// //     const pendingBtn = $(".pending-btn");
// //     const expiredBtn = $(".expired-btn");

// //     const allTable = $(".all-table");
// //     const publishedTableContainer = $(".published-table");
// //     const pendingTableContainer = $(".pending-table");
// //     const expiredTableContainer = $(".expired-table");

// //     const allTableBody = $(".all-table tbody");
// //     const publishedTableBody = $("#published-table-body");
// //     const pendingTableBody = $("#pending-table-body");
// //     const expiredTableBody = $("#expired-table-body");

// //     // function populateTable(targetTableBody, filterStatus) {
// //     //     targetTableBody.empty();
// //     //     allTableBody.find('tr').each(function() {
// //     //         const status = $(this).find('td:nth-child(4)').text().toLowerCase().trim();
// //     //         if (status === filterStatus) {
// //     //             targetTableBody.append($(this).clone());
// //     //         }
// //     //     });
// //     //     if (targetTableBody.is(':empty')) {
// //     //         targetTableBody.append('<tr><td colspan="7">No records found with status: ' + filterStatus.charAt(0).toUpperCase() + filterStatus.slice(1) + '</td></tr>');
// //     //     }
// //     // }
// //     function populateTable(targetTableBody, filterStatus) {
// //         targetTableBody.empty(); // Clear previous results
// //         allTableBody.find('tr').each(function() {
// //             // Extract only the status text (ignoring button inside the cell)
// //             const status = $(this).find('td:nth-child(4)').contents().filter(function() {
// //                 return this.nodeType === 3; // Select only text nodes
// //             }).text().toLowerCase().trim();

// //             if (status === filterStatus) { 
// //                 targetTableBody.append($(this).clone());
// //             }
// //         });

// //         if (targetTableBody.is(':empty')) {
// //             targetTableBody.append('<tr><td colspan="7">No records found with status: ' 
// //                 + filterStatus.charAt(0).toUpperCase() + filterStatus.slice(1) + '</td></tr>');
// //         }
// //     }
// //     function setActiveTable(activeTableContainer, btn) {
// //         $(".table-container").removeClass("active");
// //         activeTableContainer.addClass("active");

// //         $(".btn").removeClass("active");
// //         btn.addClass("active");
// //     }

// //     allBtn.on("click", function () {
// //         setActiveTable(allTable, $(this));
// //     });

// //     publishedBtn.on("click", function () {
// //         populateTable(publishedTableBody, 'approved');
// //         setActiveTable(publishedTableContainer, $(this));
// //     });

// //     pendingBtn.on("click", function () {
// //         populateTable(pendingTableBody, 'pending');
// //         setActiveTable(pendingTableContainer, $(this));
// //     });

// //     expiredBtn.on("click", function () {
// //         populateTable(expiredTableBody, 'expired');
// //         setActiveTable(expiredTableContainer, $(this));
// //     });

// //     populateTable(publishedTableBody, 'approved');
// //     populateTable(pendingTableBody, 'pending');
// //     populateTable(expiredTableBody, 'expired');
// // });

// //april 5
// const fileInput = document.getElementById('fileInput');
// const profilePreview = document.getElementById('profilePreview');
// const sidebar = document.getElementById('sidebar');
// const sidebarToggle = document.getElementById('sidebar-toggle');
// const mainContent = document.getElementById('main-content');
// const topNavHamburger = document.querySelector('.top-nav-hamburger'); // Correct selector
// const profileDropdown = document.querySelector('.open-profile-box');

// fileInput.addEventListener('change', function () {
//     const file = this.files[0];
//     if (file) {
//         const reader = new FileReader();
//         reader.onload = function (e) {
//             profilePreview.src = e.target.result;
//         }
//         reader.readAsDataURL(file);
//     } else {
//         profilePreview.src = "<?php echo htmlspecialchars($_SESSION['image'] ?? 'default.jpg'); ?>";
//     }
// });

// // Sidebar Toggle Functionality
// sidebarToggle.addEventListener('click', function () {
//     sidebar.classList.toggle('collapsed');
//     mainContent.classList.toggle('expanded');
// });

// // Top Navigation Dropdown Toggle Functionality
// topNavHamburger.addEventListener('click', function (event) {
//     event.stopPropagation();
//     profileDropdown.classList.toggle('open');
// });

// // Close the dropdown if clicked outside
// document.addEventListener('click', function (event) {
//     if (!event.target.closest('.top-nav') && profileDropdown.classList.contains('open')) {
//         profileDropdown.classList.remove('open');
//     }
// });

// // working properly
// // $(document).ready(function () {
// //     // Filtering functionality (Updated)
// //     function populateTable(targetTableBody, filterStatus) {
// //         targetTableBody.empty();
// //         $(".all-table tbody tr").each(function () {
// //             const status = $(this).find('.status-text').text().toLowerCase().trim();
// //             if (status === filterStatus) {
// //                 targetTableBody.append($(this).clone());
// //             }
// //         });

// //         if (targetTableBody.is(':empty')) {
// //             targetTableBody.append('<tr><td colspan="7">No records found with status: ' + filterStatus.charAt(0).toUpperCase() + filterStatus.slice(1) + '</td></tr>');
// //         }
// //     }

// //     function setActiveTable(activeTableContainer, btn) {
// //         $(".table-container").removeClass("active");
// //         activeTableContainer.addClass("active");

// //         $(".btn").removeClass("active");
// //         btn.addClass("active");
// //     }

// //     $(".all-btn").on("click", function () {
// //         setActiveTable($(".all-table"), $(this));
// //     });

// //     $(".published-btn").on("click", function () {
// //         populateTable($("#published-table-body"), 'approved');
// //         setActiveTable($(".published-table"), $(this));
// //     });

// //     $(".pending-btn").on("click", function () {
// //         populateTable($("#pending-table-body"), 'pending');
// //         setActiveTable($(".pending-table"), $(this));
// //     });

// //     $(".expired-btn").on("click", function () {
// //         populateTable($("#expired-table-body"), 'expired');
// //         setActiveTable($(".expired-table"), $(this));
// //     });

// //     // Editing functionality
// //     $(document).on("click", ".edit-icon", function () {
// //         let cell = $(this).closest(".status-cell");
// //         let statusText = cell.find(".status-text").text().trim();
// //         let enquiryId = cell.attr("data-id");

// //         let dropdown = `
// //             <select class='status-dropdown'>
// //                 <option value='approved' ${statusText === 'approved' ? 'selected' : ''}>Approved</option>
// //                 <option value='rejected' ${statusText === 'rejected' ? 'selected' : ''}>Rejected</option>
// //             </select>
// //             <button class='submit-status' data-id='${enquiryId}'>✔</button>
// //         `;
// //         cell.html(dropdown);
// //     });

// // Submit new status
// // $(document).on("click", ".submit-status", function () {
// //     let button = $(this);
// //     let cell = button.closest(".status-cell");
// //     let newStatus = cell.find(".status-dropdown").val();
// //     let enquiryId = button.attr("data-id");

// //     // Update the UI
// //     cell.html(`<span class='status-text'>${newStatus}</span> <i class='fa fa-edit edit-icon' data-id='${enquiryId}'></i>`);

// //     // let updateUrl = "connect/update_enquiry_status.php";  // Adjust this if needed
// // console.log("Trying to reach:", window.location.origin + "/" + updateUrl);  // Debugging hint
// // Send AJAX request to update in the database (optional)
// // $.ajax({
// //     url: "connect/update_enquiry_status.php",
// //     type: "POST",
// //     dataType: 'json',
// //     data: { enquiry_id: enquiryId, status: newStatus },
// //     // success: function (response) {
// //     //     console.log("Status updated successfully!");
// //     // },
// // error: function () {
// //     console.log("Error updating status.");
// // }
// //     success: function (response) {
// //         console.log("AJAX Response:", response); // Log the entire response for debugging

// //         // Check the 'status' property of the JSON response
// //         if (response.status === 'success') {
// //             console.log("Status updated successfully!");
// //             // Here you can add code to update the UI if needed
// //             // For example, update the text of the status cell in the table
// //         } else if (response.status === 'error') {
// //             console.error("Error updating status:", response.message);
// //             alert("Error updating status: " + response.message); // Optionally show an alert to the user
// //         } else {
// //             console.warn("Unexpected response:", response); // Handle unexpected responses
// //         }
// //     },
// //     error: function (xhr, status, error) {
// //         console.error("AJAX request failed:", status, error);
// //         alert("AJAX request failed: " + error); // Handle AJAX-level errors
// //     }
// // });
// //      });

// //     // Populate tables initially
// //     populateTable($("#published-table-body"), 'approved');
// //     populateTable($("#pending-table-body"), 'pending');
// //     populateTable($("#expired-table-body"), 'expired');





// // });
// $(document).ready(function () {
//     // ... Your existing scripts.js code ...

//     // Sidebar toggle functionality (if not already present)
//     $('#sidebar-toggle').click(function () {
//         $('.sidebar').toggleClass('collapsed');
//         $('.main-content').toggleClass('expanded');
//     });

//     // Status update modal display
//     $(document).on('click', '.edit-icon', function () {
//         var enquiryId = $(this).data('id');
//         $('#selectedEnquiryId').val(enquiryId);
//         $('#statusModal').css('display', 'block');
//     });

//     $('.close').click(function () {
//         $('#statusModal').css('display', 'none');
//     });
//     // Status update modal display
//     $(document).on('click', '.edit-icon', function () {
//         var enquiryId = $(this).data('id');
//         $('#selectedEnquiryId').val(enquiryId);
//         $('#statusModal').css('display', 'block');
//     });

//     $('.close').click(function () {
//         $('#statusModal').css('display', 'none');
//     });
// })

//     // Status update AJAX call
//     $('#saveStatusBtn').click(function () {
//         var enquiryId = $('#selectedEnquiryId').val();
//         // Convert the selected status to lowercase before sending
//         var newStatus = $('#statusDropdown').val().toLowerCase();

//         $.ajax({
//             url: 'connect/update_enquiry_status.php',
//             type: 'POST',
//             dataType: 'json',
//             data: { id: enquiryId, status: newStatus },
//             success: function (response) {
//                 console.log("AJAX Response:", response);

//                 if (response.status === 'success') {
//                     console.log("Status updated successfully!");
//                     $('#statusModal').css('display', 'none');
//                     // Update the status badge in the table with lowercase status
//                     $('.status-cell[data-id="' + enquiryId + '"]')
//                         .html('<span class="status-badge ' + newStatus + '">' + newStatus.charAt(0).toUpperCase() + newStatus.slice(1) + '</span> <i class="fa fa-edit edit-icon" data-id="' + enquiryId + '"></i>');

//                     var activeFilter = $('.listing-btns .btn.active').data('status');
//                     filterTable(activeFilter);

//                 } else if (response.status === 'error') {
//                     console.error("Error updating status:", response.message);
//                     alert("Error updating status: " + response.message);
//                 } else {
//                     console.warn("Unexpected response:", response);
//                 }
//             },
//             error: function (xhr, status, error) {
//                 console.error("AJAX request failed:", status, error);
//                 alert("AJAX request failed: " + error);
//             }
//         });
    
//         // Function to filter the table based on the status
//         function filterTable(status) {
//             $('table tbody tr').hide();
//             if (status === 'all') {
//                 $('table tbody tr').show();
//             } else {
//                 $('table tbody tr').filter(function () {
//                     return $(this).find('.status-badge').text().trim().toLowerCase() === status.toLowerCase();
//                 }).show();
//             }
//         }
//     })

// //